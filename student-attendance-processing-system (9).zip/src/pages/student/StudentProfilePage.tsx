import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { UserCheck, ShieldCheck, Mail, Radio, Hash, Layers, GraduationCap } from 'lucide-react';

export const StudentProfilePage: React.FC = () => {
  const { student, user } = useAuth();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Student Profile & Credentials</h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Institutional identity records and academic enrollment details.
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
        <div className="p-6 bg-slate-900 dark:bg-slate-950 text-white flex items-center gap-4 border-b border-slate-800">
          <div className="w-14 h-14 rounded-lg bg-sky-700 flex items-center justify-center font-bold text-xl text-white shadow-sm">
            {student?.name?.substring(0, 2).toUpperCase() || 'ST'}
          </div>
          <div>
            <h2 className="text-lg font-bold">{student?.name || user?.name}</h2>
            <div className="text-xs text-slate-400 font-mono mt-0.5">
              Roll No: {student?.roll_number} · Section {student?.section}
            </div>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Full Name</span>
            <div className="text-sm font-semibold text-slate-900 dark:text-white">{student?.name}</div>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Roll Number</span>
            <div className="text-sm font-mono font-bold text-slate-900 dark:text-white">{student?.roll_number}</div>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Institutional Email</span>
            <div className="text-sm font-mono text-slate-800 dark:text-slate-200">{student?.email || user?.email}</div>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Smart Card / RFID Identifier</span>
            <div className="text-sm font-mono font-bold text-sky-700 dark:text-sky-400 flex items-center gap-1.5">
              <Radio className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <span>{student?.rfid_id}</span>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Academic Branch</span>
            <div className="text-sm font-medium text-slate-800 dark:text-slate-200">{student?.branch}</div>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 dark:text-slate-400 uppercase font-semibold text-[10px] block">Semester & Section</span>
            <div className="text-sm font-medium text-slate-800 dark:text-slate-200">Semester {student?.semester} · Section {student?.section}</div>
          </div>
        </div>

        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>Department of Computer Science & Engineering</span>
          <span>Verified Student Identity</span>
        </div>
      </div>
    </div>
  );
};
