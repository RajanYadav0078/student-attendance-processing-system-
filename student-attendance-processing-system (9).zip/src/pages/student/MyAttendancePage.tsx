import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { StudentAttendanceProfile, SubjectAttendanceSummary } from '../../types/index.ts';
import { Calendar, Clock, CheckCircle2, AlertTriangle } from 'lucide-react';

interface MyAttendancePageProps {
  onNavigate: (view: string) => void;
}

export const MyAttendancePage: React.FC<MyAttendancePageProps> = ({ onNavigate }) => {
  const [profile, setProfile] = useState<StudentAttendanceProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDashboardData();
      if (data && data.profile) {
        setProfile(data.profile);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const upcomingClasses = [
    { code: 'CCSE0304', name: 'Computer Architecture & Parallel Processing', time: '10:00 AM - 11:00 AM', room: 'Hall LH-302', faculty: 'Prof. Arvind Sharma' },
    { code: 'CCSE0301', name: 'Data Structures & Algorithms', time: '11:15 AM - 12:15 PM', room: 'Lab CSE-04', faculty: 'Dr. Priya Patel' },
    { code: 'CCSE0302', name: 'Operating Systems', time: '02:00 PM - 03:00 PM', room: 'Hall LH-301', faculty: 'Dr. Rajesh Kumar' },
  ];

  if (isLoading) {
    return <div className="p-8 text-xs text-slate-500 dark:text-slate-400">Loading attendance data...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">My Subject Attendance Status</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Subject-wise attendance calculations, attended/absent tallies, and ordinance compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('student-requests')}
            className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-200 text-xs font-semibold rounded-md border border-amber-200 dark:border-amber-800 transition-colors flex items-center gap-1.5"
          >
            <span>Attendance Grievance / Request</span>
          </button>

          <button
            onClick={() => onNavigate('student-reports')}
            className="px-4 py-2 bg-slate-900 dark:bg-sky-700 hover:bg-slate-800 dark:hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors"
          >
            Download PDF Audit Report
          </button>
        </div>
      </div>

      {/* Main Subjects Table */}
      <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Enrolled Courses (Semester 3)</span>
          <span className="text-xs text-slate-500 dark:text-slate-400">Minimum 75.0% required</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Faculty In-Charge</th>
                <th className="py-3 px-4 text-right">Total Classes</th>
                <th className="py-3 px-4 text-right">Attended</th>
                <th className="py-3 px-4 text-right">Absent</th>
                <th className="py-3 px-4 text-right">Attendance %</th>
                <th className="py-3 px-4 text-center">Eligibility Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {profile?.subjects.map((sub: SubjectAttendanceSummary) => (
                <tr key={sub.subject_id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-mono font-bold text-slate-900 dark:text-white">{sub.subject_code}</div>
                    <div className="text-slate-600 dark:text-slate-300 font-medium">{sub.subject_name}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{sub.faculty_name}</td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">{sub.total_classes}</td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                    {sub.attended_classes}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500 dark:text-slate-400">{sub.absent_classes}</td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-900 dark:text-white text-sm">
                    {sub.attendance_percentage}%
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center gap-1 font-semibold ${
                        sub.is_eligible ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {sub.is_eligible ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Eligible</span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Shortage</span>
                        </>
                      )}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upcoming Timetable */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-sky-700 dark:text-sky-400" />
            <span>Today's Upcoming Lecture Schedule</span>
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">Section A Lecture Hall</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingClasses.map((cls, idx) => (
            <div key={idx} className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="font-bold text-sky-800 dark:text-sky-400">{cls.code}</span>
                <span className="text-slate-500 dark:text-slate-400">{cls.room}</span>
              </div>
              <h4 className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1">{cls.name}</h4>
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{cls.time}</span>
                </span>
                <span className="truncate max-w-[120px]">{cls.faculty}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
