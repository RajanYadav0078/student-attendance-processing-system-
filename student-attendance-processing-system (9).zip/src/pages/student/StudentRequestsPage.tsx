import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { AttendanceCorrectionRequest, AttendanceRecord } from '../../types/index.ts';
import { AttendanceDisputeModal } from '../../components/attendance/AttendanceDisputeModal.tsx';
import {
  HelpCircle,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  Filter,
  ArrowLeft,
  Calendar,
  BookOpen,
  MessageSquare,
  ShieldCheck,
  FileText,
} from 'lucide-react';

interface StudentRequestsPageProps {
  onNavigate: (view: string) => void;
}

export const StudentRequestsPage: React.FC<StudentRequestsPageProps> = ({ onNavigate }) => {
  const [requests, setRequests] = useState<AttendanceCorrectionRequest[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await api.getStudentAttendanceRequests();
      setRequests(data || []);
    } catch (e) {
      console.error('Failed to load attendance requests', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const filteredRequests = requests.filter((r) => {
    if (statusFilter === 'pending') {
      if (r.status !== 'pending' && r.status !== 'pending_faculty') return false;
    } else if (statusFilter !== 'all' && r.status !== statusFilter) {
      return false;
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchSub = r.subject_code?.toLowerCase().includes(q) || r.subject_name?.toLowerCase().includes(q);
      const matchReason = r.reason?.toLowerCase().includes(q);
      const matchFaculty = r.faculty_name?.toLowerCase().includes(q);
      if (!matchSub && !matchReason && !matchFaculty) return false;
    }
    return true;
  });

  const pendingFacultyCount = requests.filter((r) => r.status === 'pending' || r.status === 'pending_faculty').length;
  const facultyVerifiedCount = requests.filter((r) => r.status === 'faculty_verified').length;
  const approvedCount = requests.filter((r) => r.status === 'approved').length;
  const rejectedCount = requests.filter((r) => r.status === 'rejected').length;

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'technical_glitch':
        return '⚡ Technical Glitch';
      case 'marked_absent_by_mistake':
        return '🙋 Absent by Mistake';
      case 'medical_leave':
        return '🏥 Medical Leave';
      case 'college_duty':
        return '🏆 College Duty / On-Duty';
      default:
        return '📝 Other Reason';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-400 font-semibold mb-1">
            <HelpCircle className="w-4 h-4" />
            <span>Attendance Grievance & Correction Portal</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Attendance Issue Requests
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Report attendance discrepancies, scanner timeouts, or authorized leaves directly to your instructors.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('student-dashboard')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Request Attendance Correction</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-amber-200 dark:border-amber-900/60 transition-colors">
          <div className="text-xs text-amber-700 dark:text-amber-400 font-semibold flex items-center justify-between">
            <span>1. Awaiting Faculty</span>
            <Clock className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {pendingFacultyCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Under instructor verification</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-indigo-200 dark:border-indigo-900/60 transition-colors">
          <div className="text-xs text-indigo-700 dark:text-indigo-400 font-semibold flex items-center justify-between">
            <span>2. Faculty Verified</span>
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-700 dark:text-indigo-400 mt-1">
            {facultyVerifiedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Awaiting admin final approval</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-emerald-200 dark:border-emerald-900/60 transition-colors">
          <div className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold flex items-center justify-between">
            <span>3. Admin Approved</span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
            {approvedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Marked present in registry</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-rose-200 dark:border-rose-900/60 transition-colors">
          <div className="text-xs text-rose-700 dark:text-rose-400 font-semibold flex items-center justify-between">
            <span>Declined</span>
            <XCircle className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-700 dark:text-rose-400 mt-1">
            {rejectedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Remarks provided</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center gap-3 text-xs transition-colors">
        <div className="relative flex-1 w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by course code, topic, or instructor name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
          >
            <option value="all">All Statuses ({requests.length})</option>
            <option value="pending">1. Awaiting Faculty ({pendingFacultyCount})</option>
            <option value="faculty_verified">2. Faculty Verified ({facultyVerifiedCount})</option>
            <option value="approved">3. Approved & Present ({approvedCount})</option>
            <option value="rejected">Declined ({rejectedCount})</option>
          </select>
        </div>
      </div>

      {/* Request Cards / Table List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <div className="w-6 h-6 border-2 border-sky-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <span className="text-xs text-slate-500">Loading your attendance requests...</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-lg border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
            <HelpCircle className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">No attendance requests found</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
              If you experienced a technical issue during QR scanning or were marked absent while present, click below to submit a dispute to your faculty.
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm inline-flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Submit Attendance Issue</span>
            </button>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 p-5 shadow-xs transition-colors space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                    {req.subject_code}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">·</span>
                  <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                    {req.subject_name}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">·</span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Faculty: <strong>{req.faculty_name}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                    {getCategoryLabel(req.category)}
                  </span>

                  {(req.status === 'pending' || req.status === 'pending_faculty') && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                      <Clock className="w-3 h-3" />
                      <span>Step 1: Awaiting Faculty</span>
                    </span>
                  )}

                  {req.status === 'faculty_verified' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Step 2: Faculty Verified · Awaiting Admin</span>
                    </span>
                  )}

                  {req.status === 'approved' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Step 3: Admin Approved · Present</span>
                    </span>
                  )}

                  {req.status === 'rejected' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      <XCircle className="w-3 h-3" />
                      <span>Declined</span>
                    </span>
                  )}
                </div>
              </div>

              {/* 4-Step Multi-Tier Progress Stepper */}
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-md border border-slate-200/70 dark:border-slate-800">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Approval & Verification Lifecycle
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  {/* Step 1 */}
                  <div className="flex items-center gap-2 p-2 rounded bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200 text-[11px]">1. Submitted</div>
                      <div className="text-[10px] text-slate-400">By Student</div>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div
                    className={`flex items-center gap-2 p-2 rounded border ${
                      req.status === 'faculty_verified' || req.status === 'approved'
                        ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800'
                        : req.status === 'rejected'
                        ? 'bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-700'
                        : 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800'
                    }`}
                  >
                    {req.status === 'faculty_verified' || req.status === 'approved' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                    )}
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200 text-[11px]">2. Faculty Verification</div>
                      <div className="text-[10px] text-slate-500">
                        {req.faculty_verified_by || 'Course Instructor'}
                      </div>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div
                    className={`flex items-center gap-2 p-2 rounded border ${
                      req.status === 'approved'
                        ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800'
                        : req.status === 'faculty_verified'
                        ? 'bg-indigo-50/60 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-800'
                        : 'bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-700 opacity-75'
                    }`}
                  >
                    {req.status === 'approved' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                    )}
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200 text-[11px]">3. Admin Final Approval</div>
                      <div className="text-[10px] text-slate-500">
                        {req.admin_approved_by || 'Administration'}
                      </div>
                    </div>
                  </div>

                  {/* Step 4 */}
                  <div
                    className={`flex items-center gap-2 p-2 rounded border ${
                      req.status === 'approved'
                        ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-700'
                        : 'bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-700 opacity-60'
                    }`}
                  >
                    <BookOpen
                      className={`w-4 h-4 shrink-0 ${
                        req.status === 'approved' ? 'text-emerald-600' : 'text-slate-400'
                      }`}
                    />
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200 text-[11px]">4. Registry Updated</div>
                      <div className="text-[10px] text-slate-500">
                        {req.status === 'approved' ? 'Marked Present' : 'Pending Approval'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main Content Details */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
                <div className="md:col-span-8 space-y-2">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-0.5">
                      Your Explanation:
                    </span>
                    <p className="text-slate-800 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-850 p-3 rounded border border-slate-100 dark:border-slate-800">
                      {req.reason}
                    </p>
                  </div>

                  {req.proof_note && (
                    <div className="text-[11px] text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Reference/Proof: <strong>{req.proof_note}</strong></span>
                    </div>
                  )}
                </div>

                <div className="md:col-span-4 bg-slate-50 dark:bg-slate-800/40 p-3 rounded border border-slate-200 dark:border-slate-750 flex flex-col justify-between space-y-2">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 dark:text-slate-400">Class Date:</span>
                      <span className="font-mono font-semibold text-slate-900 dark:text-white">{req.date}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 dark:text-slate-400">Submitted:</span>
                      <span className="text-slate-700 dark:text-slate-300">
                        {new Date(req.created_at).toLocaleDateString()} {new Date(req.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  {/* Multi-Tier Notes */}
                  <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                    {req.faculty_remarks && (
                      <div>
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 block mb-0.5 flex items-center gap-1">
                          <MessageSquare className="w-3 h-3 text-sky-600" />
                          <span>Faculty Note ({req.faculty_verified_by || 'Faculty'}):</span>
                        </span>
                        <p className="text-[11px] italic text-slate-800 dark:text-slate-200">
                          "{req.faculty_remarks}"
                        </p>
                      </div>
                    )}

                    {req.admin_remarks && (
                      <div className="pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 block mb-0.5 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 text-emerald-600" />
                          <span>Admin Authorization ({req.admin_approved_by || 'Admin'}):</span>
                        </span>
                        <p className="text-[11px] font-medium text-emerald-800 dark:text-emerald-300">
                          "{req.admin_remarks}"
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      <AttendanceDisputeModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={() => loadRequests()}
      />
    </div>
  );
};
