import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';
import { AttendanceRecord, Subject } from '../../types/index.ts';
import { AttendanceDisputeModal } from '../../components/attendance/AttendanceDisputeModal.tsx';
import { Search, Filter, Calendar, CheckCircle2, XCircle, ArrowLeft, HelpCircle } from 'lucide-react';

interface AttendanceHistoryPageProps {
  onNavigate: (view: string) => void;
}

export const AttendanceHistoryPage: React.FC<AttendanceHistoryPageProps> = ({ onNavigate }) => {
  const { student } = useAuth();
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [disputeRecord, setDisputeRecord] = useState<AttendanceRecord | null>(null);

  useEffect(() => {
    loadData();
  }, [student]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      if (student?.id) {
        const studentData = await api.getStudentById(student.id);
        setRecords(studentData.recent_records || []);
      }
      const subjs = await api.getSubjects();
      setSubjects(subjs);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredRecords = records.filter((r) => {
    if (selectedSubject && r.subject_id !== selectedSubject) return false;
    if (selectedStatus && r.status !== selectedStatus) return false;
    if (dateFilter && r.date !== dateFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchSub = r.subject_code?.toLowerCase().includes(q) || r.subject_name?.toLowerCase().includes(q);
      const matchMethod = r.method?.toLowerCase().includes(q);
      if (!matchSub && !matchMethod) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Attendance History Logs</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Complete transaction record of your classroom check-ins, timestamps, and verification methods.
          </p>
        </div>

        <button
          onClick={() => onNavigate('student-dashboard')}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Dashboard</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3 text-xs transition-colors">
        <div className="relative flex-1 w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by course code or method..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-sans transition-colors"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Subject Filter */}
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
          >
            <option value="">All Subjects</option>
            {subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.subject_code} - {sub.subject_name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
          >
            <option value="">All Statuses</option>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
          </select>

          {/* Date Filter */}
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
          />
        </div>
      </div>

      {/* History Log Table */}
      <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Time</th>
                <th className="py-3 px-4">Course Code & Subject</th>
                <th className="py-3 px-4">Check-In Method</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Grievance / Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 dark:text-slate-500">
                    Loading records...
                  </td>
                </tr>
              ) : filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 dark:text-slate-500">
                    No attendance records match your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900 dark:text-white">{rec.date}</td>
                    <td className="py-3 px-4 font-mono text-slate-500 dark:text-slate-400">{rec.time}</td>
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-slate-800 dark:text-slate-200">{rec.subject_code}</div>
                      <div className="text-slate-500 dark:text-slate-400 text-[11px]">{rec.subject_name}</div>
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[10px] uppercase font-semibold">
                        {rec.method}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 font-semibold ${
                          rec.status === 'present' ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        {rec.status === 'present' ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Present</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Absent</span>
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {rec.status === 'absent' ? (
                        <button
                          onClick={() => setDisputeRecord(rec)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 rounded transition-colors inline-flex items-center gap-1 shadow-2xs"
                        >
                          <HelpCircle className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                          <span>Request Correction</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400">Verified</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Attendance Dispute Modal */}
      {disputeRecord && (
        <AttendanceDisputeModal
          isOpen={Boolean(disputeRecord)}
          onClose={() => setDisputeRecord(null)}
          onSuccess={() => {
            loadData();
          }}
          initialSubjectId={disputeRecord.subject_id}
          initialDate={disputeRecord.date}
          initialSessionId={disputeRecord.session_id}
        />
      )}
    </div>
  );
};
