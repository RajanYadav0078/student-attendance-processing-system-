import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';
import { StudentAttendanceProfile } from '../../types/index.ts';
import { PrintableReport } from '../../components/reports/PrintableReport.tsx';
import { FileText, ArrowLeft } from 'lucide-react';

interface StudentReportsPageProps {
  onNavigate: (view: string) => void;
}

export const StudentReportsPage: React.FC<StudentReportsPageProps> = ({ onNavigate }) => {
  const { student } = useAuth();
  const [profile, setProfile] = useState<StudentAttendanceProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadProfile();
  }, [student]);

  const loadProfile = async () => {
    setIsLoading(true);
    try {
      if (student?.id) {
        const data = await api.getStudentById(student.id);
        setProfile(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
        Preparing student audit report...
      </div>
    );
  }

  // Proper empty-state card when there is no attendance data yet
  if (!profile || profile.total_classes === 0) {
    return (
      <div className="py-16 px-4 max-w-md mx-auto text-center space-y-4">
        <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 dark:text-slate-500 shadow-xs">
          <FileText className="w-7 h-7" />
        </div>
        <div className="space-y-1">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            No attendance data available yet.
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Attendance sessions marked by faculty will appear here automatically with subject percentages and examination eligibility status.
          </p>
        </div>
        <div className="pt-2">
          <button
            onClick={() => onNavigate('student-dashboard')}
            className="inline-flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <PrintableReport
        profile={profile}
        title="Semester 3 Attendance Cumulative Eligibility Statement"
        onBack={() => onNavigate('student-dashboard')}
      />
    </div>
  );
};
