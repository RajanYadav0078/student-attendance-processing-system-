import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';
import { StudentAttendanceProfile, AttendanceRecord } from '../../types/index.ts';
import { StatCard } from '../../components/common/StatCard.tsx';
import { SubjectBarChart } from '../../components/charts/SubjectBarChart.tsx';
import { MonthlyTrendChart } from '../../components/charts/MonthlyTrendChart.tsx';
import { AttendanceDonut } from '../../components/charts/AttendanceDonut.tsx';
import { QRScannerModal } from '../../components/attendance/QRScannerModal.tsx';
import { AttendanceDisputeModal } from '../../components/attendance/AttendanceDisputeModal.tsx';
import { AiStudentAssistant } from '../../components/attendance/AiStudentAssistant.tsx';
import { AttendanceCorrectionRequest } from '../../types/index.ts';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  QrCode,
  FileText,
  TrendingUp,
  HelpCircle,
  Clock,
  PlusCircle,
  MessageSquare,
} from 'lucide-react';

interface StudentDashboardProps {
  onNavigate: (view: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const { student, user } = useAuth();
  const [profile, setProfile] = useState<StudentAttendanceProfile | null>(null);
  const [recentRecords, setRecentRecords] = useState<AttendanceRecord[]>([]);
  const [requests, setRequests] = useState<AttendanceCorrectionRequest[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isDisputeModalOpen, setIsDisputeModalOpen] = useState<boolean>(false);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDashboardData();
      if (data && data.profile) {
        setProfile(data.profile);
        setRecentRecords(data.recentRecords || []);
      }
      const reqs = await api.getStudentAttendanceRequests().catch(() => []);
      setRequests(reqs || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-slate-200 dark:bg-slate-800 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const overallPct = profile?.overall_percentage ?? 0;
  const isEligible = profile?.is_eligible ?? true;
  const attended = profile?.attended_classes ?? 0;
  const total = profile?.total_classes ?? 0;
  const absent = profile?.absent_classes ?? 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Student Profile Header Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono mb-1">
            <span>Roll No: {student?.roll_number || 'Enrolled Student'}</span>
            <span>·</span>
            <span>Section {student?.section || '—'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Welcome, {student?.name || user?.name}
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            B.Tech Computer Science & Engineering · Semester 3
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsDisputeModalOpen(true)}
            className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-200 text-xs font-semibold rounded-md border border-amber-200 dark:border-amber-800 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <HelpCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>Attendance Issue?</span>
          </button>

          <button
            onClick={() => setIsScannerOpen(true)}
            className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-2 shadow-sm"
          >
            <QrCode className="w-4 h-4" />
            <span>Scan QR Attendance</span>
          </button>

          <button
            onClick={() => onNavigate('student-reports')}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-md border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1.5"
          >
            <FileText className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span>Attendance Report</span>
          </button>
        </div>
      </div>

      {/* Attendance Alert Notice if Shortage */}
      {!isEligible && (
        <div className="p-4 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-start gap-3 text-xs text-rose-900 dark:text-rose-200">
          <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-bold block text-sm">Attendance Shortage / Defaulter Warning</span>
            <p className="mt-0.5 text-rose-800 dark:text-rose-300 leading-relaxed">
              Your overall attendance is currently <strong className="font-mono">{overallPct}%</strong>, which is
              below the mandatory 75% institutional eligibility threshold. If you were marked absent erroneously, submit a correction request to faculty.
            </p>
            <div className="mt-2.5 flex items-center gap-2">
              <button
                onClick={() => setIsDisputeModalOpen(true)}
                className="px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Request Attendance Correction</span>
              </button>
              <button
                onClick={() => onNavigate('student-requests')}
                className="px-3 py-1.5 bg-white dark:bg-slate-900 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-700 rounded text-xs font-medium hover:bg-rose-50 transition-colors"
              >
                View Requests ({requests.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Four Core Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Overall Cumulative Attendance"
          value={`${overallPct}%`}
          subtext={`Target: ≥ 75.0% threshold`}
          icon={TrendingUp}
          highlight
          badge={{
            text: isEligible ? 'Eligible' : 'Attendance Shortage',
            variant: isEligible ? 'success' : 'danger',
          }}
        />

        <StatCard
          label="Total Classes Scheduled"
          value={total}
          subtext="Theory + Laboratory modules"
          icon={CalendarCheck}
        />

        <StatCard
          label="Lectures Attended"
          value={attended}
          subtext="Verified physical presence"
          icon={CheckCircle2}
          badge={{ text: 'Verified', variant: 'info' }}
        />

        <StatCard
          label="Classes Absent"
          value={absent}
          subtext="Leaves & missed sessions"
          icon={XCircle}
          badge={{
            text: absent > 5 ? 'High Absence' : 'Acceptable',
            variant: absent > 5 ? 'warning' : 'info',
          }}
        />
      </div>

      {/* Analytics Grid: Subject Distribution + Donut Ratio */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8">
          <SubjectBarChart subjects={profile?.subjects || []} threshold={75} />
        </div>
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-colors">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Aggregate Presence Ratio</h3>
            <span className="text-xs text-slate-500 dark:text-slate-400">Present vs. Absent Lectures</span>
          </div>
          <AttendanceDonut present={attended} absent={absent} size={170} />
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
            Formula: <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">({attended} / {total}) × 100 = {overallPct}%</span>
          </div>
        </div>
      </div>

      {/* Subject-Wise Detailed Cards Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Enrolled Course Breakdown</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Semester 3 Curriculum</p>
          </div>
          <button
            onClick={() => onNavigate('student-attendance')}
            className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-800"
          >
            Detailed View & Schedule
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {profile?.subjects.map((subj) => (
            <div
              key={subj.subject_id}
              onClick={() => onNavigate('student-attendance')}
              className="bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between hover:border-sky-300 dark:hover:border-sky-700 cursor-pointer transition-all"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{subj.subject_code}</span>
                  <span
                    className={`font-semibold ${
                      subj.is_eligible ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                    }`}
                  >
                    {subj.is_eligible ? 'Eligible' : 'Shortage'}
                  </span>
                </div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white line-clamp-1">{subj.subject_name}</h4>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">{subj.faculty_name}</div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-slate-400">
                    Attended: <strong className="text-slate-800 dark:text-slate-200 font-mono">{subj.attended_classes}</strong> / {subj.total_classes}
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">
                    {subj.attendance_percentage}%
                  </span>
                </div>

                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-sm overflow-hidden">
                  <div
                    className={`h-full rounded-sm ${
                      subj.is_eligible ? 'bg-sky-700 dark:bg-sky-500' : 'bg-rose-600'
                    }`}
                    style={{ width: `${subj.attendance_percentage}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Monthly Trend Velocity & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <MonthlyTrendChart />
        </div>

        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-colors">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Recent Attendance Logs</h3>
              <button
                onClick={() => onNavigate('student-history')}
                className="text-xs text-sky-700 dark:text-sky-400 hover:underline font-medium"
              >
                View Full Log
              </button>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {recentRecords.length === 0 ? (
                <div className="py-6 text-center text-slate-400 dark:text-slate-500">No attendance activity recorded yet</div>
              ) : (
                recentRecords.slice(0, 5).map((rec) => (
                  <div key={rec.id} className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        <span className="font-mono">{rec.subject_code}</span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-mono">· {rec.method}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{rec.date}</span>
                        <span>·</span>
                        <span className="font-mono">{rec.time}</span>
                      </div>
                    </div>
                    <span
                      className={`text-xs font-semibold ${
                        rec.status === 'present'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {rec.status === 'present' ? 'Present' : 'Absent'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 dark:text-slate-500 text-center">
            Synchronized with University Attendance Registry
          </div>
        </div>
      </div>

      {/* Attendance Disputes & Faculty Requests Panel */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                <span>Attendance Issue & Dispute Requests</span>
              </h2>
              {requests.length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-sky-100 dark:bg-sky-950/60 text-sky-800 dark:text-sky-300">
                  {requests.length} submitted
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Faced a scanner timeout or marked absent by mistake? Submit a request directly to your course instructor.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDisputeModalOpen(true)}
              className="px-3.5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>+ Request Correction</span>
            </button>
            <button
              onClick={() => onNavigate('student-requests')}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 transition-colors"
            >
              Full History
            </button>
          </div>
        </div>

        {/* Requests List */}
        {requests.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg space-y-2">
            <p>No active attendance disputes or requests submitted.</p>
            <button
              onClick={() => setIsDisputeModalOpen(true)}
              className="text-xs text-sky-700 dark:text-sky-400 hover:underline font-medium"
            >
              Report an attendance discrepancy to faculty →
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {requests.slice(0, 3).map((req) => (
              <div key={req.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-slate-900 dark:text-white">{req.subject_code}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-700 dark:text-slate-300">{req.subject_name}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500 font-mono">Date: {req.date}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 text-[11px] line-clamp-1 italic">
                    "{req.reason}"
                  </p>
                  {req.faculty_remarks && (
                    <div className="text-[11px] text-emerald-800 dark:text-emerald-300 flex items-center gap-1 font-medium">
                      <MessageSquare className="w-3 h-3" />
                      <span>Faculty Feedback: {req.faculty_remarks}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {req.status === 'pending' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                      <Clock className="w-3 h-3" />
                      <span>Pending Faculty Review</span>
                    </span>
                  )}
                  {req.status === 'approved' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Approved · Marked Present</span>
                    </span>
                  )}
                  {req.status === 'rejected' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      <XCircle className="w-3 h-3" />
                      <span>Declined</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* QR Scanner Modal */}
      <QRScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onSuccess={() => {
          fetchDashboardData();
        }}
      />

      {/* Attendance Dispute Modal */}
      <AttendanceDisputeModal
        isOpen={isDisputeModalOpen}
        onClose={() => setIsDisputeModalOpen(false)}
        onSuccess={() => {
          fetchDashboardData();
        }}
        recentAbsentRecords={recentRecords.filter((r) => r.status === 'absent')}
      />

      {/* AI Attendance Assistant */}
      <AiStudentAssistant />
    </div>
  );
};
