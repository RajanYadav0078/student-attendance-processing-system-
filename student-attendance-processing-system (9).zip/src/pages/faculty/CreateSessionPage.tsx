import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotification } from '../../context/NotificationContext.tsx';
import { AttendanceSession, Subject } from '../../types/index.ts';
import { QrCode, Clock, Users, CheckCircle2, Play, AlertCircle, RefreshCw, ArrowRight } from 'lucide-react';

interface CreateSessionPageProps {
  onNavigate: (view: string) => void;
}

export const CreateSessionPage: React.FC<CreateSessionPageProps> = ({ onNavigate }) => {
  const { faculty } = useAuth();
  const { showToast } = useNotification();

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');
  const [selectedSection, setSelectedSection] = useState<string>('A');
  const [lectureTopic, setLectureTopic] = useState<string>('Regular Lecture Session');
  const [durationMinutes, setDurationMinutes] = useState<number>(15);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  // Active Session State
  const [activeSession, setActiveSession] = useState<AttendanceSession | null>(null);
  const [attendees, setAttendees] = useState<any[]>([]);
  const [presentCount, setPresentCount] = useState<number>(0);
  const [totalStudents, setTotalStudents] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);

  useEffect(() => {
    loadSubjects();
  }, []);

  const loadSubjects = async () => {
    try {
      const allSubjs = await api.getSubjects();
      const mySubjs = faculty ? allSubjs.filter((s) => s.faculty_id === faculty.id) : allSubjs;
      const finalSubjs = mySubjs.length > 0 ? mySubjs : allSubjs;
      setSubjects(finalSubjs);
      if (finalSubjs.length > 0) {
        setSelectedSubjectId(finalSubjs[0].id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Poll attendees while active session is running
  useEffect(() => {
    let interval: any;
    if (activeSession && activeSession.status === 'active') {
      fetchSessionDetails(activeSession.id);
      interval = setInterval(() => {
        fetchSessionDetails(activeSession.id);
      }, 3000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeSession]);

  // Countdown timer
  useEffect(() => {
    let timer: any;
    if (activeSession && activeSession.status === 'active') {
      const expires = new Date(activeSession.expires_at).getTime();
      const updateTimer = () => {
        const now = Date.now();
        const diff = Math.max(0, Math.floor((expires - now) / 1000));
        setTimeLeft(diff);
        if (diff <= 0) {
          handleCloseSession();
        }
      };
      updateTimer();
      timer = setInterval(updateTimer, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [activeSession]);

  const fetchSessionDetails = async (sessionId: string) => {
    try {
      const res = await api.getSessionDetails(sessionId);
      setAttendees(res.students);
      setPresentCount(res.present_count);
      setTotalStudents(res.total_students);
    } catch {
      //
    }
  };

  const handleCreateSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubjectId) {
      showToast({ type: 'warning', message: 'Please select a subject' });
      return;
    }

    setIsCreating(true);
    try {
      const newSession = await api.createSession({
        subjectId: selectedSubjectId,
        section: selectedSection,
        lectureTopic,
        durationMinutes,
      });

      setActiveSession(newSession);
      showToast({
        type: 'success',
        title: 'Attendance QR Generated',
        message: `Live session created for Section ${selectedSection}. Students may now scan.`,
      });
      fetchSessionDetails(newSession.id);
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Creation Failed',
        message: err.message || 'Could not start attendance session',
      });
    } finally {
      setIsCreating(false);
    }
  };

  const handleCloseSession = async () => {
    if (!activeSession) return;
    try {
      await api.closeSession(activeSession.id);
      setActiveSession((prev) => (prev ? { ...prev, status: 'closed' } : null));
      showToast({
        type: 'info',
        title: 'Session Closed',
        message: 'Attendance QR session has been closed. QR tokens will no longer be accepted.',
      });
    } catch (e: any) {
      console.error(e);
    }
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Generate Dynamic Attendance QR Code
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Initiate a time-limited attendance session. Students scan using their portal camera.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form & Setup */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5 transition-colors">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <Clock className="w-4 h-4 text-sky-700 dark:text-sky-400" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Session Parameters</h2>
          </div>

          <form onSubmit={handleCreateSession} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Assigned Subject</label>
              <select
                value={selectedSubjectId}
                onChange={(e) => setSelectedSubjectId(e.target.value)}
                required
                disabled={activeSession?.status === 'active'}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
              >
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.subject_code} - {sub.subject_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Class Section</label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  disabled={activeSession?.status === 'active'}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
                >
                  <option value="A">Section A (CSE-3A)</option>
                  <option value="B">Section B (CSE-3B)</option>
                  <option value="C">Section C (CSE-3C)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Session Duration</label>
                <select
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(Number(e.target.value))}
                  disabled={activeSession?.status === 'active'}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
                >
                  <option value={5}>5 Minutes (Quick Check-In)</option>
                  <option value={10}>10 Minutes</option>
                  <option value={15}>15 Minutes (Standard)</option>
                  <option value={30}>30 Minutes</option>
                  <option value={60}>60 Minutes (Full Lecture)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Lecture Topic / Notes</label>
              <input
                type="text"
                value={lectureTopic}
                onChange={(e) => setLectureTopic(e.target.value)}
                disabled={activeSession?.status === 'active'}
                placeholder="e.g. Unit 3: Memory Organization"
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
              />
            </div>

            {!activeSession || activeSession.status === 'closed' ? (
              <button
                type="submit"
                disabled={isCreating}
                className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-semibold rounded-md transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                <Play className="w-4 h-4" />
                <span>{isCreating ? 'Generating QR Code...' : 'Start Attendance Session & Display QR'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCloseSession}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-md transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <AlertCircle className="w-4 h-4" />
                <span>End Active Session Early</span>
              </button>
            )}
          </form>

          {/* Quick Shortcuts */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <button
              onClick={() => onNavigate('faculty-mark')}
              className="text-sky-700 dark:text-sky-400 hover:underline font-medium flex items-center gap-1"
            >
              <span>Switch to Manual Sheet</span>
              <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => onNavigate('faculty-dashboard')}
              className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium"
            >
              Back to Dashboard
            </button>
          </div>
        </div>

        {/* Right Column: Live Session Screen */}
        <div className="lg:col-span-7 space-y-6">
          {activeSession && activeSession.status === 'active' ? (
            <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border-2 border-sky-600 dark:border-sky-500 shadow-md space-y-6 text-center transition-colors">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                    Live Session Active
                  </span>
                </div>
                <div className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span>Time Left: {formatSeconds(timeLeft)}</span>
                </div>
              </div>

              {/* Dynamic QR Code Display */}
              <div className="flex flex-col items-center">
                <div className="p-4 bg-white rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs max-w-xs">
                  {activeSession.qr_data_url ? (
                    <img
                      src={activeSession.qr_data_url}
                      alt="Attendance QR Code"
                      className="w-64 h-64 mx-auto"
                    />
                  ) : (
                    <div className="w-64 h-64 flex items-center justify-center bg-slate-100 text-xs text-slate-400">
                      Generating QR...
                    </div>
                  )}
                </div>
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mt-3">
                  Project this QR code. Students scan via the "Scan QR" button.
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                  Section {activeSession.section} · Session ID: {activeSession.id.slice(0, 8)}
                </p>
              </div>

              {/* Real-time Attendees Progress */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-lg border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                    <span>Real-Time Check-In Count</span>
                  </span>
                  <span className="font-mono text-sm text-sky-700 dark:text-sky-400">
                    {presentCount} / {totalStudents} Students Present
                  </span>
                </div>

                <div className="w-full h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-sky-700 dark:bg-sky-500 transition-all duration-300"
                    style={{
                      width: `${totalStudents > 0 ? (presentCount / totalStudents) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>

              {/* Roster of Present Students */}
              <div className="text-left space-y-2">
                <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Attended Students (Latest Check-Ins)
                </h3>
                <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-xs border border-slate-100 dark:border-slate-800 rounded-md">
                  {attendees.filter((s) => s.status === 'present').length === 0 ? (
                    <div className="p-4 text-center text-slate-400 dark:text-slate-500">Waiting for first student scan...</div>
                  ) : (
                    attendees
                      .filter((s) => s.status === 'present')
                      .map((st) => (
                        <div key={st.student_id} className="p-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span className="font-mono font-medium text-slate-900 dark:text-white">{st.roll_number}</span>
                            <span className="text-slate-600 dark:text-slate-300">{st.name}</span>
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">
                            {st.marked_at || 'Just Now'}
                          </span>
                        </div>
                      ))
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* Standby State */
            <div className="bg-white dark:bg-slate-900 rounded-lg p-10 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col items-center justify-center text-center space-y-4 min-h-[380px] transition-colors">
              <div className="w-16 h-16 rounded-full bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
                <QrCode className="w-8 h-8" />
              </div>
              <div className="max-w-md space-y-1">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Ready to Start Session</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Select your subject, class section, and duration on the left, then click "Start Attendance Session" to project the dynamic QR code on the classroom screen.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
