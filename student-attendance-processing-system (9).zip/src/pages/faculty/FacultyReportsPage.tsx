import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Subject, Student } from '../../types/index.ts';
import { PrintableReport } from '../../components/reports/PrintableReport.tsx';

export const FacultyReportsPage: React.FC = () => {
  const { faculty } = useAuth();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [defaulters, setDefaulters] = useState<any[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadData();
  }, [faculty]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const allSubjs = await api.getSubjects();
      setSubjects(allSubjs);
      if (allSubjs.length > 0) setSelectedSubjectId(allSubjs[0].id);

      const defs = await api.getDefaultersReport();
      setDefaulters(defs);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div className="p-8 text-xs text-slate-500 dark:text-slate-400">Compiling faculty reports...</div>;
  }

  const selectedSubject = subjects.find((s) => s.id === selectedSubjectId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Faculty Course Attendance Report</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Audit summary, student percentage rosters, and flagged defaulter records.
          </p>
        </div>

        <select
          value={selectedSubjectId}
          onChange={(e) => setSelectedSubjectId(e.target.value)}
          className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 text-xs font-medium transition-colors"
        >
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.subject_code} - {s.subject_name}
            </option>
          ))}
        </select>
      </div>

      <PrintableReport
        title={`Faculty Course Audit Report: ${selectedSubject?.subject_code || 'CSE'} - ${selectedSubject?.subject_name || 'Course'}`}
        defaulters={defaulters}
      />
    </div>
  );
};
