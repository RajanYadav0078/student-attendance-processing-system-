import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { AttendanceCorrectionRequest } from '../../types/index.ts';
import {
  HelpCircle,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  Filter,
  ArrowLeft,
  Calendar,
  User,
  BookOpen,
  MessageSquare,
  Check,
  X,
  FileText,
} from 'lucide-react';

interface FacultyRequestsPageProps {
  onNavigate: (view: string) => void;
}

export const FacultyRequestsPage: React.FC<FacultyRequestsPageProps> = ({ onNavigate }) => {
  const [requests, setRequests] = useState<AttendanceCorrectionRequest[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>('pending');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalRequest, setActiveModalRequest] = useState<AttendanceCorrectionRequest | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');
  const [facultyRemarks, setFacultyRemarks] = useState<string>('');
  const [isActioning, setIsActioning] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await api.getFacultyAttendanceRequests();
      setRequests(data || []);
    } catch (e) {
      console.error('Failed to load faculty requests', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const openActionModal = (req: AttendanceCorrectionRequest, type: 'approve' | 'reject') => {
    setActiveModalRequest(req);
    setActionType(type);
    setFacultyRemarks(
      type === 'approve'
        ? 'Physical presence verified in classroom · Recommended for Admin final authorization'
        : 'Discrepancy could not be verified in class roster'
    );
    setAlertMessage(null);
  };

  const handleConfirmAction = async () => {
    if (!activeModalRequest) return;
    setIsActioning(true);
    setAlertMessage(null);

    try {
      let res;
      if (actionType === 'approve') {
        res = await api.facultyVerifyRequest(activeModalRequest.id, facultyRemarks.trim());
      } else {
        res = await api.rejectDisputeRequest(activeModalRequest.id, facultyRemarks.trim());
      }
      setAlertMessage({ type: 'success', text: res.message });
      setActiveModalRequest(null);
      await loadRequests();
    } catch (err: any) {
      setAlertMessage({ type: 'error', text: err.message || 'Failed to update request' });
    } finally {
      setIsActioning(false);
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (statusFilter === 'pending') {
      if (r.status !== 'pending' && r.status !== 'pending_faculty') return false;
    } else if (statusFilter !== 'all' && r.status !== statusFilter) {
      return false;
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchName = r.student_name?.toLowerCase().includes(q);
      const matchRoll = r.roll_number?.toLowerCase().includes(q);
      const matchSub = r.subject_code?.toLowerCase().includes(q) || r.subject_name?.toLowerCase().includes(q);
      const matchReason = r.reason?.toLowerCase().includes(q);
      if (!matchName && !matchRoll && !matchSub && !matchReason) return false;
    }
    return true;
  });

  const pendingFacultyCount = requests.filter((r) => r.status === 'pending' || r.status === 'pending_faculty').length;
  const facultyVerifiedCount = requests.filter((r) => r.status === 'faculty_verified').length;
  const approvedCount = requests.filter((r) => r.status === 'approved').length;
  const rejectedCount = requests.filter((r) => r.status === 'rejected').length;

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'technical_glitch':
        return <span className="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[10px] font-semibold">⚡ Tech Glitch</span>;
      case 'marked_absent_by_mistake':
        return <span className="px-2 py-0.5 rounded bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-[10px] font-semibold">🙋 Absent by Mistake</span>;
      case 'medical_leave':
        return <span className="px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-[10px] font-semibold">🏥 Medical Leave</span>;
      case 'college_duty':
        return <span className="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-[10px] font-semibold">🏆 On-Duty</span>;
      default:
        return <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[10px] font-semibold">📝 Other</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-400 font-semibold mb-1">
            <HelpCircle className="w-4 h-4" />
            <span>Attendance Grievances & Discrepancies</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Student Attendance Requests
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Review student-submitted attendance issues, verify presence or excuse proofs, and approve corrections.
          </p>
        </div>

        <button
          onClick={() => onNavigate('faculty-dashboard')}
          className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Faculty Dashboard</span>
        </button>
      </div>

      {/* Global Alert Notification */}
      {alertMessage && (
        <div
          className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
            alertMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
          }`}
        >
          <span>{alertMessage.text}</span>
          <button onClick={() => setAlertMessage(null)} className="p-0.5">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500 dark:text-slate-400">Total Grievances</div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {requests.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">For your assigned courses</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-amber-200 dark:border-amber-900/60">
          <div className="text-xs text-amber-700 dark:text-amber-400 font-semibold flex items-center justify-between">
            <span>1. Awaiting Review</span>
            <Clock className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {pendingFacultyCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Classroom verification required</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-indigo-200 dark:border-indigo-900/60">
          <div className="text-xs text-indigo-700 dark:text-indigo-400 font-semibold flex items-center justify-between">
            <span>2. Verified by You</span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-700 dark:text-indigo-400 mt-1">
            {facultyVerifiedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">In Admin queue for authorization</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-rose-200 dark:border-rose-900/60">
          <div className="text-xs text-rose-700 dark:text-rose-400 font-semibold flex items-center justify-between">
            <span>Declined</span>
            <XCircle className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-700 dark:text-rose-400 mt-1">
            {rejectedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Feedback provided to student</div>
        </div>
      </div>

      {/* Toolbar Filter */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student name, roll number, or explanation..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium"
          >
            <option value="pending">Awaiting Verification ({pendingFacultyCount})</option>
            <option value="faculty_verified">Faculty Verified ({facultyVerifiedCount})</option>
            <option value="approved">Admin Approved ({approvedCount})</option>
            <option value="rejected">Declined ({rejectedCount})</option>
            <option value="all">All Records ({requests.length})</option>
          </select>
        </div>
      </div>

      {/* Request Review List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <div className="w-6 h-6 border-2 border-sky-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <span className="text-xs text-slate-500">Loading student attendance requests...</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-lg border border-dashed border-slate-200 dark:border-slate-800 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 dark:text-emerald-400 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              {statusFilter === 'pending' ? 'All caught up! No pending requests.' : 'No matching requests found.'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              When students submit attendance correction requests for your classes, they will appear here for one-click verification.
            </p>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              className={`bg-white dark:bg-slate-900 rounded-lg border p-5 shadow-xs transition-colors space-y-3 ${
                req.status === 'pending'
                  ? 'border-amber-300 dark:border-amber-800/80 bg-amber-50/20 dark:bg-amber-950/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs border border-slate-200 dark:border-slate-700">
                    Sec {req.section}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {req.student_name}
                      </span>
                      <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                        ({req.roll_number})
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2">
                      <span className="font-mono font-semibold text-sky-700 dark:text-sky-400">{req.subject_code}</span>
                      <span>·</span>
                      <span>Lecture Date: <strong className="font-mono text-slate-700 dark:text-slate-300">{req.date}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {getCategoryBadge(req.category)}

                  {(req.status === 'pending' || req.status === 'pending_faculty') && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                      <Clock className="w-3 h-3" />
                      <span>Pending Your Verification</span>
                    </span>
                  )}
                  {req.status === 'faculty_verified' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Verified · Awaiting Admin Final Approval</span>
                    </span>
                  )}
                  {req.status === 'approved' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Admin Approved · Record Present</span>
                    </span>
                  )}
                  {req.status === 'rejected' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      <XCircle className="w-3 h-3" />
                      <span>Declined</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Student Claim and Details */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
                <div className="md:col-span-8 space-y-2">
                  <div className="bg-slate-50 dark:bg-slate-850 p-3 rounded-md border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Student's Explanation:
                    </span>
                    <p className="text-slate-800 dark:text-slate-200 leading-relaxed">
                      "{req.reason}"
                    </p>
                  </div>

                  {req.proof_note && (
                    <div className="text-[11px] text-slate-600 dark:text-slate-400 flex items-center gap-1.5 px-1">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Submitted Reference: <strong>{req.proof_note}</strong></span>
                    </div>
                  )}

                  {req.faculty_remarks && (
                    <div className="p-2.5 bg-slate-100 dark:bg-slate-800/80 rounded border border-slate-200 dark:border-slate-700 text-[11px]">
                      <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-0.5">Faculty Feedback:</span>
                      <span className="italic text-slate-600 dark:text-slate-300">"{req.faculty_remarks}"</span>
                    </div>
                  )}

                  {req.admin_remarks && (
                    <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 rounded border border-emerald-200 dark:border-emerald-800 text-[11px]">
                      <span className="font-semibold text-emerald-800 dark:text-emerald-300 block mb-0.5">Admin Authorization:</span>
                      <span className="italic text-emerald-700 dark:text-emerald-400">"{req.admin_remarks}"</span>
                    </div>
                  )}
                </div>

                <div className="md:col-span-4 flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 md:pl-4 space-y-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
                    <div>Submitted: <span className="text-slate-700 dark:text-slate-300 font-medium">{new Date(req.created_at).toLocaleDateString()}</span></div>
                    {req.faculty_verified_at && (
                      <div>Faculty Verified: <span className="text-indigo-600 dark:text-indigo-400 font-medium">{new Date(req.faculty_verified_at).toLocaleDateString()}</span></div>
                    )}
                    {req.resolved_at && (
                      <div>Resolved: <span className="text-slate-700 dark:text-slate-300 font-medium">{new Date(req.resolved_at).toLocaleDateString()}</span></div>
                    )}
                  </div>

                  {/* Actions for Pending */}
                  {req.status === 'pending' || req.status === 'pending_faculty' ? (
                    <div className="flex items-center gap-2 pt-2">
                      <button
                        onClick={() => openActionModal(req, 'approve')}
                        className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Verify & Forward</span>
                      </button>

                      <button
                        onClick={() => openActionModal(req, 'reject')}
                        className="py-2 px-3 bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/40 text-slate-700 hover:text-rose-700 dark:text-slate-300 dark:hover:text-rose-400 border border-slate-200 dark:border-slate-700 rounded-md transition-colors flex items-center justify-center gap-1"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Decline</span>
                      </button>
                    </div>
                  ) : req.status === 'faculty_verified' ? (
                    <div className="p-2.5 rounded bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-[11px] text-indigo-800 dark:text-indigo-300">
                      ✓ Verified by you. Forwarded to Academic Administration for final attendance record authorization.
                    </div>
                  ) : (
                    <div className="text-[11px] text-slate-400 pt-1">
                      Status is final · Attendance registry updated
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Action Confirmation Modal */}
      {activeModalRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                {actionType === 'approve' ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    <span>Verify & Forward to Administration</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 text-rose-600" />
                    <span>Decline Attendance Request</span>
                  </>
                )}
              </h3>
              <button onClick={() => setActiveModalRequest(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded border border-slate-200 dark:border-slate-700 space-y-1">
              <div>Student: <strong className="text-slate-900 dark:text-white">{activeModalRequest.student_name}</strong> ({activeModalRequest.roll_number})</div>
              <div>Subject: <strong className="font-mono text-slate-900 dark:text-white">{activeModalRequest.subject_code}</strong></div>
              <div>Date: <strong className="font-mono text-slate-900 dark:text-white">{activeModalRequest.date}</strong></div>
            </div>

            {actionType === 'approve' && (
              <p className="text-indigo-700 dark:text-indigo-400 text-[11px] leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/30 p-2.5 rounded border border-indigo-100 dark:border-indigo-900/40">
                Verifying this request certifies that the student was physically present or legitimately excused. It will be routed to the <strong>Academic Administration queue</strong> for final registry authorization.
              </p>
            )}

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Faculty Remarks / Verification Note:
              </label>
              <textarea
                rows={3}
                value={facultyRemarks}
                onChange={(e) => setFacultyRemarks(e.target.value)}
                placeholder="Add verification comments visible to student and admin..."
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-sans"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setActiveModalRequest(null)}
                disabled={isActioning}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md font-medium transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmAction}
                disabled={isActioning}
                className={`px-5 py-2 text-white font-semibold rounded-md shadow-sm transition-colors flex items-center gap-1.5 ${
                  actionType === 'approve'
                    ? 'bg-indigo-600 hover:bg-indigo-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                {isActioning ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <span>{actionType === 'approve' ? 'Verify & Forward to Admin' : 'Confirm Decline'}</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
