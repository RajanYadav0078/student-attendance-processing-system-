import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';
import { StatCard } from '../../components/common/StatCard.tsx';
import { SubjectBarChart } from '../../components/charts/SubjectBarChart.tsx';
import { AiFacultyAssistant } from '../../components/attendance/AiFacultyAssistant.tsx';
import { AttendanceCorrectionRequest } from '../../types/index.ts';
import {
  Users,
  BookOpen,
  CalendarCheck,
  AlertTriangle,
  QrCode,
  FileText,
  Clock,
  ArrowRight,
  TrendingUp,
  HelpCircle,
  CheckCircle2,
  Check,
  X,
  MessageSquare,
} from 'lucide-react';

interface FacultyDashboardProps {
  onNavigate: (view: string) => void;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({ onNavigate }) => {
  const { faculty, user } = useAuth();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [requests, setRequests] = useState<AttendanceCorrectionRequest[]>([]);
  const [actioningId, setActioningId] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDashboardData();
      setDashboardData(data);
      const reqs = await api.getFacultyAttendanceRequests().catch(() => []);
      setRequests(reqs || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = async (id: string, action: 'approve' | 'reject') => {
    setActioningId(id);
    setActionFeedback(null);
    try {
      const res = await api.actionAttendanceRequest(
        id,
        action,
        action === 'approve'
          ? 'Approved by instructor · Marked Present'
          : 'Reviewed by instructor · Discrepancy not confirmed'
      );
      setActionFeedback(res.message);
      await loadData();
      setTimeout(() => setActionFeedback(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to update request');
    } finally {
      setActioningId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-slate-200 dark:bg-slate-800 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const assignedSubjects = dashboardData?.assignedSubjects || [];
  const todaySessions = dashboardData?.todaySessions || [];
  const defaulterCount = dashboardData?.defaulterCount || 0;
  const defaulters = dashboardData?.defaulters || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Faculty Profile Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono mb-1">
            <span>Faculty ID: {faculty?.employee_id || 'EMP-CSE-01'}</span>
            <span>·</span>
            <span>{faculty?.department || 'Department of CSE'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Welcome, {faculty?.name || user?.name}
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            Faculty Member · Department of Computer Science & Engineering
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigate('faculty-create-session')}
            className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-2 shadow-sm"
          >
            <QrCode className="w-4 h-4" />
            <span>Generate Attendance QR</span>
          </button>

          <button
            onClick={() => onNavigate('faculty-mark')}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-md border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1.5"
          >
            <CalendarCheck className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span>Manual Sheet</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Assigned Subjects"
          value={assignedSubjects.length}
          subtext="Theory & Lab Courses"
          icon={BookOpen}
        />

        <StatCard
          label="Today's Active Lectures"
          value={todaySessions.length}
          subtext="Sessions scheduled today"
          icon={Clock}
        />

        <StatCard
          label="Average Class Attendance"
          value="82.4%"
          subtext="Across assigned courses"
          icon={TrendingUp}
          highlight
          badge={{ text: 'Healthy', variant: 'success' }}
        />

        <StatCard
          label="Defaulter Students (<75%)"
          value={defaulterCount}
          subtext="Across assigned classes"
          icon={AlertTriangle}
          highlight={defaulterCount > 0}
          badge={{
            text: defaulterCount > 0 ? 'Requires Action' : 'All Clear',
            variant: defaulterCount > 0 ? 'warning' : 'success',
          }}
        />
      </div>

      {/* Subject Attendance Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8">
          <SubjectBarChart
            subjects={assignedSubjects.map((s: any) => ({
              ...s,
              attendance_percentage: s.average_attendance || 80,
            }))}
            threshold={75}
          />
        </div>

        {/* Quick Launch & Control Panel */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4 transition-colors">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Lecture Session Controls</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Quick actions for classroom attendance management</p>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => onNavigate('faculty-create-session')}
              className="w-full p-3 rounded-md border border-sky-200 dark:border-sky-800 bg-sky-50 dark:bg-sky-950/40 text-left hover:bg-sky-100/70 dark:hover:bg-sky-900/50 transition-colors flex items-center justify-between"
            >
              <div>
                <span className="font-semibold text-xs text-sky-900 dark:text-sky-300 block">Start Live QR Session</span>
                <span className="text-[11px] text-sky-700 dark:text-sky-400">Project dynamic expiring code</span>
              </div>
              <QrCode className="w-4 h-4 text-sky-700 dark:text-sky-400" />
            </button>

            <button
              onClick={() => onNavigate('faculty-mark')}
              className="w-full p-3 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between"
            >
              <div>
                <span className="font-semibold text-xs text-slate-800 dark:text-slate-200 block">Open Class Attendance Sheet</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Manual roster & instant undo</span>
              </div>
              <CalendarCheck className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>

            <button
              onClick={() => onNavigate('faculty-history')}
              className="w-full p-3 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between"
            >
              <div>
                <span className="font-semibold text-xs text-slate-800 dark:text-slate-200 block">Session History & Logs</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Review past attendance records</span>
              </div>
              <Clock className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>

            <button
              onClick={() => onNavigate('faculty-requests')}
              className="w-full p-3 rounded-md border border-amber-200 dark:border-amber-800 bg-amber-50/70 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-colors text-left flex items-center justify-between"
            >
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-xs text-amber-900 dark:text-amber-200 block">Student Grievances</span>
                  {requests.filter((r) => r.status === 'pending').length > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-200 dark:bg-amber-800 text-amber-900 dark:text-white font-bold">
                      {requests.filter((r) => r.status === 'pending').length} pending
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-amber-700 dark:text-amber-400">Attendance issues submitted by students</span>
              </div>
              <HelpCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </button>
          </div>

          <div className="text-[11px] text-slate-400 dark:text-slate-500 text-center pt-2 border-t border-slate-100 dark:border-slate-800">
            Attendance Records Synced with Central Database
          </div>
        </div>
      </div>

      {/* Action Toast Feedback */}
      {actionFeedback && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 rounded-lg text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{actionFeedback}</span>
          </div>
          <button onClick={() => setActionFeedback(null)} className="p-0.5 text-emerald-700">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Student Attendance Grievances & Discrepancies Panel */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                <span>Student Attendance Requests & Grievances</span>
              </h2>
              {requests.filter((r) => r.status === 'pending').length > 0 ? (
                <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  {requests.filter((r) => r.status === 'pending').length} Pending Action
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                  All Reviewed
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Review attendance issues submitted by students for technical glitches, absence disputes, or authorized leaves.
            </p>
          </div>

          <button
            onClick={() => onNavigate('faculty-requests')}
            className="text-xs text-sky-700 dark:text-sky-400 hover:text-sky-900 dark:hover:text-sky-300 font-semibold flex items-center gap-1"
          >
            <span>Manage All Requests ({requests.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {requests.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
            No attendance grievances or correction requests have been submitted by students yet.
          </div>
        ) : (
          <div className="space-y-3">
            {requests.slice(0, 4).map((req) => (
              <div
                key={req.id}
                className={`p-4 rounded-lg border text-xs transition-colors space-y-2.5 ${
                  req.status === 'pending'
                    ? 'border-amber-200 dark:border-amber-800/80 bg-amber-50/30 dark:bg-amber-950/20'
                    : 'border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850/50'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 dark:text-white">{req.student_name}</span>
                    <span className="font-mono text-slate-500">({req.roll_number})</span>
                    <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-[10px] font-semibold text-slate-700 dark:text-slate-300">
                      Sec {req.section}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="font-mono font-semibold text-sky-700 dark:text-sky-400">{req.subject_code}</span>
                    <span className="text-slate-400">·</span>
                    <span className="font-mono text-slate-600 dark:text-slate-400">Class: {req.date}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {req.status === 'pending' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                        Pending
                      </span>
                    ) : req.status === 'approved' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                        Approved · Marked Present
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300">
                        Declined
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pt-1">
                  <div className="flex-1 space-y-1">
                    <p className="text-slate-700 dark:text-slate-300 italic">
                      "{req.reason}"
                    </p>
                    {req.proof_note && (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        <span>Reference: <strong>{req.proof_note}</strong></span>
                      </div>
                    )}
                    {req.faculty_remarks && (
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 flex items-center gap-1 font-medium mt-1">
                        <MessageSquare className="w-3 h-3 text-slate-400" />
                        <span>Remarks: {req.faculty_remarks}</span>
                      </div>
                    )}
                  </div>

                  {req.status === 'pending' && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleQuickAction(req.id, 'approve')}
                        disabled={actioningId === req.id}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded font-semibold text-[11px] flex items-center gap-1 transition-colors shadow-2xs"
                      >
                        <Check className="w-3 h-3" />
                        <span>Approve & Mark Present</span>
                      </button>

                      <button
                        onClick={() => handleQuickAction(req.id, 'reject')}
                        disabled={actioningId === req.id}
                        className="px-2.5 py-1.5 bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 text-slate-700 hover:text-rose-700 dark:text-slate-300 rounded text-[11px] flex items-center gap-1 border border-slate-200 dark:border-slate-700 transition-colors"
                      >
                        <X className="w-3 h-3" />
                        <span>Decline</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Defaulter List Preview */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>Flagged Defaulter Students (Under 75% Attendance)</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Students who require attendance warning notices</p>
          </div>
          <button
            onClick={() => onNavigate('faculty-reports')}
            className="text-xs text-sky-700 dark:text-sky-400 hover:text-sky-900 dark:hover:text-sky-300 font-semibold"
          >
            Export Faculty Report
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                <th className="py-2.5 px-3">Roll No</th>
                <th className="py-2.5 px-3">Student Name</th>
                <th className="py-2.5 px-3">Section</th>
                <th className="py-2.5 px-3 text-right">Overall %</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {defaulters.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-4 text-center text-slate-400 dark:text-slate-500">
                    No students currently below the 75% threshold in your assigned sections.
                  </td>
                </tr>
              ) : (
                defaulters.map((d: any, idx: number) => (
                  <tr key={d.student?.id || d.id || idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-2.5 px-3 font-mono font-medium text-slate-900 dark:text-white">{d.student?.roll_number || d.roll_number}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white">{d.student?.name || d.name}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-400">Sec {d.student?.section || d.section}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700 dark:text-rose-400">
                      {d.overall_percentage}%
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="font-semibold text-rose-700 dark:text-rose-400">Attendance Shortage</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Teaching & Attendance Analytics Assistant */}
      <AiFacultyAssistant />
    </div>
  );
};
