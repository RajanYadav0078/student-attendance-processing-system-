import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotification } from '../../context/NotificationContext.tsx';
import { Subject, AttendanceSession } from '../../types/index.ts';
import {
  RotateCcw,
  Save,
  CheckCircle2,
  XCircle,
  Search,
  BookOpen,
  Users,
  ShieldCheck,
  AlertCircle,
  Info,
  Calendar,
  Clock,
} from 'lucide-react';

interface MarkAttendancePageProps {
  onNavigate?: (view: string) => void;
}

export const MarkAttendancePage: React.FC<MarkAttendancePageProps> = ({ onNavigate }) => {
  const { faculty } = useAuth();
  const { showToast } = useNotification();

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');
  const [selectedSection, setSelectedSection] = useState<string>('A');
  const [sessionTopic, setSessionTopic] = useState<string>('Regular Lecture Session');
  const [activeSession, setActiveSession] = useState<AttendanceSession | null>(null);
  const [isLoadingStudents, setIsLoadingStudents] = useState<boolean>(true);

  // Student list for marking
  const [studentRows, setStudentRows] = useState<
    Array<{
      studentId: string;
      rollNumber: string;
      name: string;
      status: 'present' | 'absent';
      remarks: string;
    }>
  >([]);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [isUndoing, setIsUndoing] = useState<boolean>(false);

  useEffect(() => {
    loadSubjects();
  }, []);

  const loadSubjects = async () => {
    try {
      const allSubjs = await api.getSubjects();
      const mySubjs = faculty ? allSubjs.filter((s) => s.faculty_id === faculty.id) : allSubjs;
      const finalSubjs = mySubjs.length > 0 ? mySubjs : allSubjs;
      setSubjects(finalSubjs);
      if (finalSubjs.length > 0) {
        setSelectedSubjectId(finalSubjs[0].id);
        initSession(finalSubjs[0].id, 'A');
      } else {
        setIsLoadingStudents(false);
      }
    } catch (e) {
      console.error(e);
      setIsLoadingStudents(false);
    }
  };

  const initSession = async (subjectId: string, section: string) => {
    setIsLoadingStudents(true);
    try {
      const sess = await api.createSession({
        subjectId,
        section,
        lectureTopic: sessionTopic,
        durationMinutes: 60,
      });
      setActiveSession(sess);

      // Fetch students strictly from database registered by Admin
      const allStudents = await api.getStudents({ section });
      setStudentRows(
        allStudents.map((st) => ({
          studentId: st.id,
          rollNumber: st.roll_number,
          name: st.name,
          status: 'present',
          remarks: '',
        }))
      );
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingStudents(false);
    }
  };

  const handleSubjectOrSectionChange = (subjId: string, sec: string) => {
    setSelectedSubjectId(subjId);
    setSelectedSection(sec);
    initSession(subjId, sec);
  };

  const toggleStudentStatus = (studentId: string) => {
    setStudentRows((prev) =>
      prev.map((s) =>
        s.studentId === studentId
          ? { ...s, status: s.status === 'present' ? 'absent' : 'present' }
          : s
      )
    );
  };

  const handleMarkAllPresent = () => {
    setStudentRows((prev) => prev.map((s) => ({ ...s, status: 'present' })));
    showToast({ type: 'info', message: 'All students set to Present' });
  };

  const handleMarkAllAbsent = () => {
    setStudentRows((prev) => prev.map((s) => ({ ...s, status: 'absent' })));
    showToast({ type: 'info', message: 'All students set to Absent' });
  };

  const handleSaveConfirmed = async () => {
    if (!activeSession) return;
    setIsSaving(true);
    setShowConfirmModal(false);

    try {
      const records = studentRows.map((r) => ({
        studentId: r.studentId,
        status: r.status,
        remarks: r.remarks,
      }));

      const res = await api.saveBulkAttendance(activeSession.id, records);
      showToast({
        type: 'success',
        title: 'Attendance Saved',
        message: `${res.message}. Rollback point created.`,
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Save Failed',
        message: err.message || 'Could not commit attendance records',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleUndo = async () => {
    setIsUndoing(true);
    try {
      const res = await api.undoLatestAttendance(activeSession?.id);
      showToast({
        type: 'success',
        title: 'Attendance Reverted',
        message: res.message,
      });

      if (activeSession) {
        const details = await api.getSessionDetails(activeSession.id);
        if (details.students.length > 0) {
          setStudentRows(
            details.students.map((st) => ({
              studentId: st.student_id,
              rollNumber: st.roll_number,
              name: st.name,
              status: st.status,
              remarks: '',
            }))
          );
        }
      }
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Undo Failed',
        message: err.message || 'Unable to pop undo stack',
      });
    } finally {
      setIsUndoing(false);
    }
  };

  const filteredStudents = studentRows.filter(
    (s) =>
      s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const presentCount = studentRows.filter((s) => s.status === 'present').length;
  const absentCount = studentRows.filter((s) => s.status === 'absent').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* ================================================== */}
      {/* SPECIAL ATTENDANCE ACCESS BLOCK (Mandatory Info)   */}
      {/* ================================================== */}
      <div className="p-4 rounded-lg bg-sky-50 dark:bg-slate-900 border border-sky-200 dark:border-sky-900/60 shadow-xs flex items-start gap-3.5 transition-colors">
        <div className="w-8 h-8 rounded-md bg-sky-700 dark:bg-sky-800 text-white flex items-center justify-center shrink-0 shadow-xs">
          <ShieldCheck className="w-4 h-4" />
        </div>
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-900 dark:text-sky-300">
              Attendance Access
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
              Admin Verified Only
            </span>
          </div>
          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            Only students registered by the Administrator can receive attendance. New students must first be added by the Administrator.
          </p>
        </div>
      </div>

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Batch Attendance Marking</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Conduct roster verification for enrolled students with instant rollback support.
          </p>
        </div>

        {/* Undo & Save Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleUndo}
            disabled={isUndoing}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md border border-slate-200 dark:border-slate-700 transition-colors disabled:opacity-50"
            title="Revert previous attendance changes"
          >
            <RotateCcw className="w-3.5 h-3.5 text-sky-700 dark:text-sky-400" />
            <span>{isUndoing ? 'Reverting...' : 'Undo Latest Entry'}</span>
          </button>

          <button
            onClick={() => setShowConfirmModal(true)}
            disabled={isSaving || studentRows.length === 0}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-md transition-colors shadow-sm disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Attendance</span>
          </button>
        </div>
      </div>

      {/* Control Bar: Subject, Section, Topic */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject</label>
            <select
              value={selectedSubjectId}
              onChange={(e) => handleSubjectOrSectionChange(e.target.value, selectedSection)}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.subject_code} - {s.subject_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Class Section</label>
            <select
              value={selectedSection}
              onChange={(e) => handleSubjectOrSectionChange(selectedSubjectId, e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
            >
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Lecture Topic</label>
            <input
              type="text"
              value={sessionTopic}
              onChange={(e) => setSessionTopic(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium transition-colors"
              placeholder="Lecture Topic"
            />
          </div>
        </div>

        {/* Batch Marking Bar & Search (Only shown when students exist) */}
        {studentRows.length > 0 && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Quick Batch Action:</span>
              <button
                onClick={handleMarkAllPresent}
                className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded font-semibold hover:bg-emerald-100 transition-colors"
              >
                Mark All Present
              </button>
              <button
                onClick={handleMarkAllAbsent}
                className="px-2.5 py-1 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800 rounded font-semibold hover:bg-rose-100 transition-colors"
              >
                Mark All Absent
              </button>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3 font-mono font-medium">
                <span className="text-emerald-700 dark:text-emerald-400">Present: {presentCount}</span>
                <span className="text-rose-700 dark:text-rose-400">Absent: {absentCount}</span>
                <span className="text-slate-600 dark:text-slate-400">Total: {studentRows.length}</span>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search roll no or name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Table / Empty State Container */}
      {isLoadingStudents ? (
        <div className="bg-white dark:bg-slate-900 rounded-lg p-12 text-center border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="w-8 h-8 border-2 border-sky-700 dark:border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs text-slate-500 dark:text-slate-400">Loading section roster...</p>
        </div>
      ) : studentRows.length === 0 ? (
        /* Empty State Card when Admin has registered 0 students */
        <div className="bg-white dark:bg-slate-900 rounded-lg p-12 text-center border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 dark:text-slate-500">
            <Users className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              No registered students available for attendance.
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              No students have been added by Admin yet for Section {selectedSection}. Students added by the Administrator will appear here automatically.
            </p>
            <p className="text-xs font-semibold text-sky-700 dark:text-sky-400 pt-2">
              Please ask the Administrator to add students first.
            </p>
          </div>
        </div>
      ) : (
        /* Students Attendance Table */
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                  <th className="py-3 px-4 w-12 text-center">#</th>
                  <th className="py-3 px-4">Roll Number</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4 text-center">Attendance Status</th>
                  <th className="py-3 px-4 text-center">Toggle Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400 dark:text-slate-500">
                      No students matched your search query "{searchQuery}"
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((row, idx) => (
                    <tr
                      key={row.studentId}
                      className={`transition-colors ${
                        row.status === 'present'
                          ? 'hover:bg-emerald-50/30 dark:hover:bg-emerald-950/20'
                          : 'bg-rose-50/20 dark:bg-rose-950/10 hover:bg-rose-50/40 dark:hover:bg-rose-950/20'
                      }`}
                    >
                      <td className="py-3 px-4 text-center text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 dark:text-white">
                        {row.rollNumber}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900 dark:text-white">{row.name}</td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            row.status === 'present'
                              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                              : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300'
                          }`}
                        >
                          {row.status === 'present' ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Present</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3 h-3" />
                              <span>Absent</span>
                            </>
                          )}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => toggleStudentStatus(row.studentId)}
                          className={`px-3 py-1 rounded text-[11px] font-semibold border transition-colors ${
                            row.status === 'present'
                              ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800 hover:bg-rose-100'
                              : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                          }`}
                        >
                          Mark {row.status === 'present' ? 'Absent' : 'Present'}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-lg max-w-sm w-full p-5 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Confirm Attendance Submission</h3>
            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-2">
              <p>You are about to save the attendance roster for this session:</p>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded font-mono text-[11px] space-y-1">
                <div>Section: {selectedSection}</div>
                <div>Present: {presentCount}</div>
                <div>Absent: {absentCount}</div>
                <div>Total Enrolled: {studentRows.length}</div>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                A snapshot will be recorded. You can undo this action at any time using the Undo button.
              </p>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveConfirmed}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded shadow-xs"
              >
                Confirm & Commit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
