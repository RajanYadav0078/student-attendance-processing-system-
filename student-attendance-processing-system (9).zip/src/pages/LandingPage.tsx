import React, { useState, useEffect } from 'react';
import {
  Cpu,
  QrCode,
  ArrowRight,
  CheckCircle2,
  ShieldCheck,
  Zap,
  GraduationCap,
  School,
  Lock,
  Mail,
  User,
  AlertCircle,
  Building2,
  Key,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { useNotification } from '../context/NotificationContext.tsx';

interface LandingPageProps {
  onNavigate: (view: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { showToast } = useNotification();

  // Admin status check
  const [hasAdmin, setHasAdmin] = useState<boolean | null>(null);
  const [adminCount, setAdminCount] = useState<number>(0);
  const [isCheckingAdmin, setIsCheckingAdmin] = useState<boolean>(true);

  // Form state for creating first admin
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminConfirmPassword, setAdminConfirmPassword] = useState('');
  const [isSubmittingAdmin, setIsSubmittingAdmin] = useState(false);
  const [adminFormError, setAdminFormError] = useState('');

  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    setIsCheckingAdmin(true);
    try {
      const res = await api.getAdminStatus();
      setHasAdmin(res.hasAdmin);
      setAdminCount(res.count);
    } catch (e) {
      console.error('Failed to query admin status', e);
      // Default to true for safety
      setHasAdmin(true);
    } finally {
      setIsCheckingAdmin(false);
    }
  };

  const handleCreateAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminFormError('');

    if (!adminName.trim() || !adminEmail.trim() || !adminPassword) {
      setAdminFormError('All fields are required.');
      return;
    }

    if (adminPassword !== adminConfirmPassword) {
      setAdminFormError('Passwords do not match. Please re-enter.');
      return;
    }

    if (adminPassword.length < 6) {
      setAdminFormError('Password must be at least 6 characters.');
      return;
    }

    setIsSubmittingAdmin(true);
    try {
      const res = await api.setupAdmin({
        name: adminName.trim(),
        email: adminEmail.trim(),
        password: adminPassword,
      });

      showToast({
        type: 'success',
        title: 'Administrator Created',
        message: 'Primary Administrator account configured. Redirecting to Admin Dashboard...',
      });

      setHasAdmin(true);
      setAdminCount(1);
      setTimeout(() => {
        onNavigate('admin-dashboard');
      }, 500);
    } catch (err: any) {
      setAdminFormError(err.message || 'Failed to create administrator account.');
      showToast({
        type: 'error',
        title: 'Setup Failed',
        message: err.message || 'Could not configure administrator.',
      });
    } finally {
      setIsSubmittingAdmin(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 py-12 sm:py-20 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-sky-700 dark:text-sky-400">
                <span>College Attendance Management Platform</span>
                <span aria-hidden="true">·</span>
                <span>Department of Computer Science & Engineering</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-950 dark:text-white text-balance leading-tight">
                Student Attendance Processing System
              </h1>

              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                A digital attendance management platform engineered for students, faculty, and academic administrators.
                Features real-time dynamic QR code scanning, instant 75% eligibility calculation, manual batch roster marking,
                and centralized administrator controls.
              </p>

              {/* Four Portal Quick Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onNavigate('login-student')}
                  className="px-4 py-2.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2 border border-slate-700 dark:border-slate-600"
                >
                  <GraduationCap className="w-4 h-4 text-sky-400" />
                  <span>Student Login</span>
                </button>

                <button
                  onClick={() => onNavigate('login-faculty')}
                  className="px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2"
                >
                  <School className="w-4 h-4" />
                  <span>Faculty Login</span>
                </button>

                <button
                  onClick={() => onNavigate('login-admin')}
                  className="px-4 py-2.5 bg-slate-800 dark:bg-sky-900/60 hover:bg-slate-900 dark:hover:bg-sky-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2 border border-slate-700 dark:border-sky-700"
                >
                  <ShieldCheck className="w-4 h-4 text-sky-300" />
                  <span>Institution/Admin Login</span>
                </button>

                <button
                  onClick={() => onNavigate('register-institution')}
                  className="px-4.5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2 border border-emerald-600 shadow-emerald-900/10"
                >
                  <Building2 className="w-4 h-4 text-emerald-200" />
                  <span>Register Your Institution</span>
                </button>
              </div>

              {/* Default Password Quick Access Banner */}
              <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 border border-sky-200/90 dark:border-sky-800 text-xs text-sky-900 dark:text-sky-200 shadow-2xs">
                <Key className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                <span className="leading-snug">
                  <strong>Easy Access:</strong> Default password for all student, faculty & admin accounts is{' '}
                  <code className="font-mono font-bold bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded border border-sky-300 dark:border-sky-700 text-sky-800 dark:text-sky-300">
                    password123
                  </code>
                  {' '}(with 1-click login on login portal).
                </span>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-6 text-xs text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  75% Attendance Threshold
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  Time-Limited Dynamic QR
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  Single Database Source of Truth
                </span>
              </div>
            </div>

            {/* Right Column: Hero Visual Asset */}
            <div className="lg:col-span-5 relative">
              <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md bg-slate-900 aspect-16/10 relative">
                <img
                  src="/src/assets/images/hero_campus_tech_1790872560204.jpg"
                  alt="University Campus Laboratory"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent flex flex-col justify-end p-5 text-white">
                  <div className="text-xs font-mono text-sky-400">Campus Attendance Network</div>
                  <div className="text-sm font-semibold mt-0.5">Automated Real-Time Check-In Processing</div>
                  <div className="text-[11px] text-slate-300 mt-1">
                    Dynamic QR Validation · Defaulter Rosters · Official Reports
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================================================== */}
      {/* ADMINISTRATOR SETUP SECTION (Visually Separated)   */}
      {/* ================================================== */}
      <section className="py-12 bg-sky-50/50 dark:bg-slate-900/40 border-b border-sky-100 dark:border-slate-800 transition-colors">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-sky-200 dark:border-slate-800 shadow-md overflow-hidden transition-colors">
            {/* Section Header */}
            <div className="p-6 bg-slate-900 dark:bg-slate-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-sky-700 flex items-center justify-center shrink-0 shadow-sm">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-base font-bold tracking-tight">
                    {hasAdmin ? 'Administrator Setup' : 'Create First Administrator'}
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {hasAdmin
                      ? 'System administrator credentials and governance access.'
                      : 'Configure the initial administrator account to initialize student records.'}
                  </p>
                </div>
              </div>

              {hasAdmin && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Admin Configured ({adminCount})</span>
                </span>
              )}
            </div>

            {/* Section Content */}
            <div className="p-6 sm:p-8">
              {isCheckingAdmin ? (
                <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
                  Checking institutional administrator status...
                </div>
              ) : hasAdmin ? (
                /* Protected State when Admin already exists */
                <div className="space-y-4">
                  <div className="flex items-start gap-3 p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs">
                    <AlertCircle className="w-4 h-4 text-sky-700 dark:text-sky-400 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">
                        Administrator account already exists.
                      </p>
                      <p className="text-slate-600 dark:text-slate-400">
                        Please log in as an authorized Administrator to register students, assign classes, or manage additional administrator accounts.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                    <button
                      onClick={() => onNavigate('login-admin')}
                      className="w-full sm:w-auto px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Log In as Administrator</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-1" />
                    </button>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      Additional administrators can be created via Admin Console → Admin Management.
                    </span>
                  </div>
                </div>
              ) : (
                /* Setup State when NO Admin exists */
                <div className="space-y-6">
                  <div className="p-3.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs">
                    <p className="font-semibold">Initial Setup Required:</p>
                    <p className="mt-0.5">
                      No administrator is currently provisioned. Create the first administrator account to begin registering students and configuring courses.
                    </p>
                  </div>

                  {adminFormError && (
                    <div className="p-3 rounded-md bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 text-xs">
                      {adminFormError}
                    </div>
                  )}

                  <form onSubmit={handleCreateAdminSubmit} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Full Name
                        </label>
                        <div className="relative">
                          <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            required
                            value={adminName}
                            onChange={(e) => setAdminName(e.target.value)}
                            placeholder="e.g. Dr. S. K. Raman"
                            className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Institutional Email Address
                        </label>
                        <div className="relative">
                          <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="email"
                            required
                            value={adminEmail}
                            onChange={(e) => setAdminEmail(e.target.value)}
                            placeholder="admin@university.edu"
                            className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Password
                        </label>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="password"
                            required
                            value={adminPassword}
                            onChange={(e) => setAdminPassword(e.target.value)}
                            placeholder="Minimum 6 characters"
                            className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Confirm Password
                        </label>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="password"
                            required
                            value={adminConfirmPassword}
                            onChange={(e) => setAdminConfirmPassword(e.target.value)}
                            placeholder="Re-enter password"
                            className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between">
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        This creates the primary system administrator account.
                      </span>

                      <button
                        type="submit"
                        disabled={isSubmittingAdmin}
                        className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors flex items-center gap-2 disabled:opacity-50"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>{isSubmittingAdmin ? 'Creating Administrator...' : 'Create Admin'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Role Portals Section */}
      <section className="py-12 bg-slate-100 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Role Portal Access</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
              Select your designated portal to access role-specific dashboards and features.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Student Card */}
            <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-sky-300 dark:hover:border-sky-700 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">Student Access</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Student Portal</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                  Track individual course attendance tallies, monitor threshold compliance status, scan camera QR codes for active sessions, and export formal PDF transcripts.
                </p>
              </div>
              <button
                onClick={() => onNavigate('login-student')}
                className="mt-6 w-full py-2 bg-slate-900 dark:bg-sky-700 hover:bg-sky-700 dark:hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Student Login</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Faculty Card */}
            <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-sky-300 dark:hover:border-sky-700 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
                    <School className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">Faculty Access</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Faculty Portal</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                  Broadcast time-limited QR codes to classroom projectors, manage interactive manual attendance sheets, revert unintended entries, and identify course defaulters.
                </p>
              </div>
              <button
                onClick={() => onNavigate('login-faculty')}
                className="mt-6 w-full py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Faculty Login</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Admin Card */}
            <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-sky-300 dark:hover:border-sky-700 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">Admin Access</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Admin Console</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                  Exclusive student creation authority, faculty assignment, course registry, institutional threshold configuration, and complete audit reports.
                </p>
              </div>
              <button
                onClick={() => onNavigate('login-admin')}
                className="mt-6 w-full py-2 bg-slate-900 dark:bg-sky-700 hover:bg-sky-700 dark:hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Admin Login</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Pillars */}
      <section className="py-16 bg-white dark:bg-slate-900 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-700 dark:text-sky-400">Core Capabilities</span>
            <h2 className="text-2xl font-bold text-slate-950 dark:text-white mt-1">Engineered for Academic Integrity</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
              Optical verification, proxy rejection, and instant attendance compliance calculation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-3">
              <div className="w-9 h-9 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-sky-700 dark:text-sky-400">
                <QrCode className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Time-Limited Dynamic QR</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Tokens automatically expire after configurable duration windows, preventing proxy check-ins or screenshot sharing.
              </p>
            </div>

            <div className="p-5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-3">
              <div className="w-9 h-9 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-sky-700 dark:text-sky-400">
                <Cpu className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Real-Time Attendance Math</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Percentage calculations automatically tag students with compliance flags against the institutional 75% cutoff.
              </p>
            </div>

            <div className="p-5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-3">
              <div className="w-9 h-9 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-sky-700 dark:text-sky-400">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Batch Marking & Instant Undo</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Faculty can mark entire sections with one click and rollback recent changes using session undo state management.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-slate-900 dark:bg-slate-950 text-slate-400 py-8 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="font-semibold text-white">Student Attendance Processing System</span>
            <div className="text-[11px] text-slate-500">
              Department of Computer Science & Engineering
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">Home</button>
            <button onClick={() => onNavigate('login')} className="hover:text-white transition-colors">Portal Login</button>
          </div>
        </div>
      </footer>
    </div>
  );
};
