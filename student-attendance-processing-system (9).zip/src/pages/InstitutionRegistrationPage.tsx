import React, { useState } from 'react';
import {
  Building2,
  ShieldCheck,
  Globe,
  Mail,
  Lock,
  User,
  Phone,
  MapPin,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Copy,
  Server,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { Institution, InstitutionType } from '../types/index.ts';
import { useNotification } from '../context/NotificationContext.tsx';

interface InstitutionRegistrationPageProps {
  onNavigate: (view: string) => void;
}

export const InstitutionRegistrationPage: React.FC<InstitutionRegistrationPageProps> = ({ onNavigate }) => {
  const { showToast } = useNotification();

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    type: 'college' as InstitutionType,
    affiliation: '',
    aishe_code: '',
    website: '',
    address: '',
    city: '',
    state: '',
    country: 'India',
    domain: '',
    admin_name: '',
    admin_designation: 'Principal / Academic Director',
    official_contact: '',
    official_email: '',
    desired_username: 'admin',
    password: 'password123',
    confirm_password: 'password123',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [formError, setFormError] = useState('');

  // Post-Registration State
  const [registeredInstitution, setRegisteredInstitution] = useState<Institution | null>(null);
  const [adminEmailIdentity, setAdminEmailIdentity] = useState<string>('');
  const [verificationInputToken, setVerificationInputToken] = useState<string>('');
  const [isVerifyingDomain, setIsVerifyingDomain] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (formError) setFormError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Validation
    if (!formData.name.trim()) return setFormError('Institution name is required.');
    if (!formData.address.trim() || !formData.city.trim() || !formData.state.trim()) {
      return setFormError('Full institutional address with city and state is required.');
    }
    if (!formData.domain.trim()) return setFormError('Official institution domain is required (e.g. niet.co.in).');
    if (!formData.admin_name.trim()) return setFormError('Administrator / Principal name is required.');
    if (!formData.official_email.trim()) return setFormError('Official contact email is required.');
    if (!formData.password) return setFormError('Admin password is required.');
    if (formData.password.length < 6) return setFormError('Password must be at least 6 characters.');
    if (formData.password !== formData.confirm_password) {
      return setFormError('Passwords do not match. Please re-enter.');
    }

    // Clean domain
    const cleanDomain = formData.domain.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');

    setIsLoading(true);
    try {
      const res = await api.registerInstitution({
        ...formData,
        domain: cleanDomain,
      });

      setRegisteredInstitution(res.institution);
      setAdminEmailIdentity(res.institution.institutional_admin_email);
      setVerificationInputToken(res.institution.verification_token);

      showToast({
        type: 'success',
        title: 'Institution Registered',
        message: `${res.institution.name} enrolled. Domain verification initiated.`,
      });
    } catch (err: any) {
      setFormError(err.message || 'Registration failed. Please check form values.');
      showToast({
        type: 'error',
        title: 'Registration Error',
        message: err.message || 'Could not register institution.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyDomain = async () => {
    if (!registeredInstitution) return;
    setIsVerifyingDomain(true);
    try {
      const res = await api.verifyDomain(verificationInputToken);
      setRegisteredInstitution(res.institution);
      showToast({
        type: 'success',
        title: 'Domain Verified!',
        message: `Ownership of ${res.institution.domain} confirmed. Institutional administrator credentials activated.`,
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Verification Failed',
        message: err.message || 'DNS TXT verification record check failed.',
      });
    } finally {
      setIsVerifyingDomain(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 py-10 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <button onClick={() => onNavigate('landing')} className="hover:underline flex items-center gap-1">
            Home
          </button>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="font-semibold text-slate-900 dark:text-white">Institution Registration</span>
        </div>

        {/* Success Modal / Banner when Institution Registered */}
        {registeredInstitution ? (
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-sky-200 dark:border-sky-900 shadow-md p-6 sm:p-8 space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-sky-100 dark:bg-sky-950 flex items-center justify-center shrink-0 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-400">
                <Building2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 uppercase tracking-wider font-mono">
                    {registeredInstitution.verification_status === 'verified' ? 'Verified Domain' : 'Pending Domain Verification'}
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-950 dark:text-white mt-1">
                  {registeredInstitution.name}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Official Domain: <span className="font-mono text-sky-700 dark:text-sky-400 font-semibold">{registeredInstitution.domain}</span>
                </p>
              </div>
            </div>

            {/* Generated Institutional Email Identity Card */}
            <div className="p-4 sm:p-5 rounded-lg bg-sky-50 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-sky-900 dark:text-sky-200 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                  Institutional Administrator Email Identity
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-sky-100 dark:bg-sky-900 text-sky-800 dark:text-sky-300">
                  {registeredInstitution.verification_status === 'verified' ? 'Active' : 'Pending Domain Verification'}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-3 rounded-md border border-sky-200 dark:border-slate-800 font-mono text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center justify-between">
                <span>{adminEmailIdentity}</span>
                <button
                  onClick={() => copyToClipboard(adminEmailIdentity)}
                  className="text-xs text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 font-sans"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Copy Email
                </button>
              </div>

              {/* Crucial Mailbox Distinction Disclaimer */}
              <div className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-400 pt-1">
                <Info className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Email Identity vs Actual Mailbox:</strong> The institutional administrator email identity has been generated for platform authentication. No real email mailbox is simulated until Google Workspace, Microsoft 365, or an SMTP mail server is configured under Admin Email Settings.
                </p>
              </div>
            </div>

            {/* Domain Verification Section */}
            <div className="p-5 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                    Domain Ownership Verification
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    To activate your institutional account, verify ownership of your institution domain ({registeredInstitution.domain}).
                  </p>
                </div>
                {registeredInstitution.verification_status === 'verified' && (
                  <span className="flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-md border border-emerald-200 dark:border-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Verified
                  </span>
                )}
              </div>

              {registeredInstitution.verification_status !== 'verified' ? (
                <div className="space-y-3">
                  <div className="bg-white dark:bg-slate-900 p-3 rounded-md border border-slate-200 dark:border-slate-700">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-1 font-mono uppercase">
                      Required DNS TXT Record:
                    </div>
                    <div className="flex items-center justify-between font-mono text-xs sm:text-sm font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 p-2 rounded">
                      <span className="break-all">{registeredInstitution.verification_token}</span>
                      <button
                        onClick={() => copyToClipboard(registeredInstitution.verification_token)}
                        className="ml-2 text-xs text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 shrink-0 font-sans"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedToken ? 'Copied!' : 'Copy'}
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
                    <button
                      onClick={handleVerifyDomain}
                      disabled={isVerifyingDomain}
                      className="w-full sm:w-auto px-5 py-2.5 bg-sky-700 hover:bg-sky-800 disabled:opacity-50 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-2 shadow-sm"
                    >
                      {isVerifyingDomain ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Checking DNS TXT Record...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Verify Domain</span>
                        </>
                      )}
                    </button>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      Simulation Mode: Instant validation against domain token registry
                    </span>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-md border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Domain verified successfully! You can now access the full Institution Admin Console.</span>
                </div>
              )}
            </div>

            {/* Dashboard Redirect Action */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => onNavigate('login-admin')}
                className="text-xs text-slate-600 dark:text-slate-400 hover:underline"
              >
                Return to Portal Login
              </button>

              <button
                onClick={() => onNavigate('admin-dashboard')}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-sky-700 dark:hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-2 shadow-sm"
              >
                <span>Launch Institution Admin Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Registration Form */
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-md overflow-hidden transition-colors">
            {/* Header */}
            <div className="p-6 sm:p-8 bg-slate-900 text-white border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-sky-700 flex items-center justify-center shrink-0 shadow-sm">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight">Register Your Institution</h1>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Enroll your college, university, or institute on the central attendance platform
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-8">
              {formError && (
                <div className="p-3.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* 1. Institution Information */}
              <div className="space-y-4">
                <div className="border-b border-slate-200 dark:border-slate-800 pb-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] font-mono text-sky-700 dark:text-sky-400">
                    1. Institution Information
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Institution / College Name <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. Noida Institute of Engineering and Technology"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Institution Type <span className="text-rose-600">*</span>
                    </label>
                    <select
                      name="type"
                      value={formData.type}
                      onChange={handleChange}
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    >
                      <option value="college">College</option>
                      <option value="university">University</option>
                      <option value="institute">Institute</option>
                      <option value="school">School</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      University / Affiliation Name
                    </label>
                    <input
                      type="text"
                      name="affiliation"
                      value={formData.affiliation}
                      onChange={handleChange}
                      placeholder="e.g. Dr. A.P.J. Abdul Kalam Technical University"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      AISHE / Institution ID (Optional)
                    </label>
                    <input
                      type="text"
                      name="aishe_code"
                      value={formData.aishe_code}
                      onChange={handleChange}
                      placeholder="e.g. C-46141"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Institution Website
                    </label>
                    <input
                      type="url"
                      name="website"
                      value={formData.website}
                      onChange={handleChange}
                      placeholder="https://www.niet.co.in"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Institution Address <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="19, Knowledge Park-II, Institutional Area"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      City <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                      placeholder="Greater Noida"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      State <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="state"
                      value={formData.state}
                      onChange={handleChange}
                      placeholder="Uttar Pradesh"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Country <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="country"
                      value={formData.country}
                      onChange={handleChange}
                      placeholder="India"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* 2. Official Institution Domain */}
              <div className="space-y-4">
                <div className="border-b border-slate-200 dark:border-slate-800 pb-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] font-mono text-sky-700 dark:text-sky-400">
                    2. Official Institution Domain
                  </h3>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Official Institution Domain <span className="text-rose-600">*</span>
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      name="domain"
                      value={formData.domain}
                      onChange={handleChange}
                      placeholder="e.g. niet.co.in or abcuniversity.edu or example.ac.in"
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    All institutional email addresses for faculty, students, and administrators will be formulated based on this domain (e.g. admin@{formData.domain || 'domain.edu'}).
                  </p>
                </div>
              </div>

              {/* 3. Authorized Person */}
              <div className="space-y-4">
                <div className="border-b border-slate-200 dark:border-slate-800 pb-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] font-mono text-sky-700 dark:text-sky-400">
                    3. Authorized Person
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Administrator / Principal Name <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="admin_name"
                      value={formData.admin_name}
                      onChange={handleChange}
                      placeholder="e.g. Rajan Yadav"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Designation
                    </label>
                    <input
                      type="text"
                      name="admin_designation"
                      value={formData.admin_designation}
                      onChange={handleChange}
                      placeholder="Principal / Academic Director"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Official Contact Number
                    </label>
                    <input
                      type="tel"
                      name="official_contact"
                      value={formData.official_contact}
                      onChange={handleChange}
                      placeholder="+91 98765 43210"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Official Email Address <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="email"
                      name="official_email"
                      value={formData.official_email}
                      onChange={handleChange}
                      placeholder="rajan.yadav@example.com"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* 4. Administrator Account */}
              <div className="space-y-4">
                <div className="border-b border-slate-200 dark:border-slate-800 pb-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] font-mono text-sky-700 dark:text-sky-400">
                    4. Administrator Account Credentials
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Desired Admin Username
                    </label>
                    <input
                      type="text"
                      name="desired_username"
                      value={formData.desired_username}
                      onChange={handleChange}
                      placeholder="admin"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Email identity: {formData.desired_username || 'admin'}@{formData.domain || 'domain.edu'}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Password <span className="text-rose-600">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, password: 'password123', confirm_password: 'password123' })}
                        className="text-[10px] text-sky-700 dark:text-sky-400 hover:underline"
                      >
                        Default: password123
                      </button>
                    </div>
                    <input
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block mt-1">
                      Pre-filled with default password "password123"
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Confirm Password <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="password"
                      name="confirm_password"
                      value={formData.confirm_password}
                      onChange={handleChange}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onNavigate('landing')}
                  className="text-xs text-slate-600 dark:text-slate-400 hover:underline"
                >
                  Cancel & Return
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 disabled:opacity-50 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-2 shadow-sm"
                >
                  {isLoading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Registering Institution...</span>
                    </>
                  ) : (
                    <>
                      <Building2 className="w-4 h-4" />
                      <span>Register Institution</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
