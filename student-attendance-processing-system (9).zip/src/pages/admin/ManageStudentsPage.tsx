import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { Student, Institution } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';
import {
  GraduationCap,
  Plus,
  Search,
  Edit2,
  Trash2,
  Radio,
  CheckCircle2,
  AlertTriangle,
  X,
  Users,
  ShieldCheck,
  UserCheck,
  Mail,
  Sparkles,
  Info,
} from 'lucide-react';

export const ManageStudentsPage: React.FC = () => {
  const { showToast } = useNotification();
  const [students, setStudents] = useState<Student[]>([]);
  const [institution, setInstitution] = useState<Institution | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sectionFilter, setSectionFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Modal States
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    roll_number: '',
    email: '',
    institutional_email: '',
    branch: 'Computer Science & Engineering',
    semester: 3,
    section: 'A',
    student_id: '',
    rfid_id: '',
    password: 'password123',
  });

  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [studentsData, instData] = await Promise.all([
        api.getStudents(),
        api.getCurrentInstitution().catch(() => null),
      ]);
      setStudents(studentsData);
      setInstitution(instData);
    } catch (e: any) {
      showToast({ type: 'error', message: e.message || 'Failed to load students' });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      roll_number: '',
      email: '',
      institutional_email: '',
      branch: 'Computer Science & Engineering',
      semester: 3,
      section: 'A',
      student_id: '',
      rfid_id: '',
      password: 'password123',
    });
    setFormError('');
  };

  const handleGenerateInstitutionalEmail = () => {
    if (!formData.name.trim()) {
      setFormError('Please enter the Student Full Name first to generate institutional email.');
      return;
    }
    const domain = institution?.domain || 'college.ac.in';
    const clean = formData.name.trim().toLowerCase().replace(/\s+/g, '.').replace(/[^a-z0-9.]/g, '');
    const generated = `${clean}@${domain}`;
    setFormData((prev) => ({ ...prev, institutional_email: generated }));
    showToast({
      type: 'info',
      title: 'Institutional Email Generated',
      message: `Formulated ${generated} based on domain ${domain}.`,
    });
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // 1. Validate required fields
    if (!formData.name.trim()) {
      setFormError('Student Name is required.');
      return;
    }
    if (!formData.roll_number.trim()) {
      setFormError('Roll Number is required.');
      return;
    }
    if (!formData.email.trim()) {
      setFormError('Student personal email address is required.');
      return;
    }

    // 2. Check local uniqueness for instant feedback
    const rollTrimmed = formData.roll_number.trim().toLowerCase();
    if (students.some((s) => s.roll_number.toLowerCase() === rollTrimmed)) {
      setFormError(`A student with Roll Number "${formData.roll_number}" already exists in this institution.`);
      return;
    }

    const emailTrimmed = formData.email.trim().toLowerCase();
    if (students.some((s) => s.email.toLowerCase() === emailTrimmed)) {
      setFormError(`A student with Email "${formData.email}" already exists.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const newSt = await api.addStudent({
        name: formData.name.trim(),
        roll_number: formData.roll_number.trim().toUpperCase(),
        email: formData.email.trim().toLowerCase(),
        institutional_email: formData.institutional_email.trim() || undefined,
        branch: formData.branch,
        semester: Number(formData.semester),
        section: formData.section,
        rfid_id: formData.rfid_id.trim() || undefined,
        password: formData.password || 'student123',
      });

      showToast({
        type: 'success',
        title: 'Student Created',
        message: `Student ${newSt.name} (${newSt.roll_number}) enrolled in Section ${newSt.section}.`,
      });

      setShowAddModal(false);
      resetForm();
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create student. Please verify input data.');
      showToast({
        type: 'error',
        title: 'Enrollment Error',
        message: err.message || 'Could not enroll student.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    setFormError('');

    if (!formData.name.trim() || !formData.email.trim()) {
      setFormError('Name and email are required.');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.updateStudent(selectedStudent.id, {
        name: formData.name.trim(),
        email: formData.email.trim().toLowerCase(),
        institutional_email: formData.institutional_email.trim() || undefined,
        branch: formData.branch,
        semester: Number(formData.semester),
        section: formData.section,
        rfid_id: formData.rfid_id.trim(),
      });

      showToast({
        type: 'success',
        title: 'Student Updated',
        message: `Student profile updated successfully.`,
      });

      setShowEditModal(false);
      setSelectedStudent(null);
      resetForm();
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to update student.');
      showToast({
        type: 'error',
        title: 'Update Error',
        message: err.message || 'Could not update student.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (studentId: string, studentName: string) => {
    if (!window.confirm(`Are you sure you want to permanently remove student ${studentName}? All associated attendance logs will be deleted.`)) {
      return;
    }

    try {
      await api.deleteStudent(studentId);
      showToast({
        type: 'info',
        title: 'Student Removed',
        message: `Student ${studentName} removed from the institution database.`,
      });
      loadData();
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Deletion Failed',
        message: err.message || 'Could not delete student.',
      });
    }
  };

  const openEditModal = (st: Student) => {
    setSelectedStudent(st);
    setFormData({
      name: st.name,
      roll_number: st.roll_number,
      email: st.email,
      institutional_email: st.institutional_email || '',
      branch: st.branch,
      semester: st.semester,
      section: st.section,
      student_id: st.id,
      rfid_id: st.rfid_id || '',
      password: '',
    });
    setFormError('');
    setShowEditModal(true);
  };

  // Filter students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.roll_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.rfid_id && s.rfid_id.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (s.institutional_email && s.institutional_email.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSection = sectionFilter === '' || s.section === sectionFilter;
    return matchesSearch && matchesSection;
  });

  const mailboxStatus = institution?.mailbox_status || 'pending';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono mb-1">
            <span>Institution Administration</span>
            <span>·</span>
            <span>{institution?.name || 'Student Enrollment Database'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Manage Students Directory
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Administer student enrollment records, sections, institutional email identities, and RFID smart card identifiers.
          </p>
        </div>

        {/* Prominent + Add New Student Button */}
        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add New Student</span>
        </button>
      </div>

      {/* Admin Authority Banner */}
      <div className="p-3.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 flex items-center justify-between text-xs text-sky-900 dark:text-sky-200">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-sky-700 dark:text-sky-400 shrink-0" />
          <span>
            <strong>Institution Admin Exclusive Authority:</strong> Only administrators can enroll students. Students created here automatically belong to <strong>{institution?.name || 'this institution'}</strong> and appear across faculty rosters, attendance sheets, and analytics.
          </span>
        </div>
      </div>

      {/* Toolbar */}
      {students.length > 0 && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center gap-3 text-xs transition-colors">
          <div className="relative flex-1 w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, roll number, email, or RFID UID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
            />
          </div>

          <select
            value={sectionFilter}
            onChange={(e) => setSectionFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 w-full sm:w-48 transition-colors"
          >
            <option value="">All Sections</option>
            <option value="A">Section A</option>
            <option value="B">Section B</option>
            <option value="C">Section C</option>
            <option value="D">Section D</option>
          </select>
        </div>
      )}

      {/* Table / Empty State Container */}
      {isLoading ? (
        <div className="bg-white dark:bg-slate-900 rounded-lg p-12 text-center border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="w-8 h-8 border-2 border-sky-700 dark:border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs text-slate-500 dark:text-slate-400">Loading student roster...</p>
        </div>
      ) : students.length === 0 ? (
        /* Empty State Card when 0 students exist (Requirement 11) */
        <div className="bg-white dark:bg-slate-900 rounded-lg p-12 text-center border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 dark:text-slate-500">
            <Users className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-sm mx-auto">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              No students added yet.
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              The student directory is currently empty. Add your first student to configure class rosters and enable faculty attendance marking.
            </p>
          </div>
          <div className="pt-2">
            <button
              onClick={() => {
                resetForm();
                setShowAddModal(true);
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add First Student</span>
            </button>
          </div>
        </div>
      ) : (
        /* Student Table */
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                  <th className="py-3 px-4">Roll Number</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Institutional Email Identity</th>
                  <th className="py-3 px-4">Section</th>
                  <th className="py-3 px-4">Card ID</th>
                  <th className="py-3 px-4 text-right">Attendance %</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400 dark:text-slate-500">
                      No students matched the filter query.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((st) => (
                    <tr key={st.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 dark:text-white">
                        {st.roll_number}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">{st.name}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">{st.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        {st.institutional_email ? (
                          <div className="space-y-0.5">
                            <span className="font-mono text-xs text-sky-700 dark:text-sky-400 block font-medium">
                              {st.institutional_email}
                            </span>
                            <span className="inline-flex items-center text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                              Status: {mailboxStatus === 'active' ? 'Active' : 'Pending'}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Not generated</span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">Sec {st.section}</td>
                      <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                        {st.rfid_id ? (
                          <span className="flex items-center gap-1">
                            <Radio className="w-3 h-3 text-sky-600 dark:text-sky-400" />
                            <span>{st.rfid_id}</span>
                          </span>
                        ) : (
                          <span className="text-slate-400 dark:text-slate-500">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {st.total_classes && st.total_classes > 0
                          ? `${st.overall_percentage ?? 100}%`
                          : 'No sessions'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 font-semibold text-[11px] ${
                            (st.overall_percentage ?? 100) >= 75
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : 'text-rose-700 dark:text-rose-400'
                          }`}
                        >
                          {(st.overall_percentage ?? 100) >= 75 ? 'Eligible' : 'Shortage'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openEditModal(st)}
                            className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-sky-700 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                            title="Edit Student"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(st.id, st.name)}
                            className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-rose-700 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
                            title="Delete Student"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================================================== */}
      {/* ADD STUDENT MODAL (Requirements 8 & 9)             */}
      {/* ================================================== */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-lg max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-400 flex items-center justify-center">
                  <UserCheck className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Register New Student</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-md bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Student Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Rajan Yadav"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Roll Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.roll_number}
                    onChange={(e) => setFormData({ ...formData, roll_number: e.target.value })}
                    placeholder="e.g. 2501330100294"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Student Personal Email <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="rajan@example.com"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Temporary Password
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Defaults to student123"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>

              {/* Requirement 9: Student Institutional Email with Generator & Status */}
              <div className="p-3 rounded-lg bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/70 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-sky-950 dark:text-sky-200 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-sky-700 dark:text-sky-400" />
                    Institutional Email Identity
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateInstitutionalEmail}
                    className="text-[11px] font-semibold text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    Generate Institutional Email
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={formData.institutional_email}
                    onChange={(e) => setFormData({ ...formData, institutional_email: e.target.value })}
                    placeholder={`e.g. rajan.yadav@${institution?.domain || 'college.ac.in'}`}
                    className="flex-1 px-3 py-2 border border-sky-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-md font-mono text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                  <span className="text-[11px] font-mono px-2 py-1.5 rounded bg-sky-100 dark:bg-sky-900 text-sky-800 dark:text-sky-300 shrink-0 font-medium">
                    Status: {mailboxStatus === 'active' ? 'Active' : 'Pending'}
                  </span>
                </div>

                <div className="flex items-start gap-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                  <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-sky-600 dark:text-sky-400" />
                  <span>
                    No real mailbox is created unless the institution's email provider is configured. The identity is active for portal authentication.
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch</label>
                  <input
                    type="text"
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    placeholder="CSE"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Semester</label>
                  <input
                    type="number"
                    min="1"
                    max="8"
                    value={formData.semester}
                    onChange={(e) => setFormData({ ...formData, semester: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Section</label>
                  <select
                    value={formData.section}
                    onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  >
                    <option value="A">Section A</option>
                    <option value="B">Section B</option>
                    <option value="C">Section C</option>
                    <option value="D">Section D</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Student ID (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.student_id}
                    onChange={(e) => setFormData({ ...formData, student_id: e.target.value })}
                    placeholder="Auto-generated if empty"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    RFID ID (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.rfid_id}
                    onChange={(e) => setFormData({ ...formData, rfid_id: e.target.value })}
                    placeholder="e.g. RFID-00129"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300">
                    Account Login Password
                  </label>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    Default: password123 (easy access)
                  </span>
                </div>
                <input
                  type="text"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="password123"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Enrolling Student...' : 'Add Student'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {showEditModal && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-lg max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Edit Student Profile</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-md bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Student Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Roll Number</label>
                  <input
                    type="text"
                    disabled
                    value={formData.roll_number}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 rounded-md font-mono cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Student Personal Email</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Institutional Email</label>
                <input
                  type="email"
                  value={formData.institutional_email}
                  onChange={(e) => setFormData({ ...formData, institutional_email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md font-mono text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Branch</label>
                  <input
                    type="text"
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Semester</label>
                  <input
                    type="number"
                    min="1"
                    max="8"
                    value={formData.semester}
                    onChange={(e) => setFormData({ ...formData, semester: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Section</label>
                  <select
                    value={formData.section}
                    onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  >
                    <option value="A">Section A</option>
                    <option value="B">Section B</option>
                    <option value="C">Section C</option>
                    <option value="D">Section D</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">RFID Tag ID</label>
                <input
                  type="text"
                  value={formData.rfid_id}
                  onChange={(e) => setFormData({ ...formData, rfid_id: e.target.value })}
                  placeholder="RFID-00129"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving Changes...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
