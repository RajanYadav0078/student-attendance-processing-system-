import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { SystemSettings } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';
import { Settings, Save, RotateCcw } from 'lucide-react';

export const SystemSettingsPage: React.FC = () => {
  const { showToast } = useNotification();
  const [settings, setSettings] = useState<SystemSettings>({
    eligibility_threshold: 75,
    academic_year: '2026-2027',
    semester_name: 'Odd Semester (Semester 3)',
    institute_name: 'Institute of Technology & Science',
    course_code: 'CCSE0304',
    course_name: 'Computer Architecture & Parallel Processing',
    program: 'B.Tech CSE, Semester 3',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const data = await api.getSettings();
      setSettings(data);
    } catch (e: any) {
      console.error(e);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const updated = await api.updateSettings(settings);
      setSettings(updated);
      showToast({
        type: 'success',
        title: 'Settings Saved',
        message: `System threshold set to ${updated.eligibility_threshold}%. Calculations updated system-wide.`,
      });
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to update settings' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDatabase = async () => {
    if (
      !window.confirm(
        'Are you sure you want to reset all records to the clean system state? This will restore 20 students, 3 faculty members, 5 subjects, and baseline attendance.'
      )
    ) {
      return;
    }

    setIsResetting(true);
    try {
      const res = await api.resetDemoData();
      showToast({
        type: 'success',
        title: 'System Initialized',
        message: 'Database reset to clean state with initial student and course records.',
      });
      loadSettings();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Reset failed' });
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          System Configuration & Settings
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Tune regulatory attendance thresholds, academic calendar parameters, and system state.
        </p>
      </div>

      {/* Main Settings Form */}
      <form
        onSubmit={handleSave}
        className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6"
      >
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <Settings className="w-4 h-4 text-sky-700 dark:text-sky-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            University Attendance Ordinance Parameters
          </h2>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Minimum Attendance Eligibility Cutoff Threshold (%)
            </label>
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <input
                type="number"
                min={50}
                max={95}
                required
                value={settings.eligibility_threshold}
                onChange={(e) =>
                  setSettings({ ...settings, eligibility_threshold: Number(e.target.value) })
                }
                className="w-32 px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono text-base font-bold text-slate-900 dark:text-white"
              />
              <span className="text-slate-500 dark:text-slate-400">
                Default: 75%. Students scoring beneath this value will be categorized as "Attendance Shortage / Defaulter".
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Academic Year
              </label>
              <input
                type="text"
                value={settings.academic_year}
                onChange={(e) => setSettings({ ...settings, academic_year: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Semester Identifier
              </label>
              <input
                type="text"
                value={settings.semester_name}
                onChange={(e) => setSettings({ ...settings, semester_name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Institution Name
            </label>
            <input
              type="text"
              value={settings.institute_name}
              onChange={(e) => setSettings({ ...settings, institute_name: e.target.value })}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 text-slate-900 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course Code
              </label>
              <input
                type="text"
                value={settings.course_code}
                onChange={(e) => setSettings({ ...settings, course_code: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Academic Program
              </label>
              <input
                type="text"
                value={settings.program}
                onChange={(e) => setSettings({ ...settings, program: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-1.5 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Updating...' : 'Save Configuration'}</span>
          </button>
        </div>
      </form>

      {/* Database Reset & System Initialization Card (Image 2 - Demo text removed) */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <RotateCcw className="w-4 h-4 text-slate-600 dark:text-slate-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            Database Maintenance & System Initialization
          </h2>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
          <div className="space-y-1">
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              Reset Database to Clean State
            </span>
            <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
              Restores initial student directory (20 students), faculty members, subjects, and baseline attendance records across sections A and B.
            </p>
          </div>

          <button
            onClick={handleResetDatabase}
            disabled={isResetting}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold rounded-md border border-slate-200 dark:border-slate-700 transition-colors whitespace-nowrap"
          >
            {isResetting ? 'Resetting...' : 'Reset Database'}
          </button>
        </div>
      </div>
    </div>
  );
};
