import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { AttendanceCorrectionRequest } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';
import {
  ShieldCheck,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Search,
  Filter,
  ArrowLeft,
  Calendar,
  User,
  BookOpen,
  MessageSquare,
  Check,
  X,
  FileText,
  BadgeCheck,
  RefreshCw,
} from 'lucide-react';

interface AdminRequestsPageProps {
  onNavigate: (view: string) => void;
}

export const AdminRequestsPage: React.FC<AdminRequestsPageProps> = ({ onNavigate }) => {
  const { showToast } = useNotification();
  const [requests, setRequests] = useState<AttendanceCorrectionRequest[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>('faculty_verified');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalRequest, setActiveModalRequest] = useState<AttendanceCorrectionRequest | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');
  const [adminRemarks, setAdminRemarks] = useState<string>('');
  const [isActioning, setIsActioning] = useState<boolean>(false);

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await api.getAllAttendanceRequests();
      setRequests(data || []);
      // If no faculty_verified exist, default filter to all
      const hasVerified = data?.some((r) => r.status === 'faculty_verified');
      if (!hasVerified && statusFilter === 'faculty_verified') {
        setStatusFilter('all');
      }
    } catch (e: any) {
      console.error('Failed to load correction requests', e);
      showToast({ type: 'error', message: e.message || 'Failed to load requests' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const openActionModal = (req: AttendanceCorrectionRequest, type: 'approve' | 'reject') => {
    setActiveModalRequest(req);
    setActionType(type);
    setAdminRemarks(
      type === 'approve'
        ? `Authorized by Academic Administration · Verified presence in ${req.subject_code} on ${req.date}`
        : 'Administrative review could not validate attendance claim'
    );
  };

  const handleConfirmAction = async () => {
    if (!activeModalRequest) return;
    setIsActioning(true);

    try {
      let res;
      if (actionType === 'approve') {
        res = await api.adminApproveRequest(activeModalRequest.id, adminRemarks.trim());
      } else {
        res = await api.rejectDisputeRequest(activeModalRequest.id, adminRemarks.trim());
      }

      showToast({
        type: 'success',
        title: actionType === 'approve' ? 'Attendance Record Updated' : 'Request Declined',
        message: res.message,
      });

      setActiveModalRequest(null);
      await loadRequests();
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Action Failed',
        message: err.message || 'Failed to process request',
      });
    } finally {
      setIsActioning(false);
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (statusFilter === 'pending') {
      if (r.status !== 'pending' && r.status !== 'pending_faculty') return false;
    } else if (statusFilter !== 'all' && r.status !== statusFilter) {
      return false;
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchName = r.student_name?.toLowerCase().includes(q);
      const matchRoll = r.roll_number?.toLowerCase().includes(q);
      const matchSub = r.subject_code?.toLowerCase().includes(q) || r.subject_name?.toLowerCase().includes(q);
      const matchReason = r.reason?.toLowerCase().includes(q);
      const matchFaculty = r.faculty_name?.toLowerCase().includes(q) || r.faculty_verified_by?.toLowerCase().includes(q);
      if (!matchName && !matchRoll && !matchSub && !matchReason && !matchFaculty) return false;
    }
    return true;
  });

  const facultyVerifiedCount = requests.filter((r) => r.status === 'faculty_verified').length;
  const pendingFacultyCount = requests.filter((r) => r.status === 'pending' || r.status === 'pending_faculty').length;
  const approvedCount = requests.filter((r) => r.status === 'approved').length;
  const rejectedCount = requests.filter((r) => r.status === 'rejected').length;

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'technical_glitch':
        return <span className="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[10px] font-semibold">⚡ Tech Glitch</span>;
      case 'marked_absent_by_mistake':
        return <span className="px-2 py-0.5 rounded bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-[10px] font-semibold">🙋 Absent by Mistake</span>;
      case 'medical_leave':
        return <span className="px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-[10px] font-semibold">🏥 Medical Leave</span>;
      case 'college_duty':
        return <span className="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-[10px] font-semibold">🏆 On-Duty</span>;
      default:
        return <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[10px] font-semibold">📝 Other</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-400 font-semibold mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Tier 2 Administrative Authorization Portal</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Attendance Correction Approvals
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Final governance over attendance disputes. Attendance records in the central registry update to <strong>Present</strong> only upon successful admin final approval.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('admin-dashboard')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Admin Dashboard</span>
          </button>

          <button
            onClick={loadRequests}
            className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className={`p-4 rounded-lg border transition-all ${
          facultyVerifiedCount > 0
            ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800 ring-2 ring-indigo-500/20'
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
        }`}>
          <div className="text-xs text-indigo-700 dark:text-indigo-400 font-semibold flex items-center justify-between">
            <span>Awaiting Admin Approval</span>
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-900 dark:text-indigo-200 mt-1">
            {facultyVerifiedCount}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Faculty-verified & ready for final signoff
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-amber-200 dark:border-amber-900/60">
          <div className="text-xs text-amber-700 dark:text-amber-400 font-semibold flex items-center justify-between">
            <span>Faculty Review Stage</span>
            <Clock className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {pendingFacultyCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Under instructor verification</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-emerald-200 dark:border-emerald-900/60">
          <div className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold flex items-center justify-between">
            <span>Approved & Present</span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
            {approvedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Attendance registry updated</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-rose-200 dark:border-rose-900/60">
          <div className="text-xs text-rose-700 dark:text-rose-400 font-semibold flex items-center justify-between">
            <span>Declined</span>
            <XCircle className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-700 dark:text-rose-400 mt-1">
            {rejectedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Requests rejected</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student name, roll number, course, reason, or faculty..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium"
          >
            <option value="faculty_verified">Awaiting Admin Final Approval ({facultyVerifiedCount})</option>
            <option value="all">All Records ({requests.length})</option>
            <option value="pending">Faculty Review Stage ({pendingFacultyCount})</option>
            <option value="approved">Approved & Registry Updated ({approvedCount})</option>
            <option value="rejected">Declined ({rejectedCount})</option>
          </select>
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <div className="w-6 h-6 border-2 border-sky-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <span className="text-xs text-slate-500">Loading attendance correction queue...</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-lg border border-dashed border-slate-200 dark:border-slate-800 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 dark:text-emerald-400 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              No Correction Requests in Selected View
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {statusFilter === 'faculty_verified'
                ? 'All faculty-verified requests have been actioned! Central attendance registry is synchronized.'
                : 'No attendance requests match the active filter criteria.'}
            </p>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              className={`bg-white dark:bg-slate-900 rounded-lg border p-5 shadow-xs transition-colors space-y-4 ${
                req.status === 'faculty_verified'
                  ? 'border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/10'
                  : req.status === 'approved'
                  ? 'border-emerald-200 dark:border-emerald-900/60'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="w-9 h-9 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs border border-slate-200 dark:border-slate-700">
                    Sec {req.section}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {req.student_name}
                      </span>
                      <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                        ({req.roll_number})
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-semibold text-sky-700 dark:text-sky-400">{req.subject_code}</span>
                      <span>·</span>
                      <span>{req.subject_name}</span>
                      <span>·</span>
                      <span>Lecture: <strong className="font-mono text-slate-700 dark:text-slate-300">{req.date}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {getCategoryBadge(req.category)}

                  {req.status === 'faculty_verified' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-700">
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Ready for Admin Signoff</span>
                    </span>
                  )}

                  {(req.status === 'pending' || req.status === 'pending_faculty') && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                      <Clock className="w-3 h-3" />
                      <span>In Faculty Review</span>
                    </span>
                  )}

                  {req.status === 'approved' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Admin Approved · Record Present</span>
                    </span>
                  )}

                  {req.status === 'rejected' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      <XCircle className="w-3 h-3" />
                      <span>Declined</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Details & Tier Proofs */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
                <div className="md:col-span-8 space-y-2">
                  <div className="bg-slate-50 dark:bg-slate-850 p-3 rounded-md border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Student Reason:
                    </span>
                    <p className="text-slate-800 dark:text-slate-200 leading-relaxed">
                      "{req.reason}"
                    </p>
                  </div>

                  {req.proof_note && (
                    <div className="text-[11px] text-slate-600 dark:text-slate-400 flex items-center gap-1.5 px-1">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Proof / Reference: <strong>{req.proof_note}</strong></span>
                    </div>
                  )}

                  {/* Faculty Tier Verification Box */}
                  {req.faculty_remarks && (
                    <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/30 rounded border border-indigo-200 dark:border-indigo-800 text-[11px]">
                      <div className="flex items-center justify-between font-semibold text-indigo-900 dark:text-indigo-200 mb-1">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Tier 1 Faculty Verification ({req.faculty_verified_by || req.faculty_name})</span>
                        </span>
                        {req.faculty_verified_at && (
                          <span className="text-[10px] text-indigo-700 dark:text-indigo-300 font-normal">
                            {new Date(req.faculty_verified_at).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      <p className="italic text-indigo-800 dark:text-indigo-300">"{req.faculty_remarks}"</p>
                    </div>
                  )}

                  {/* Admin Tier Remarks if Approved */}
                  {req.admin_remarks && (
                    <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/40 rounded border border-emerald-200 dark:border-emerald-800 text-[11px]">
                      <div className="flex items-center justify-between font-semibold text-emerald-900 dark:text-emerald-200 mb-1">
                        <span className="flex items-center gap-1.5">
                          <BadgeCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Tier 2 Admin Authorization ({req.admin_approved_by || 'Admin'})</span>
                        </span>
                        {req.admin_approved_at && (
                          <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-normal">
                            {new Date(req.admin_approved_at).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      <p className="text-emerald-800 dark:text-emerald-300 font-medium">"{req.admin_remarks}"</p>
                    </div>
                  )}
                </div>

                <div className="md:col-span-4 flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 md:pl-4 space-y-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
                    <div>Submitted: <span className="text-slate-700 dark:text-slate-300 font-medium">{new Date(req.created_at).toLocaleDateString()}</span></div>
                    {req.faculty_verified_at && (
                      <div>Faculty Signed: <span className="text-indigo-600 dark:text-indigo-400 font-medium">{new Date(req.faculty_verified_at).toLocaleDateString()}</span></div>
                    )}
                    {req.resolved_at && (
                      <div>Admin Actioned: <span className="text-slate-700 dark:text-slate-300 font-medium">{new Date(req.resolved_at).toLocaleDateString()}</span></div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  {req.status === 'faculty_verified' ? (
                    <div className="space-y-2 pt-2">
                      <button
                        onClick={() => openActionModal(req, 'approve')}
                        className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-sm text-xs"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>Authorize & Mark Present</span>
                      </button>

                      <button
                        onClick={() => openActionModal(req, 'reject')}
                        className="w-full py-1.5 px-3 bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/40 text-slate-700 hover:text-rose-700 dark:text-slate-300 dark:hover:text-rose-400 border border-slate-200 dark:border-slate-700 rounded-md transition-colors flex items-center justify-center gap-1 text-xs"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Decline Request</span>
                      </button>
                    </div>
                  ) : req.status === 'pending' || req.status === 'pending_faculty' ? (
                    <div className="space-y-2 pt-2">
                      <div className="text-[10px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 p-2 rounded border border-amber-200 dark:border-amber-800">
                        Awaiting instructor verification. Admin override available below.
                      </div>
                      <button
                        onClick={() => openActionModal(req, 'approve')}
                        className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-md transition-colors flex items-center justify-center gap-1 text-xs"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Emergency Admin Override</span>
                      </button>
                    </div>
                  ) : (
                    <div className="text-[11px] text-slate-400 pt-1">
                      Status is final · Central attendance database updated
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Admin Authorization Modal */}
      {activeModalRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                {actionType === 'approve' ? (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Admin Final Authorization</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 text-rose-600" />
                    <span>Decline Correction Request</span>
                  </>
                )}
              </h3>
              <button onClick={() => setActiveModalRequest(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded border border-slate-200 dark:border-slate-700 space-y-1">
              <div>Student: <strong className="text-slate-900 dark:text-white">{activeModalRequest.student_name}</strong> ({activeModalRequest.roll_number}, Sec {activeModalRequest.section})</div>
              <div>Course: <strong className="font-mono text-slate-900 dark:text-white">{activeModalRequest.subject_code}</strong> · {activeModalRequest.subject_name}</div>
              <div>Date: <strong className="font-mono text-slate-900 dark:text-white">{activeModalRequest.date}</strong></div>
              {activeModalRequest.faculty_remarks && (
                <div className="text-indigo-700 dark:text-indigo-400 pt-1 border-t border-slate-200 dark:border-slate-700 mt-1">
                  Faculty Note: "{activeModalRequest.faculty_remarks}"
                </div>
              )}
            </div>

            {actionType === 'approve' && (
              <div className="p-2.5 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-[11px] leading-relaxed">
                ✓ <strong>Database Update Guarantee:</strong> Granting final approval will update this student's attendance record to <strong>Present</strong> in the central database, recalculate cumulative attendance percentage, and notify the student.
              </div>
            )}

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Administrative Remarks / Authorization Order:
              </label>
              <textarea
                rows={3}
                value={adminRemarks}
                onChange={(e) => setAdminRemarks(e.target.value)}
                placeholder="Enter regulatory authorization rationale..."
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-sans"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setActiveModalRequest(null)}
                disabled={isActioning}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md font-medium transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmAction}
                disabled={isActioning}
                className={`px-5 py-2 text-white font-semibold rounded-md shadow-sm transition-colors flex items-center gap-1.5 ${
                  actionType === 'approve'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                {isActioning ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Updating Database...</span>
                  </>
                ) : (
                  <span>{actionType === 'approve' ? 'Authorize & Update Registry' : 'Confirm Decline'}</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
