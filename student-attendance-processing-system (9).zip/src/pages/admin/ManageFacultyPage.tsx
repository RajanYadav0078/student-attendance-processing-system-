import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { Faculty, Subject, Institution } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  BookOpen,
  X,
  Mail,
  ShieldCheck,
  Sparkles,
  Layers,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export const ManageFacultyPage: React.FC = () => {
  const { showToast } = useNotification();
  const [facultyList, setFacultyList] = useState<Faculty[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [institution, setInstitution] = useState<Institution | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedFaculty, setSelectedFaculty] = useState<Faculty | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    institutional_email: '',
    employee_id: '',
    department: 'Computer Science & Engineering',
    assigned_subject_ids: [] as string[],
    section: 'A',
    password: 'password123',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [fList, subjs, inst] = await Promise.all([
        api.getFacultyList(),
        api.getSubjects(),
        api.getCurrentInstitution().catch(() => null),
      ]);
      setFacultyList(fList);
      setSubjects(subjs);
      setInstitution(inst);
    } catch (e: any) {
      showToast({ type: 'error', message: e.message || 'Failed to load faculty' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateInstitutionalEmail = () => {
    if (!formData.name.trim()) {
      showToast({ type: 'error', message: 'Enter faculty name first to generate institutional email identity' });
      return;
    }
    const domain = institution?.domain || 'college.ac.in';
    const clean = formData.name
      .trim()
      .toLowerCase()
      .replace(/^prof\.\s*|^dr\.\s*/i, '')
      .replace(/\s+/g, '.')
      .replace(/[^a-z0-9.]/g, '');
    const generated = `${clean}@${domain}`;
    setFormData((prev) => ({ ...prev, institutional_email: generated }));
    showToast({
      type: 'info',
      title: 'Institutional Email Formulated',
      message: `Identity ${generated} formulated based on domain ${domain}.`,
    });
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newF = await api.addFaculty({
        name: formData.name,
        email: formData.email,
        institutional_email: formData.institutional_email || undefined,
        employee_id: formData.employee_id,
        department: formData.department,
        assigned_subject_ids: formData.assigned_subject_ids,
        password: formData.password || 'password123',
      });
      showToast({
        type: 'success',
        title: 'Faculty Registered',
        message: `Registered ${newF.name} (${newF.employee_id}) successfully.`,
      });
      setShowAddModal(false);
      resetForm();
      loadData();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to add faculty' });
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFaculty) return;
    try {
      const updated = await api.updateFaculty(selectedFaculty.id, {
        name: formData.name,
        email: formData.email,
        institutional_email: formData.institutional_email,
        employee_id: formData.employee_id,
        department: formData.department,
        assigned_subject_ids: formData.assigned_subject_ids,
      });
      showToast({
        type: 'success',
        title: 'Faculty Updated',
        message: `Updated ${updated.name} successfully.`,
      });
      setShowEditModal(false);
      setSelectedFaculty(null);
      resetForm();
      loadData();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to update faculty' });
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to remove faculty member ${name}?`)) return;
    try {
      await api.deleteFaculty(id);
      showToast({
        type: 'info',
        title: 'Faculty Removed',
        message: `Removed ${name} from active faculty roster.`,
      });
      loadData();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to delete faculty' });
    }
  };

  const openEditModal = (f: Faculty) => {
    setSelectedFaculty(f);
    setFormData({
      name: f.name,
      email: f.email,
      institutional_email: f.institutional_email || '',
      employee_id: f.employee_id,
      department: f.department,
      assigned_subject_ids: f.assigned_subject_ids || [],
      section: 'A',
      password: '',
    });
    setShowEditModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      institutional_email: '',
      employee_id: '',
      department: 'Computer Science & Engineering',
      assigned_subject_ids: [],
      section: 'A',
      password: 'password123',
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono mb-1">
            <span>Institution Administration</span>
            <span>·</span>
            <span>{institution?.name || 'Department Roster'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Faculty Directory & Allocations</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Administer teaching faculty, employee identifiers, institutional email identities, and course allocations.
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Faculty</span>
        </button>
      </div>

      {/* Notice Banner */}
      <div className="p-3.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 flex items-center gap-2.5 text-xs text-sky-900 dark:text-sky-200">
        <ShieldCheck className="w-4 h-4 text-sky-700 dark:text-sky-400 shrink-0" />
        <span>
          <strong>Tenant Authorization:</strong> Faculty members only have access to their assigned subjects, sections, and students belonging to <strong>{institution?.name || 'this institution'}</strong>.
        </span>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                <th className="py-3 px-4">Employee ID</th>
                <th className="py-3 px-4">Faculty Name</th>
                <th className="py-3 px-4">Official / Institutional Email</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Assigned Courses</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {facultyList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 dark:text-slate-500">
                    No faculty members enrolled yet. Click "Add New Faculty" to register teaching faculty.
                  </td>
                </tr>
              ) : (
                facultyList.map((f) => (
                  <tr key={f.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900 dark:text-white">{f.employee_id}</td>
                    <td className="py-3 px-4 font-medium text-slate-900 dark:text-white">{f.name}</td>
                    <td className="py-3 px-4">
                      <div className="text-slate-800 dark:text-slate-200">{f.email}</div>
                      {f.institutional_email && (
                        <div className="text-[11px] font-mono text-sky-700 dark:text-sky-400 flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          <span>{f.institutional_email}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{f.department}</td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {f.assigned_subjects && f.assigned_subjects.length > 0 ? (
                          f.assigned_subjects.map((s) => (
                            <span
                              key={s.id}
                              className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[10px] text-slate-700 dark:text-slate-300"
                            >
                              {s.subject_code}
                            </span>
                          ))
                        ) : (
                          <span className="text-slate-400 italic">No courses assigned</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEditModal(f)}
                          className="p-1.5 text-slate-500 hover:text-sky-700 dark:hover:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(f.id, f.name)}
                          className="p-1.5 text-slate-500 hover:text-rose-700 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-lg max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                Register Teaching Faculty
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Faculty Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Prof. Arvind Sharma"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Employee ID <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.employee_id}
                    onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                    placeholder="EMP-CSE-04"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                  />
                </div>
              </div>

              {/* Official Email */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Official Email Address <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="prof.arvind@example.com"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              {/* Institutional Email Identity Option (Requirement 10) */}
              <div className="p-3 rounded-lg bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/70 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-sky-950 dark:text-sky-200 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-sky-700 dark:text-sky-400" />
                    Institutional Email Identity
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateInstitutionalEmail}
                    className="text-[11px] font-semibold text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    Generate Institutional Email
                  </button>
                </div>

                <input
                  type="text"
                  value={formData.institutional_email}
                  onChange={(e) => setFormData({ ...formData, institutional_email: e.target.value })}
                  placeholder={`e.g. arvind.sharma@${institution?.domain || 'college.ac.in'}`}
                  className="w-full px-3 py-2 border border-sky-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-md font-mono text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Formulated on verified domain <strong>{institution?.domain || 'college.ac.in'}</strong>. Mailbox status is currently {institution?.mailbox_status || 'pending'}.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-semibold text-slate-700 dark:text-slate-300">Login Password</label>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Default: password123</span>
                  </div>
                  <input
                    type="text"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono text-xs"
                  />
                </div>
              </div>

              {/* Course Assignment */}
              {subjects.length > 0 && (
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Assign Subject Courses
                  </label>
                  <div className="max-h-28 overflow-y-auto p-2 border border-slate-200 dark:border-slate-700 rounded-md bg-slate-50 dark:bg-slate-800/50 space-y-1">
                    {subjects.map((subj) => (
                      <label key={subj.id} className="flex items-center gap-2 cursor-pointer hover:bg-white dark:hover:bg-slate-800 p-1 rounded">
                        <input
                          type="checkbox"
                          checked={formData.assigned_subject_ids.includes(subj.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setFormData({
                                ...formData,
                                assigned_subject_ids: [...formData.assigned_subject_ids, subj.id],
                              });
                            } else {
                              setFormData({
                                ...formData,
                                assigned_subject_ids: formData.assigned_subject_ids.filter((id) => id !== subj.id),
                              });
                            }
                          }}
                          className="rounded text-sky-600 focus:ring-sky-500"
                        />
                        <span className="font-mono text-slate-800 dark:text-slate-200">{subj.subject_code}</span>
                        <span className="text-slate-600 dark:text-slate-400 text-[11px] truncate">{subj.subject_name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
                >
                  Register Faculty
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-lg max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Edit Faculty Member</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee ID</label>
                  <input
                    type="text"
                    required
                    value={formData.employee_id}
                    onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Official Email</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Institutional Email</label>
                <input
                  type="email"
                  value={formData.institutional_email}
                  onChange={(e) => setFormData({ ...formData, institutional_email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md font-mono text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
