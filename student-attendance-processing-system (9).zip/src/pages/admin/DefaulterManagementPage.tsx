import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { useNotification } from '../../context/NotificationContext.tsx';
import { AlertOctagon, Mail, Download, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { PrintableReport } from '../../components/reports/PrintableReport.tsx';

export const DefaulterManagementPage: React.FC = () => {
  const { showToast } = useNotification();
  const [defaulters, setDefaulters] = useState<any[]>([]);
  const [threshold, setThreshold] = useState<number>(75);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [showPrintReport, setShowPrintReport] = useState<boolean>(false);

  useEffect(() => {
    loadDefaulters();
  }, [threshold]);

  const loadDefaulters = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDefaultersReport(threshold);
      setDefaulters(data);
    } catch (e: any) {
      showToast({ type: 'error', message: e.message || 'Failed to load defaulters' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendNotice = (studentName: string, roll: string) => {
    showToast({
      type: 'info',
      title: 'Warning Notice Dispatched',
      message: `System notification queued for ${studentName} (${roll}): Mandatory ${threshold}% attendance compliance notice.`,
    });
  };

  const handleSendAllNotices = () => {
    showToast({
      type: 'success',
      title: 'Batch Notices Dispatched',
      message: `Sent attendance shortage warnings to all ${defaulters.length} flagged students.`,
    });
  };

  if (showPrintReport) {
    return (
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <PrintableReport
          title={`Institute Defaulter Roster (Below ${threshold}% Minimum Threshold)`}
          defaulters={defaulters}
          onBack={() => setShowPrintReport(false)}
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Attendance Defaulter Management</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Identify, audit, and issue regulatory warnings to students failing the minimum attendance cutoff.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSendAllNotices}
            disabled={defaulters.length === 0}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-800 dark:text-rose-300 text-xs font-semibold rounded-md border border-rose-200 dark:border-rose-800 transition-colors disabled:opacity-50"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Send Batch Warnings</span>
          </button>

          <button
            onClick={() => setShowPrintReport(true)}
            className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md shadow-sm transition-colors"
          >
            Generate Defaulter PDF
          </button>
        </div>
      </div>

      {/* Threshold Controller Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 text-xs transition-colors">
        <div className="flex items-center gap-3">
          <label className="font-semibold text-slate-700 dark:text-slate-300">Filter by Attendance Threshold Cutoff:</label>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-md">
            {[65, 70, 75, 80].map((val) => (
              <button
                key={val}
                onClick={() => setThreshold(val)}
                className={`px-3 py-1 font-semibold rounded-sm transition-colors ${
                  threshold === val
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {val}%
              </button>
            ))}
          </div>
        </div>

        <div className="text-slate-500 dark:text-slate-400 font-mono">
          Flagged Defaulters: <strong className="text-rose-700 dark:text-rose-400 text-sm">{defaulters.length}</strong> Students
        </div>
      </div>

      {/* Defaulter Table */}
      <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-semibold">
                <th className="py-3 px-4">Roll Number</th>
                <th className="py-3 px-4">Student Name</th>
                <th className="py-3 px-4">Section</th>
                <th className="py-3 px-4 text-right">Classes Attended</th>
                <th className="py-3 px-4 text-right">Overall Percentage</th>
                <th className="py-3 px-4">Subject Deficiencies</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 dark:text-slate-500">
                    Loading defaulter roster...
                  </td>
                </tr>
              ) : defaulters.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 dark:text-slate-500">
                    No defaulter students found below {threshold}%.
                  </td>
                </tr>
              ) : (
                defaulters.map((d) => (
                  <tr key={d.student.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">{d.student.roll_number}</td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900 dark:text-white">{d.student.name}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">{d.student.email}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">Sec {d.student.section}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {d.attended_classes} / {d.total_classes}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-700 dark:text-rose-400 text-sm">
                      {d.overall_percentage}%
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {d.defaulterSubjects?.map((sub: any) => (
                          <span
                            key={sub.subject_id}
                            className="font-mono text-[10px] bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 px-1.5 py-0.5 rounded-xs"
                          >
                            {sub.subject_code} ({sub.attendance_percentage}%)
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleSendNotice(d.student.name, d.student.roll_number)}
                        className="text-xs text-sky-700 dark:text-sky-400 hover:text-sky-900 dark:hover:text-sky-300 font-semibold"
                      >
                        Issue Warning
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
