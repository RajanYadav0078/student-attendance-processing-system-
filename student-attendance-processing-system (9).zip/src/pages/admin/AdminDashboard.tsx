import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotification } from '../../context/NotificationContext.tsx';
import { Institution } from '../../types/index.ts';
import { StatCard } from '../../components/common/StatCard.tsx';
import { SubjectBarChart } from '../../components/charts/SubjectBarChart.tsx';
import {
  GraduationCap,
  Users,
  BookOpen,
  CalendarCheck,
  TrendingUp,
  AlertOctagon,
  ArrowRight,
  Settings,
  ShieldCheck,
  Building2,
  Globe,
  Mail,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Server,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (view: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useNotification();

  const [data, setData] = useState<any>(null);
  const [institution, setInstitution] = useState<Institution | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Domain verification simulation state
  const [verificationTokenInput, setVerificationTokenInput] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [copiedToken, setCopiedToken] = useState(false);

  // Email configuration state
  const [selectedProvider, setSelectedProvider] = useState<'none' | 'google_workspace' | 'microsoft_365' | 'custom_mail_server' | 'smtp'>('none');
  const [isSavingEmailConfig, setIsSavingEmailConfig] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [res, instRes] = await Promise.all([
        api.getDashboardData(),
        api.getCurrentInstitution().catch(() => null),
      ]);
      setData(res);
      const inst = instRes || res?.institution || null;
      setInstitution(inst);
      if (inst) {
        setVerificationTokenInput(inst.verification_token);
        setSelectedProvider(inst.email_service_provider || 'none');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyDomain = async () => {
    if (!institution) return;
    setIsVerifying(true);
    try {
      const res = await api.verifyDomain(verificationTokenInput);
      setInstitution(res.institution);
      showToast({
        type: 'success',
        title: 'Domain Verified',
        message: `Domain ${res.institution.domain} is now verified. Institutional credentials fully active.`,
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Verification Failed',
        message: err.message || 'DNS TXT verification record check failed.',
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSaveEmailConfig = async (activateMailbox: boolean) => {
    if (!institution) return;
    setIsSavingEmailConfig(true);
    try {
      const mailboxStatus = activateMailbox ? 'active' : selectedProvider === 'none' ? 'not_configured' : 'pending';
      const res = await api.configureEmailProvider({
        provider: selectedProvider,
        mailboxStatus,
      });
      setInstitution(res.institution);
      showToast({
        type: 'success',
        title: 'Email Provider Configured',
        message: `Email system linked with ${selectedProvider}. Mailbox status: ${res.institution.mailbox_status.toUpperCase()}.`,
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Configuration Error',
        message: err.message || 'Could not update email configuration.',
      });
    } finally {
      setIsSavingEmailConfig(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-28 bg-slate-200 dark:bg-slate-800 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const stats = data?.stats || {};
  const defaulters = data?.defaulters || [];
  const subjectStats = data?.subjectStats || [];
  const settings = data?.settings || {};

  const instName = institution?.name || settings.institute_name || 'Registered Academic Institution';
  const instDomain = institution?.domain || 'college.ac.in';
  const adminName = institution?.admin_name || user?.name || 'Administrator';
  const isVerified = institution?.verification_status === 'verified';
  const mailboxStatus = institution?.mailbox_status || 'not_configured';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* ================================================== */}
      {/* 1. INSTITUTION ADMINISTRATOR BANNER (Requirement 6) */}
      {/* ================================================== */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Institution Crest, Name, Domain, Admin */}
          <div className="flex items-start sm:items-center gap-4">
            {/* Institution Logo / Emblem */}
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-sky-700 to-slate-900 text-white flex items-center justify-center shrink-0 shadow-md border border-sky-600/30">
              <Building2 className="w-8 h-8 text-sky-200" />
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">
                  {institution?.type ? institution.type.toUpperCase() : 'COLLEGE'}
                </span>
                <span className="text-slate-300 dark:text-slate-600">·</span>
                {/* Verification Status Badge */}
                {isVerified ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    Domain Verified
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded-full">
                    <AlertTriangle className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                    Pending Verification
                  </span>
                )}
              </div>

              {/* Institution Name */}
              <h1 className="text-xl sm:text-2xl font-bold text-slate-950 dark:text-white leading-tight">
                {instName}
              </h1>

              {/* Domain & Administrator Name */}
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-400 pt-0.5">
                <span className="flex items-center gap-1 font-mono text-sky-700 dark:text-sky-400 font-semibold">
                  <Globe className="w-3.5 h-3.5" />
                  {instDomain}
                </span>
                <span className="text-slate-300 dark:text-slate-600">·</span>
                <span className="flex items-center gap-1 text-slate-800 dark:text-slate-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  Administrator: <strong>{adminName}</strong>
                </span>
                {institution?.institutional_admin_email && (
                  <>
                    <span className="text-slate-300 dark:text-slate-600">·</span>
                    <span className="font-mono text-slate-500 dark:text-slate-400">
                      {institution.institutional_admin_email}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Quick Action Navigation */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => onNavigate('admin-students')}
              className="px-3.5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Students</span>
            </button>

            <button
              onClick={() => onNavigate('admin-faculty')}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5"
            >
              <Users className="w-4 h-4 text-sky-300" />
              <span>Faculty</span>
            </button>

            <button
              onClick={() => onNavigate('admin-settings')}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-md border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1"
            >
              <Settings className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              <span>Settings</span>
            </button>
          </div>
        </div>
      </div>

      {/* ================================================== */}
      {/* 2. DOMAIN VERIFICATION CARD (Requirement 4)        */}
      {/* ================================================== */}
      {!isVerified && institution && (
        <div className="p-6 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 shadow-xs space-y-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-amber-950 dark:text-amber-200">
                  Domain Ownership Verification Required
                </h3>
                <span className="text-[11px] font-mono font-bold text-amber-700 dark:text-amber-400 uppercase">
                  STATUS: PENDING VERIFICATION
                </span>
              </div>
              <p className="text-xs text-amber-900/80 dark:text-amber-300/80 mt-1 leading-relaxed">
                To activate your institutional account, verify ownership of your institution domain (<strong>{institution.domain}</strong>). Add the following DNS TXT record to your domain DNS settings, then click "Verify Domain".
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-amber-200 dark:border-slate-800">
            <div className="md:col-span-8 flex items-center justify-between font-mono text-xs font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 p-2.5 rounded">
              <span className="break-all">{institution.verification_token}</span>
              <button
                onClick={() => copyToClipboard(institution.verification_token)}
                className="ml-2 text-xs text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 shrink-0 font-sans"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedToken ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="md:col-span-4 flex items-center justify-end gap-2">
              <button
                onClick={handleVerifyDomain}
                disabled={isVerifying}
                className="w-full sm:w-auto px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-50"
              >
                {isVerifying ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Verifying...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Verify Domain</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================== */}
      {/* 3. EMAIL CONFIGURATION PANEL (Requirement 5)       */}
      {/* ================================================== */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm transition-colors space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-100 dark:bg-sky-950 flex items-center justify-center shrink-0 text-sky-700 dark:text-sky-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Institutional Email Configuration</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Manage email identity provisioning & mailbox provider connectivity
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 dark:text-slate-400">Mailbox Status:</span>
            <span
              className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full ${
                mailboxStatus === 'active'
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                  : mailboxStatus === 'pending'
                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                  : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
              }`}
            >
              {mailboxStatus.toUpperCase()}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Identity Info */}
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-750 space-y-1.5">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase font-mono">
              Admin Email Identity
            </div>
            <div className="font-mono text-xs font-bold text-slate-900 dark:text-white break-all">
              {institution?.institutional_admin_email || `admin@${instDomain}`}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-1">
              Identity established based on verified domain <strong className="font-mono">{instDomain}</strong>.
            </p>
          </div>

          {/* Provider Selection */}
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-750 space-y-2">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase font-mono">
              Mailbox Service Provider
            </div>
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-sky-600 font-medium"
            >
              <option value="none">Not Configured (Identity Only)</option>
              <option value="google_workspace">Google Workspace</option>
              <option value="microsoft_365">Microsoft 365</option>
              <option value="custom_mail_server">Institution Mail Server</option>
              <option value="smtp">Standard SMTP / IMAP</option>
            </select>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Future integration with cloud or institutional mailbox clusters.
            </p>
          </div>

          {/* Action / Demo Mode Activation */}
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-750 flex flex-col justify-between space-y-2">
            <div>
              <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase font-mono">
                Provisioning Control
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Toggle demo mode activation or persist server configurations.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                onClick={() => handleSaveEmailConfig(false)}
                disabled={isSavingEmailConfig}
                className="px-3 py-1.5 text-xs font-semibold rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 transition-colors disabled:opacity-50"
              >
                Save Choice
              </button>

              <button
                onClick={() => handleSaveEmailConfig(true)}
                disabled={isSavingEmailConfig}
                className="px-3 py-1.5 text-xs font-semibold rounded bg-sky-700 hover:bg-sky-800 text-white transition-colors disabled:opacity-50 flex items-center gap-1 shadow-2xs"
              >
                <span>Activate Demo Mailbox</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================================================== */}
      {/* 4. SIX CORE STAT CARDS (REAL DATABASE ONLY)        */}
      {/* ================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
        <StatCard
          label="Total Students"
          value={stats.totalStudents ?? 0}
          subtext="Admin-Registered Students"
          icon={GraduationCap}
        />

        <StatCard
          label="Total Faculty"
          value={stats.totalFaculty ?? 0}
          subtext="Professors & Coordinators"
          icon={Users}
        />

        <StatCard
          label="Total Subjects"
          value={stats.totalSubjects ?? 0}
          subtext="Theory & Lab Courses"
          icon={BookOpen}
        />

        <StatCard
          label="Today's Sessions"
          value={stats.todaySessionsCount ?? 0}
          subtext="Active / Completed"
          icon={CalendarCheck}
        />

        <StatCard
          label="Average Attendance"
          value={stats.totalStudents > 0 ? `${stats.averageAttendance ?? 0}%` : 'N/A'}
          subtext={stats.totalStudents > 0 ? 'Aggregate presence rate' : 'No students enrolled'}
          icon={TrendingUp}
          highlight
        />

        <StatCard
          label="Defaulters (<75%)"
          value={stats.defaultersCount ?? 0}
          subtext="Under required threshold"
          icon={AlertOctagon}
          badge={{
            text: stats.defaultersCount > 0 ? 'Action Needed' : 'Nominal',
            variant: stats.defaultersCount > 0 ? 'danger' : 'success',
          }}
        />
      </div>

      {/* ================================================== */}
      {/* 5. CHARTS & ADMINISTRATIVE SHORTCUTS               */}
      {/* ================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8">
          <SubjectBarChart
            subjects={subjectStats}
            threshold={settings.eligibility_threshold || 75}
          />
        </div>

        {/* Administrative Shortcuts */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4 transition-colors">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Administrative Modules</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Tenant management controls</p>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => onNavigate('admin-students')}
              className="w-full p-2.5 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">Manage Students</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Add, edit, generate institutional email</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 dark:text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('admin-faculty')}
              className="w-full p-2.5 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">Manage Faculty</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Employee IDs & faculty identities</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 dark:text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('admin-defaulters')}
              className="w-full p-2.5 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">Defaulter Roster</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Students under 75% threshold</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 dark:text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('admin-settings')}
              className="w-full p-2.5 rounded-md border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">System Settings & Thresholds</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Configure attendance percentage rule</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 dark:text-slate-500" />
            </button>
          </div>

          <div className="text-[11px] text-slate-400 dark:text-slate-500 text-center pt-2 border-t border-slate-100 dark:border-slate-800">
            Tenant ID: <strong className="font-mono text-slate-600 dark:text-slate-300">{institution?.id || 'inst-default'}</strong>
          </div>
        </div>
      </div>
    </div>
  );
};
