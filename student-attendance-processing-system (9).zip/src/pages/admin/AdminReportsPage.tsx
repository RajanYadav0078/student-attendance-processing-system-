import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { PrintableReport } from '../../components/reports/PrintableReport.tsx';

export const AdminReportsPage: React.FC = () => {
  const [defaulters, setDefaulters] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDashboardData();
      setStats(data?.stats);
      const defs = await api.getDefaultersReport();
      setDefaulters(defs);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div className="p-8 text-xs text-slate-500 dark:text-slate-400">Compiling university attendance report...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 transition-colors">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Consolidated Institute Attendance Audit Report
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Official academic compliance record for Department of Computer Science & Engineering.
        </p>
      </div>

      <PrintableReport
        title="Departmental Cumulative Attendance & Ordinance Compliance Audit"
        defaulters={defaulters}
      />
    </div>
  );
};
