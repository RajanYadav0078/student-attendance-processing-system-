import React from 'react';
import { BookOpen, GraduationCap, Award, CheckCircle2, ShieldCheck, QrCode } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Title */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-6 transition-colors">
        <div className="flex items-center gap-2 text-xs font-semibold text-sky-700 dark:text-sky-400">
          <span>Academic Portal</span>
          <span aria-hidden="true">·</span>
          <span>Semester 3</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white mt-1">
          About the Student Attendance Processing System
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
          Digital attendance management platform engineered for higher-education departments to track, calculate, and report classroom attendance.
        </p>
      </div>

      {/* Curriculum Card */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 space-y-4 transition-colors">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-sky-700 dark:text-sky-400" />
          <span>Department Specifications</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-md border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Academic Program</span>
            <span className="font-bold text-slate-900 dark:text-white">B.Tech Computer Science & Engineering</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-md border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Current Semester</span>
            <span className="font-mono font-bold text-slate-900 dark:text-white">Semester 3</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-md border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Department</span>
            <span className="font-medium text-slate-800 dark:text-slate-200">Department of Computer Science & Engineering</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-md border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Academic Session</span>
            <span className="font-medium text-slate-800 dark:text-slate-200">Session 2026-2027</span>
          </div>
        </div>
      </div>

      {/* Purpose & Objectives */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 space-y-4 transition-colors">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <GraduationCap className="w-4 h-4 text-sky-700 dark:text-sky-400" />
          <span>Platform Objectives</span>
        </h2>
        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
          Provides automated attendance recording, immediate mathematical calculations, and instant defaulter identification.
        </p>
        <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>Digitized High-Speed Check-In:</strong> Dynamic time-expiring QR code tokens scanned via camera feed.
            </span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>Real-Time Compliance Engine:</strong> Automated percentage calculations (Attended / Total) × 100 with immediate 75% cutoff flagging.
            </span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>Role-Based Access Control:</strong> Isolated dashboards and secure permissions for Students, Faculty, and Administrators.
            </span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>Reversible Attendance Records:</strong> Instant undo support for rollback of accidental markings.
            </span>
          </div>
        </div>
      </div>

      {/* University Compliance Guidelines */}
      <div className="bg-white dark:bg-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-800 space-y-3 text-xs text-slate-600 dark:text-slate-400 transition-colors">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Award className="w-4 h-4 text-sky-700 dark:text-sky-400" />
          <span>Institutional Attendance Ordinance</span>
        </h2>
        <p className="leading-relaxed">
          Students must maintain a minimum of <strong>75% attendance</strong> across all enrolled theory and laboratory courses to remain eligible for Semester End Examinations. Defaulter lists are automatically updated following each lecture session.
        </p>
      </div>
    </div>
  );
};
