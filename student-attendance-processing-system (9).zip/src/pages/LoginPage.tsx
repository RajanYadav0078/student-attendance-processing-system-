import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useNotification } from '../context/NotificationContext.tsx';
import { api } from '../services/api.ts';
import {
  Cpu,
  Lock,
  Mail,
  ArrowRight,
  Eye,
  EyeOff,
  Key,
  Sparkles,
  Check,
  Copy,
  ShieldCheck,
  GraduationCap,
  School,
  Zap,
  Building2,
  UserCheck,
} from 'lucide-react';

interface LoginPageProps {
  onNavigate: (view: string) => void;
  initialRole?: 'student' | 'faculty' | 'admin';
}

interface DemoAccount {
  role: 'student' | 'faculty' | 'admin';
  label: string;
  name: string;
  email: string;
  identifier: string;
  rollNumber?: string;
  employeeId?: string;
  password: string;
  institution: string;
}

const FALLBACK_ACCOUNTS: Record<'student' | 'faculty' | 'admin', DemoAccount[]> = {
  student: [
    {
      role: 'student',
      label: 'Student (Aarav Sharma)',
      name: 'Aarav Sharma',
      email: 'aarav.sharma@niet.co.in',
      identifier: 'student',
      rollNumber: '26CSE042',
      password: 'password123',
      institution: 'Noida Institute of Engineering and Technology',
    },
    {
      role: 'student',
      label: 'Student (Rajan Yadav)',
      name: 'Rajan Yadav',
      email: 'rajan.yadav@niet.co.in',
      identifier: '25012347284',
      rollNumber: '25012347284',
      password: 'password123',
      institution: 'Noida Institute of Engineering and Technology',
    },
  ],
  faculty: [
    {
      role: 'faculty',
      label: 'Faculty (Dr. Priya Sharma)',
      name: 'Dr. Priya Sharma',
      email: 'dr.priya.sharma@niet.co.in',
      identifier: 'faculty',
      employeeId: 'FAC-CSE-001',
      password: 'password123',
      institution: 'Noida Institute of Engineering and Technology',
    },
    {
      role: 'faculty',
      label: 'Faculty (ARMIND)',
      name: 'ARMIND',
      email: 'armind@niet.co.in',
      identifier: 'CSE-4',
      employeeId: 'CSE-4',
      password: 'password123',
      institution: 'Noida Institute of Engineering and Technology',
    },
  ],
  admin: [
    {
      role: 'admin',
      label: 'Admin (Dr. S. K. Raman)',
      name: 'Dr. S. K. Raman',
      email: 'admin@niet.co.in',
      identifier: 'admin',
      password: 'password123',
      institution: 'Noida Institute of Engineering and Technology',
    },
    {
      role: 'admin',
      label: 'Admin (Rajan Yadav)',
      name: 'Rajan Yadav',
      email: 'rajan.yadav@apexuniv.ac.in',
      identifier: 'admin',
      password: 'password123',
      institution: 'Apex University of Technology',
    },
  ],
};

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate, initialRole = 'student' }) => {
  const { login } = useAuth();
  const { showToast } = useNotification();

  const [selectedRoleTab, setSelectedRoleTab] = useState<'student' | 'faculty' | 'admin'>(initialRole);
  const [accountList, setAccountList] = useState<Record<'student' | 'faculty' | 'admin', DemoAccount[]>>(FALLBACK_ACCOUNTS);
  const [selectedAccountIndex, setSelectedAccountIndex] = useState<number>(0);

  const [email, setEmail] = useState(FALLBACK_ACCOUNTS[initialRole][0].email);
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [copiedPass, setCopiedPass] = useState(false);

  // Fetch demo credentials dynamically from server
  useEffect(() => {
    let isMounted = true;
    api
      .getDemoCredentials()
      .then((data) => {
        if (!isMounted || !data?.accounts) return;
        const grouped: Record<'student' | 'faculty' | 'admin', DemoAccount[]> = {
          student: [],
          faculty: [],
          admin: [],
        };
        data.accounts.forEach((acc: any) => {
          if (acc.role === 'student') grouped.student.push(acc);
          else if (acc.role === 'faculty') grouped.faculty.push(acc);
          else if (acc.role === 'admin') grouped.admin.push(acc);
        });

        // Ensure at least fallback accounts exist if groups are empty
        if (grouped.student.length === 0) grouped.student = FALLBACK_ACCOUNTS.student;
        if (grouped.faculty.length === 0) grouped.faculty = FALLBACK_ACCOUNTS.faculty;
        if (grouped.admin.length === 0) grouped.admin = FALLBACK_ACCOUNTS.admin;

        setAccountList(grouped);
        const currentTabAccounts = grouped[selectedRoleTab] || [];
        if (currentTabAccounts.length > 0) {
          setEmail(currentTabAccounts[0].email);
        }
      })
      .catch(() => {
        // Fallback already pre-set
      });
    return () => {
      isMounted = false;
    };
  }, []);

  // Sync tab when initialRole changes
  useEffect(() => {
    setSelectedRoleTab(initialRole);
    setSelectedAccountIndex(0);
    const accs = accountList[initialRole] || FALLBACK_ACCOUNTS[initialRole];
    if (accs.length > 0) {
      setEmail(accs[0].email);
    }
    setPassword('password123');
  }, [initialRole]);

  const handleRoleSelect = (role: 'student' | 'faculty' | 'admin') => {
    setSelectedRoleTab(role);
    setSelectedAccountIndex(0);
    setErrorMessage('');
    const accs = accountList[role] || FALLBACK_ACCOUNTS[role];
    if (accs.length > 0) {
      setEmail(accs[0].email);
    }
    setPassword('password123');
  };

  const selectAccount = (idx: number) => {
    setSelectedAccountIndex(idx);
    const accs = accountList[selectedRoleTab] || FALLBACK_ACCOUNTS[selectedRoleTab];
    if (accs[idx]) {
      setEmail(accs[idx].email);
      setPassword('password123');
      showToast({
        type: 'info',
        title: 'Account Loaded',
        message: `Selected ${accs[idx].name} (${accs[idx].email}) with default password "password123".`,
      });
    }
  };

  const handleCopyPassword = () => {
    navigator.clipboard.writeText('password123');
    setCopiedPass(true);
    setTimeout(() => setCopiedPass(false), 2000);
    showToast({
      type: 'info',
      message: 'Default password "password123" copied to clipboard.',
    });
  };

  const performLogin = async (loginEmail: string, loginPass: string) => {
    setIsLoading(true);
    setErrorMessage('');

    const trimmedEmail = (loginEmail || '').trim();
    const trimmedPass = (loginPass || '').trim() || 'password123';

    try {
      const redirectPath = await login(trimmedEmail, trimmedPass);
      showToast({
        type: 'success',
        title: 'Authentication Successful',
        message: 'Redirecting to your authorized dashboard...',
      });

      if (redirectPath.includes('student')) {
        onNavigate('student-dashboard');
      } else if (redirectPath.includes('faculty')) {
        onNavigate('faculty-dashboard');
      } else if (redirectPath.includes('admin')) {
        onNavigate('admin-dashboard');
      } else {
        onNavigate('landing');
      }
    } catch (err: any) {
      const msg = err.message || 'Login failed. Please verify your credentials.';
      setErrorMessage(msg);
      showToast({
        type: 'error',
        title: 'Sign In Failed',
        message: msg,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const currentAccs = accountList[selectedRoleTab] || FALLBACK_ACCOUNTS[selectedRoleTab];
    const targetEmail = email.trim() || currentAccs[selectedAccountIndex]?.email || selectedRoleTab;
    const targetPass = password.trim() || 'password123';
    await performLogin(targetEmail, targetPass);
  };

  const handleQuickOneClickLogin = async (acc: DemoAccount) => {
    setSelectedRoleTab(acc.role);
    setEmail(acc.email);
    setPassword('password123');
    await performLogin(acc.email, 'password123');
  };

  const activeAccounts = accountList[selectedRoleTab] || FALLBACK_ACCOUNTS[selectedRoleTab];
  const currentAccount = activeAccounts[selectedAccountIndex] || activeAccounts[0] || FALLBACK_ACCOUNTS[selectedRoleTab][0];

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 transition-colors">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-xl shadow-lg border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
        {/* Top Header */}
        <div className="p-6 bg-slate-900 dark:bg-slate-950 text-white text-center border-b border-slate-800">
          <div className="w-10 h-10 rounded-lg bg-sky-700 mx-auto flex items-center justify-center mb-3 shadow-sm">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Portal Authentication</h1>
          <p className="text-xs text-slate-400 mt-1">
            Student Attendance Processing System
          </p>
        </div>

        {/* Universal Default Password Banner */}
        <div className="bg-sky-50 dark:bg-sky-950/60 border-b border-sky-100 dark:border-sky-900/60 p-3.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-sky-900 dark:text-sky-200">
            <Key className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
            <div>
              <span className="font-semibold block sm:inline">Default Password: </span>
              <code className="font-mono bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded border border-sky-200 dark:border-sky-800 text-sky-800 dark:text-sky-300 font-bold ml-0.5">
                password123
              </code>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block sm:inline sm:ml-1">
                (Universal access for all accounts)
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleCopyPassword}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white dark:bg-slate-800 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 hover:bg-sky-100/70 dark:hover:bg-slate-700 text-[11px] font-medium transition-colors shrink-0 shadow-2xs"
            title="Copy default password"
          >
            {copiedPass ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
            <span>{copiedPass ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Role Switcher Tabs */}
        <div className="p-2 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex gap-1">
          <button
            type="button"
            onClick={() => handleRoleSelect('student')}
            className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 ${
              selectedRoleTab === 'student'
                ? 'bg-white dark:bg-slate-700 text-sky-800 dark:text-sky-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Student</span>
          </button>
          <button
            type="button"
            onClick={() => handleRoleSelect('faculty')}
            className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 ${
              selectedRoleTab === 'faculty'
                ? 'bg-white dark:bg-slate-700 text-sky-800 dark:text-sky-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <School className="w-3.5 h-3.5" />
            <span>Faculty</span>
          </button>
          <button
            type="button"
            onClick={() => handleRoleSelect('admin')}
            className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 ${
              selectedRoleTab === 'admin'
                ? 'bg-white dark:bg-slate-700 text-sky-800 dark:text-sky-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Administrator</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          {/* Quick 1-Click Access Card */}
          <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Default {selectedRoleTab.charAt(0).toUpperCase() + selectedRoleTab.slice(1)} Accounts</span>
              </span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                Password: password123
              </span>
            </div>

            {/* Account Selector Chips if multiple */}
            {activeAccounts.length > 1 && (
              <div className="flex flex-wrap gap-1.5 pt-0.5">
                {activeAccounts.map((acc, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => selectAccount(idx)}
                    className={`px-2.5 py-1 text-[11px] rounded font-medium transition-colors flex items-center gap-1 border ${
                      selectedAccountIndex === idx
                        ? 'bg-sky-100 dark:bg-sky-900/60 text-sky-900 dark:text-sky-200 border-sky-300 dark:border-sky-700'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-750'
                    }`}
                  >
                    <UserCheck className="w-3 h-3 text-sky-600 dark:text-sky-400" />
                    <span>{acc.name}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Current Loaded Details */}
            <div className="text-[11px] font-mono text-slate-600 dark:text-slate-300 space-y-1 bg-white dark:bg-slate-900 p-2.5 rounded border border-slate-200/80 dark:border-slate-800">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-sans">User:</span>
                <span className="font-semibold text-slate-900 dark:text-white font-sans">{currentAccount.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-sans">Email/ID:</span>
                <span className="text-sky-700 dark:text-sky-400 font-medium">{currentAccount.email}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-sans">Password:</span>
                <span className="text-emerald-700 dark:text-emerald-400 font-bold">password123</span>
              </div>
            </div>

            {/* 1-Click Sign In Button */}
            <button
              type="button"
              disabled={isLoading}
              onClick={() => handleQuickOneClickLogin(currentAccount)}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-2xs disabled:opacity-50"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>
                {isLoading ? 'Signing In...' : `1-Click Quick Sign In as ${currentAccount.name}`}
              </span>
            </button>
          </div>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            <span className="flex-shrink mx-2 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Or Sign In with Custom Credentials
            </span>
            <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-md bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 text-xs space-y-1.5">
              <p className="font-medium">{errorMessage}</p>
              <div className="text-[11px] text-rose-700 dark:text-rose-400 flex flex-wrap gap-2 pt-1 border-t border-rose-200 dark:border-rose-900/60">
                <span>Quick Fix:</span>
                <button
                  type="button"
                  onClick={() => handleRoleSelect('student')}
                  className="underline hover:no-underline font-semibold"
                >
                  Student (Aarav)
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => handleRoleSelect('faculty')}
                  className="underline hover:no-underline font-semibold"
                >
                  Faculty (Dr. Priya)
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => handleRoleSelect('admin')}
                  className="underline hover:no-underline font-semibold"
                >
                  Admin
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Institutional Email, Username, or ID
                </label>
                <span className="text-[10px] text-slate-400">
                  accepts {selectedRoleTab} / email / ID / name
                </span>
              </div>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@university.edu or roll number or 'student'/'faculty'/'admin'"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-sans transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setPassword('password123')}
                  className="text-[11px] text-sky-700 dark:text-sky-400 hover:underline font-medium"
                >
                  Use Default (password123)
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-10 py-2 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-sans transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Default password <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">password123</span> works universally for all accounts.
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
            >
              <span>{isLoading ? 'Verifying Credentials...' : `Sign In as ${selectedRoleTab.charAt(0).toUpperCase() + selectedRoleTab.slice(1)}`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Footer info & Navigation */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <button
            onClick={() => onNavigate('register-institution')}
            className="text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 font-medium"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Register Institution</span>
          </button>
          <button
            onClick={() => onNavigate('landing')}
            className="text-slate-600 dark:text-slate-400 hover:underline"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};
