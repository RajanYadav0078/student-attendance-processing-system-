import React, { useState } from 'react';
import {
  Cpu,
  Layers,
  QrCode,
  RotateCcw,
  CheckCircle2,
  ArrowRight,
  Play,
  Zap,
  ShieldCheck,
  Database,
  BarChart3,
  Lock,
} from 'lucide-react';

interface ArchitecturePageProps {
  onNavigate?: (view: string) => void;
}

export const ArchitecturePage: React.FC<ArchitecturePageProps> = ({ onNavigate }) => {
  const [activeCycle, setActiveCycle] = useState<number>(0);

  const processingStages = [
    {
      step: 1,
      name: 'TOKEN GENERATION',
      unit: 'Cryptographic QR Session Generator',
      description: 'The faculty member starts a lecture session. The server generates a unique session token with a dynamic time-to-live (TTL) expiration window and projects the QR code.',
      technicalDetails: 'HMAC-signed session identifier, expiration timestamp, subject & section binding.',
      activeColor: 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-900 dark:text-sky-300',
    },
    {
      step: 2,
      name: 'OPTICAL INGESTION',
      unit: 'Device Camera Scanner & Decoder',
      description: 'The student opens their mobile camera scanner. Video frames are captured in real-time and decoded via client-side matrix scanning algorithms.',
      technicalDetails: 'Continuous HTML5 video frame buffer, client-side canvas parsing, optical QR detection.',
      activeColor: 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-300',
    },
    {
      step: 3,
      name: 'IDENTITY RESOLUTION',
      unit: 'Student Authorization & Roster Matching',
      description: 'The system validates the student bearer token, resolves their verified student record, and confirms enrollment in the targeted class section.',
      technicalDetails: 'RBAC identity resolution, session section comparison, enrollment verification.',
      activeColor: 'border-purple-500 bg-purple-50 dark:bg-purple-950/40 text-purple-900 dark:text-purple-300',
    },
    {
      step: 4,
      name: 'DUPLICATE CHECK',
      unit: 'Anti-Proxy Guard & State Validator',
      description: 'The engine verifies if the student has already marked attendance for this session. Expired QR tokens and duplicate check-ins are strictly rejected.',
      technicalDetails: 'Relational uniqueness constraint (student_id + session_id), TTL expiration comparator.',
      activeColor: 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300',
    },
    {
      step: 5,
      name: 'PERCENTAGE ENGINE',
      unit: 'Real-Time Cumulative Calculation Engine',
      description: 'Upon recording presence, the calculation engine dynamically recomputes (Attended / Total Classes) × 100 and compares against the 75% institutional eligibility threshold.',
      technicalDetails: 'Dynamic aggregate computation, defaulter flag resolution, instant compliance status.',
      activeColor: 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-300',
    },
    {
      step: 6,
      name: 'PERSISTENCE MATRIX',
      unit: 'Relational Transaction Ledger',
      description: 'The verified record (student ID, subject, method "QR", timestamp, status "present") is committed to the relational database with full transaction isolation.',
      technicalDetails: 'Atomic database write, LIFO state snapshot pushed for faculty undo operations.',
      activeColor: 'border-blue-500 bg-blue-50 dark:bg-blue-950/40 text-blue-900 dark:text-blue-300',
    },
    {
      step: 7,
      name: 'REAL-TIME DISPATCH',
      unit: 'Audit Log & Dashboard Notification Dispatcher',
      description: 'Real-time WebSocket and polling streams update the faculty live roster, student dashboard widgets, and administrative defaulter tallies.',
      technicalDetails: 'Live attendee counter increment, instant student profile sync, PDF report generator ready.',
      activeColor: 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 text-teal-900 dark:text-teal-300',
    },
  ];

  const handleNextCycle = () => {
    setActiveCycle((prev) => (prev + 1) % processingStages.length);
  };

  const handleResetCycle = () => {
    setActiveCycle(0);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Page Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-6 transition-colors">
        <div className="flex items-center gap-2 text-xs font-semibold text-sky-700 dark:text-sky-400">
          <span>System Architecture & Engineering</span>
          <span aria-hidden="true">·</span>
          <span>Technical Blueprint</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white mt-1">
          Attendance Processing Engine Architecture
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-2 max-w-3xl leading-relaxed">
          Comprehensive data flow, verification protocols, and calculation pipeline powering the Student Attendance Processing System.
        </p>
      </div>

      {/* Visual Architectural Banner */}
      <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm bg-slate-900 relative aspect-21/9 max-h-64">
        <img
          src="/src/assets/images/arch_processor_chip_1790872574138.jpg"
          alt="High-Speed Processing Datapath"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/50 to-transparent flex flex-col justify-center px-8 text-white">
          <span className="text-xs font-mono text-sky-400">REAL-TIME PROCESSING FLOW</span>
          <h2 className="text-xl sm:text-2xl font-bold mt-1">Automated Attendance Pipeline</h2>
          <p className="text-xs text-slate-300 max-w-lg mt-1">
            Explore the multi-tier flow from dynamic QR generation through camera ingestion, anti-proxy verification, and relational persistence.
          </p>
        </div>
      </div>

      {/* Interactive Datapath Simulator */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-sky-700 dark:text-sky-400" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Interactive Processing Pipeline</h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Step through the stages of student attendance ingestion and verification.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleResetCycle}
              className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
            <button
              onClick={handleNextCycle}
              className="px-4 py-1.5 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Step Next Stage ({activeCycle + 1}/7)</span>
            </button>
          </div>
        </div>

        {/* Pipeline Stage Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {processingStages.map((stage, idx) => {
            const isCurrent = activeCycle === idx;
            const isPassed = activeCycle > idx;

            return (
              <button
                key={stage.step}
                onClick={() => setActiveCycle(idx)}
                className={`p-3 rounded-lg border text-left transition-all relative ${
                  isCurrent
                    ? 'border-sky-600 dark:border-sky-500 bg-sky-50 dark:bg-sky-950/60 shadow-sm ring-1 ring-sky-500/20'
                    : isPassed
                    ? 'border-emerald-200 dark:border-emerald-800/80 bg-emerald-50/40 dark:bg-emerald-950/30 text-slate-700 dark:text-slate-300'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                  <span>STAGE {stage.step}</span>
                  {isPassed && <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />}
                </div>
                <div className={`text-xs font-bold truncate ${isCurrent ? 'text-sky-900 dark:text-sky-200' : 'text-slate-800 dark:text-slate-200'}`}>
                  {stage.name}
                </div>
              </button>
            );
          })}
        </div>

        {/* Current Active Pipeline Stage Detail */}
        <div className="p-5 rounded-lg border border-sky-200 dark:border-sky-800 bg-sky-50/50 dark:bg-sky-950/30 space-y-3 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-sky-800 dark:text-sky-300 uppercase tracking-wide">
              Active Stage {processingStages[activeCycle].step}: {processingStages[activeCycle].name}
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
              Component: {processingStages[activeCycle].unit}
            </span>
          </div>

          <h3 className="text-base font-bold text-slate-900 dark:text-white">{processingStages[activeCycle].unit}</h3>
          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            {processingStages[activeCycle].description}
          </p>
          <div className="pt-2 border-t border-sky-200/60 dark:border-sky-800/60 text-xs text-slate-600 dark:text-slate-400 font-mono">
            <strong>Technical Protocol:</strong> {processingStages[activeCycle].technicalDetails}
          </div>
        </div>
      </div>

      {/* Systematic Architecture Modules */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
          <div className="w-9 h-9 rounded-md bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Security & Proxy Prevention</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Sessions enforce dynamic cryptographic tokens that expire after configurable minutes. Single-use uniqueness constraints prevent shared screenshots or replay attacks.
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
          <div className="w-9 h-9 rounded-md bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Instant Math & 75% Cutoff</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Attendance percentages are calculated in real time: (Classes Attended / Total Classes) × 100. Any score below 75% automatically generates defaulter alerts.
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
          <div className="w-9 h-9 rounded-md bg-sky-50 dark:bg-sky-950/60 flex items-center justify-center text-sky-700 dark:text-sky-400">
            <Database className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Relational Integrity & Rollback</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Structured relational tables enforce foreign keys across students, subjects, and sessions, with complete session-level rollback for undoing accidental batch marks.
          </p>
        </div>
      </div>
    </div>
  );
};
