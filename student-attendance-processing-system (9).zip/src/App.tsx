import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { NotificationProvider } from './context/NotificationContext.tsx';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { Sidebar } from './components/layout/Sidebar.tsx';
import { RFIDSimulatorModal } from './components/attendance/RFIDSimulatorModal.tsx';
import { QRScannerModal } from './components/attendance/QRScannerModal.tsx';

// Public Pages
import { LandingPage } from './pages/LandingPage.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { AboutPage } from './pages/AboutPage.tsx';
import { ArchitecturePage } from './pages/ArchitecturePage.tsx';
import { InstitutionRegistrationPage } from './pages/InstitutionRegistrationPage.tsx';

// Student Pages
import { StudentDashboard } from './pages/student/StudentDashboard.tsx';
import { MyAttendancePage } from './pages/student/MyAttendancePage.tsx';
import { AttendanceHistoryPage } from './pages/student/AttendanceHistoryPage.tsx';
import { StudentReportsPage } from './pages/student/StudentReportsPage.tsx';
import { StudentProfilePage } from './pages/student/StudentProfilePage.tsx';
import { StudentRequestsPage } from './pages/student/StudentRequestsPage.tsx';

// Faculty Pages
import { FacultyDashboard } from './pages/faculty/FacultyDashboard.tsx';
import { CreateSessionPage } from './pages/faculty/CreateSessionPage.tsx';
import { MarkAttendancePage } from './pages/faculty/MarkAttendancePage.tsx';
import { FacultyHistoryPage } from './pages/faculty/FacultyHistoryPage.tsx';
import { FacultyReportsPage } from './pages/faculty/FacultyReportsPage.tsx';
import { FacultyRequestsPage } from './pages/faculty/FacultyRequestsPage.tsx';

// Admin Pages
import { AdminDashboard } from './pages/admin/AdminDashboard.tsx';
import { ManageStudentsPage } from './pages/admin/ManageStudentsPage.tsx';
import { ManageFacultyPage } from './pages/admin/ManageFacultyPage.tsx';
import { ManageSubjectsPage } from './pages/admin/ManageSubjectsPage.tsx';
import { MasterAttendancePage } from './pages/admin/MasterAttendancePage.tsx';
import { DefaulterManagementPage } from './pages/admin/DefaulterManagementPage.tsx';
import { AdminReportsPage } from './pages/admin/AdminReportsPage.tsx';
import { SystemSettingsPage } from './pages/admin/SystemSettingsPage.tsx';
import { AdminManagementPage } from './pages/admin/AdminManagementPage.tsx';
import { AdminRequestsPage } from './pages/admin/AdminRequestsPage.tsx';

const MainLayout: React.FC = () => {
  const { user, role, isAuthenticated, isLoading } = useAuth();
  const [currentView, setCurrentView] = useState<string>('landing');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isRfidModalOpen, setIsRfidModalOpen] = useState<boolean>(false);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState<boolean>(false);

  // Sync hash in URL with view
  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash) {
      setCurrentView(hash);
    }
  }, []);

  const navigateTo = (view: string) => {
    if (view === 'rfid-simulator') {
      setIsRfidModalOpen(true);
      return;
    }
    if (view === 'student-scanner') {
      setIsQrScannerOpen(true);
      return;
    }

    setCurrentView(view);
    window.location.hash = view;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Auto redirect upon auth state resolution if needed
  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated && currentView.includes('dashboard')) {
        setCurrentView('login');
      }
    }
  }, [isAuthenticated, isLoading, currentView]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 transition-colors">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-sky-700 dark:border-sky-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-medium text-slate-600 dark:text-slate-400 font-sans">
            Loading Attendance Processing System...
          </span>
        </div>
      </div>
    );
  }

  // Determine whether to show sidebar (only when authenticated and not on landing / login / about / architecture / register-institution)
  const isPublicStandaloneView =
    currentView === 'landing' ||
    currentView.startsWith('login') ||
    currentView === 'about' ||
    currentView === 'architecture' ||
    currentView === 'register-institution';

  const showSidebar = isAuthenticated && !isPublicStandaloneView;

  const renderContent = () => {
    // Public routes
    if (currentView === 'landing') return <LandingPage onNavigate={navigateTo} />;
    if (currentView === 'register-institution') return <InstitutionRegistrationPage onNavigate={navigateTo} />;
    if (currentView === 'login' || currentView.startsWith('login-')) {
      const initialRole: 'student' | 'faculty' | 'admin' =
        currentView === 'login-faculty' ? 'faculty' : currentView === 'login-admin' ? 'admin' : 'student';
      return <LoginPage onNavigate={navigateTo} initialRole={initialRole} />;
    }
    if (currentView === 'about') return <AboutPage />;
    if (currentView === 'architecture') return <ArchitecturePage onNavigate={navigateTo} />;

    // Protected Student Routes
    if (role === 'student' || currentView.startsWith('student-')) {
      switch (currentView) {
        case 'student-dashboard':
          return <StudentDashboard onNavigate={navigateTo} />;
        case 'student-attendance':
          return <MyAttendancePage onNavigate={navigateTo} />;
        case 'student-history':
          return <AttendanceHistoryPage onNavigate={navigateTo} />;
        case 'student-reports':
          return <StudentReportsPage onNavigate={navigateTo} />;
        case 'student-requests':
          return <StudentRequestsPage onNavigate={navigateTo} />;
        case 'student-profile':
          return <StudentProfilePage />;
        default:
          return <StudentDashboard onNavigate={navigateTo} />;
      }
    }

    // Protected Faculty Routes
    if (role === 'faculty' || currentView.startsWith('faculty-')) {
      switch (currentView) {
        case 'faculty-dashboard':
          return <FacultyDashboard onNavigate={navigateTo} />;
        case 'faculty-create-session':
          return <CreateSessionPage onNavigate={navigateTo} />;
        case 'faculty-mark':
          return <MarkAttendancePage onNavigate={navigateTo} />;
        case 'faculty-history':
          return <FacultyHistoryPage />;
        case 'faculty-requests':
          return <FacultyRequestsPage onNavigate={navigateTo} />;
        case 'faculty-analytics':
        case 'faculty-reports':
          return <FacultyReportsPage />;
        default:
          return <FacultyDashboard onNavigate={navigateTo} />;
      }
    }

    // Protected Admin Routes
    if (role === 'admin' || currentView.startsWith('admin-')) {
      switch (currentView) {
        case 'admin-dashboard':
          return <AdminDashboard onNavigate={navigateTo} />;
        case 'admin-students':
          return <ManageStudentsPage />;
        case 'admin-faculty':
          return <ManageFacultyPage />;
        case 'admin-subjects':
          return <ManageSubjectsPage />;
        case 'admin-records':
          return <MasterAttendancePage />;
        case 'admin-defaulters':
          return <DefaulterManagementPage />;
        case 'admin-reports':
          return <AdminReportsPage />;
        case 'admin-management':
          return <AdminManagementPage />;
        case 'admin-settings':
          return <SystemSettingsPage />;
        default:
          return <AdminDashboard onNavigate={navigateTo} />;
      }
    }

    return <LandingPage onNavigate={navigateTo} />;
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-150">
      <Navbar
        currentView={currentView}
        onNavigate={navigateTo}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <div className="flex-1 flex">
        {showSidebar && (
          <Sidebar
            currentView={currentView}
            onNavigate={navigateTo}
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
          />
        )}

        <main className={`flex-1 transition-all ${showSidebar ? 'lg:pl-64' : ''}`}>
          {renderContent()}
        </main>
      </div>

      {/* RFID Simulation Modal */}
      <RFIDSimulatorModal
        isOpen={isRfidModalOpen}
        onClose={() => setIsRfidModalOpen(false)}
      />

      {/* QR Scanner Modal */}
      <QRScannerModal
        isOpen={isQrScannerOpen}
        onClose={() => setIsQrScannerOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <MainLayout />
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
