import React from 'react';
import { SubjectAttendanceSummary } from '../../types/index.ts';

interface SubjectBarChartProps {
  subjects: Array<SubjectAttendanceSummary | { subject_code: string; subject_name: string; average_attendance?: number; attendance_percentage?: number }>;
  threshold?: number;
}

export const SubjectBarChart: React.FC<SubjectBarChartProps> = ({ subjects, threshold = 75 }) => {
  if (!subjects || subjects.length === 0) {
    return (
      <div className="p-8 text-center text-xs text-slate-400 dark:text-slate-500 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
        No subject data available
      </div>
    );
  }

  return (
    <div className="w-full bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Subject-wise Attendance Distribution</h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">Threshold: {threshold}% minimum required</span>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
            <span className="w-3 h-3 rounded-xs bg-sky-700 dark:bg-sky-500" />
            <span>Eligible ({`≥`}{threshold}%)</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
            <span className="w-3 h-3 rounded-xs bg-rose-600" />
            <span>Shortage ({`<`}{threshold}%)</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {subjects.map((item, idx) => {
          const code = item.subject_code;
          const name = item.subject_name;
          const pct = 'attendance_percentage' in item && item.attendance_percentage !== undefined
            ? item.attendance_percentage
            : (item as any).average_attendance || 0;

          const isEligible = pct >= threshold;

          return (
            <div key={idx} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 max-w-[70%]">
                  <span className="font-mono font-medium text-slate-800 dark:text-slate-200">{code}</span>
                  <span className="text-slate-500 dark:text-slate-400 truncate hidden sm:inline">· {name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-semibold tabular-nums text-slate-900 dark:text-white">{pct}%</span>
                  <span className={`text-[11px] font-medium ${isEligible ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}`}>
                    {isEligible ? 'Eligible' : 'Shortage'}
                  </span>
                </div>
              </div>

              {/* Progress bar with threshold indicator */}
              <div className="relative w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-sm overflow-hidden">
                {/* 75% Target Marker */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-slate-400 dark:bg-slate-500 z-10"
                  style={{ left: `${threshold}%` }}
                  title={`Threshold: ${threshold}%`}
                />
                <div
                  className={`h-full rounded-sm transition-all duration-500 ${
                    isEligible ? 'bg-sky-700 dark:bg-sky-500' : 'bg-rose-600'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
