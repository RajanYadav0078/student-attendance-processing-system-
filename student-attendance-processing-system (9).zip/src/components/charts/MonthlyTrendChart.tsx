import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext.tsx';

interface MonthlyDataPoint {
  month: string;
  percentage: number;
  totalClasses: number;
  attended: number;
}

interface MonthlyTrendChartProps {
  data?: MonthlyDataPoint[];
}

export const MonthlyTrendChart: React.FC<MonthlyTrendChartProps> = ({ data }) => {
  const { isDark } = useTheme();
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const defaultData: MonthlyDataPoint[] = [
    { month: 'Jul', percentage: 92, totalClasses: 25, attended: 23 },
    { month: 'Aug', percentage: 86, totalClasses: 32, attended: 28 },
    { month: 'Sep', percentage: 84, totalClasses: 38, attended: 32 },
    { month: 'Oct', percentage: 88, totalClasses: 18, attended: 16 },
  ];

  const points = data && data.length > 0 ? data : defaultData;

  const width = 500;
  const height = 180;
  const paddingX = 40;
  const paddingY = 30;

  const minVal = 50;
  const maxVal = 100;

  const getX = (index: number) => {
    return paddingX + (index * (width - 2 * paddingX)) / (points.length - 1);
  };

  const getY = (val: number) => {
    const clamped = Math.min(maxVal, Math.max(minVal, val));
    return height - paddingY - ((clamped - minVal) * (height - 2 * paddingY)) / (maxVal - minVal);
  };

  const linePath = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.percentage)}`)
    .join(' ');

  const areaPath = `${linePath} L ${getX(points.length - 1)} ${height - paddingY} L ${getX(0)} ${height - paddingY} Z`;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-800 w-full transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Monthly Attendance Velocity</h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">Tracking aggregate consistency across Semester 3</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
          <span className="w-2 h-0.5 bg-sky-700 dark:bg-sky-400 inline-block" />
          <span>75% Compliance Target</span>
        </div>
      </div>

      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-44 overflow-visible">
          {/* 75% Reference Guideline */}
          <line
            x1={paddingX}
            y1={getY(75)}
            x2={width - paddingX}
            y2={getY(75)}
            stroke={isDark ? '#475569' : '#cbd5e1'}
            strokeDasharray="4 4"
            strokeWidth="1"
          />
          <text
            x={paddingX - 6}
            y={getY(75) + 3}
            textAnchor="end"
            fontSize="10"
            fill={isDark ? '#94a3b8' : '#64748b'}
            fontFamily="monospace"
          >
            75%
          </text>

          {/* Shaded Area */}
          <path d={areaPath} fill={isDark ? 'rgba(56, 189, 248, 0.12)' : 'rgba(3, 105, 161, 0.08)'} />

          {/* Trend Line */}
          <path
            d={linePath}
            fill="none"
            stroke={isDark ? '#38bdf8' : '#0369a1'}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Data Points */}
          {points.map((p, i) => {
            const cx = getX(i);
            const cy = getY(p.percentage);
            const isHovered = hoveredIdx === i;

            return (
              <g key={i}>
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 6 : 4}
                  fill={isDark ? '#0f172a' : '#ffffff'}
                  stroke={isDark ? '#38bdf8' : '#0369a1'}
                  strokeWidth="2.5"
                  className="cursor-pointer transition-all"
                  onMouseEnter={() => setHoveredIdx(i)}
                  onMouseLeave={() => setHoveredIdx(null)}
                />
                {/* Month Label */}
                <text
                  x={cx}
                  y={height - 8}
                  textAnchor="middle"
                  fontSize="11"
                  fill={isDark ? '#94a3b8' : '#475569'}
                  fontWeight="500"
                >
                  {p.month}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip */}
        {hoveredIdx !== null && (
          <div
            className="absolute -top-3 bg-slate-900 text-white dark:bg-slate-800 dark:border dark:border-slate-700 text-xs px-2.5 py-1.5 rounded-md shadow-md pointer-events-none transform -translate-x-1/2 -translate-y-full"
            style={{
              left: `${(getX(hoveredIdx) / width) * 100}%`,
              top: `${(getY(points[hoveredIdx].percentage) / height) * 100}%`,
            }}
          >
            <div className="font-semibold">{points[hoveredIdx].month} Attendance</div>
            <div className="font-mono text-sky-300">
              {points[hoveredIdx].percentage}% ({points[hoveredIdx].attended}/{points[hoveredIdx].totalClasses} classes)
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
