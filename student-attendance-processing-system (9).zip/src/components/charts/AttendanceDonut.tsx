import React from 'react';
import { useTheme } from '../../context/ThemeContext.tsx';

interface AttendanceDonutProps {
  present: number;
  absent: number;
  size?: number;
}

export const AttendanceDonut: React.FC<AttendanceDonutProps> = ({
  present,
  absent,
  size = 180,
}) => {
  const { isDark } = useTheme();
  const total = present + absent;
  const percentage = total > 0 ? Number(((present / total) * 100).toFixed(1)) : 0;

  const strokeWidth = 16;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background Track (Absent / Remaining) */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke={isDark ? '#334155' : '#f1f5f9'}
            strokeWidth={strokeWidth}
          />
          {/* Present Arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke={percentage >= 75 ? (isDark ? '#38bdf8' : '#0284c7') : '#e11d48'}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Center Readout */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
            {percentage}%
          </span>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">
            {percentage >= 75 ? 'Eligible' : 'Shortage'}
          </span>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-center gap-6 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-sky-700 dark:bg-sky-400" />
          <span className="text-slate-600 dark:text-slate-400">
            Present: <strong className="text-slate-900 dark:text-white font-mono tabular-nums">{present}</strong>
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
          <span className="text-slate-600 dark:text-slate-400">
            Absent: <strong className="text-slate-900 dark:text-white font-mono tabular-nums">{absent}</strong>
          </span>
        </div>
      </div>
    </div>
  );
};
