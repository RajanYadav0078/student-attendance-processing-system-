import React from 'react';
import { StudentAttendanceProfile, SubjectAttendanceSummary } from '../../types/index.ts';
import { Printer, Download, ArrowLeft } from 'lucide-react';

interface PrintableReportProps {
  profile?: StudentAttendanceProfile;
  title?: string;
  isInstituteReport?: boolean;
  instituteStats?: any;
  defaulters?: any[];
  onBack?: () => void;
}

export const PrintableReport: React.FC<PrintableReportProps> = ({
  profile,
  title = 'Student Attendance Cumulative Audit Report',
  isInstituteReport,
  instituteStats,
  defaulters,
  onBack,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (profile) {
      csvContent += 'Roll Number,Student Name,Branch,Semester,Section,Overall Percentage,Eligibility\n';
      csvContent += `"${profile.student.roll_number}","${profile.student.name}","${profile.student.branch}",${profile.student.semester},"${profile.student.section}",${profile.overall_percentage}%,${profile.is_eligible ? 'Eligible' : 'Shortage'}\n\n`;
      csvContent += 'Subject Code,Subject Name,Faculty,Total Classes,Attended,Absent,Percentage,Status\n';
      profile.subjects.forEach((s) => {
        csvContent += `"${s.subject_code}","${s.subject_name}","${s.faculty_name}",${s.total_classes},${s.attended_classes},${s.absent_classes},${s.attendance_percentage}%,${s.is_eligible ? 'Eligible' : 'Shortage'}\n`;
      });
    } else if (defaulters) {
      csvContent += 'Roll Number,Student Name,Section,Overall Percentage,Defaulter Subjects\n';
      defaulters.forEach((d) => {
        const subjs = d.defaulterSubjects?.map((s: any) => s.subject_code).join('; ') || '';
        const roll = d.student?.roll_number || d.roll_number || '';
        const name = d.student?.name || d.name || '';
        const sec = d.student?.section || d.section || '';
        csvContent += `"${roll}","${name}","${sec}",${d.overall_percentage}%,"${subjs}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Attendance_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Action Bar (hidden during printing) */}
      <div className="print:hidden flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-200 dark:border-slate-800 transition-colors">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={onBack}
              className="p-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 mr-2 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Print / Export Document</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md border border-slate-200 dark:border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium text-white bg-sky-700 hover:bg-sky-800 rounded-md transition-colors shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report (PDF)</span>
          </button>
        </div>
      </div>

      {/* Printable Sheet Viewport */}
      <div className="bg-white dark:bg-slate-900 p-8 sm:p-12 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm print:border-none print:shadow-none print:p-0 print:bg-white print:text-black transition-colors">
        {/* Academic Header */}
        <div className="text-center border-b-2 border-slate-900 dark:border-slate-700 print:border-slate-900 pb-6 mb-6">
          <div className="text-xs font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400 print:text-slate-600">
            College of Engineering & Technology · Autonomous Institution
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-950 dark:text-white print:text-slate-950 mt-1">
            Student Attendance Processing System
          </h1>
          <div className="text-xs text-slate-600 dark:text-slate-400 print:text-slate-600 mt-1">
            Department of Computer Science & Engineering
          </div>
          <div className="mt-3 inline-block px-3 py-1 bg-slate-100 dark:bg-slate-800 print:bg-slate-100 text-slate-800 dark:text-slate-200 print:text-slate-800 text-xs font-semibold font-mono rounded-xs border border-slate-200 dark:border-slate-700 print:border-none">
            {title}
          </div>
        </div>

        {/* Individual Student Report Details */}
        {profile && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 dark:bg-slate-800/60 print:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-md mb-6 text-xs">
              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Student Name</span>
                <span className="font-bold text-slate-900 dark:text-white print:text-slate-900 text-sm">{profile.student.name}</span>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Roll Number</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white print:text-slate-900 text-sm">{profile.student.roll_number}</span>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Branch & Semester</span>
                <span className="font-medium text-slate-800 dark:text-slate-200 print:text-slate-800">CSE · Semester 3 (Sec {profile.student.section})</span>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-semibold">Student Card ID</span>
                <span className="font-mono text-slate-800 dark:text-slate-200 print:text-slate-800">{profile.student.rfid_id}</span>
              </div>
            </div>

            {/* Overall Attendance Summary Banner */}
            <div className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-md mb-6 bg-white dark:bg-slate-800/40 print:bg-white">
              <div>
                <span className="text-xs text-slate-500 dark:text-slate-400 block">Overall Cumulative Attendance</span>
                <div className="text-2xl font-bold font-mono text-slate-950 dark:text-white print:text-slate-950">
                  {profile.overall_percentage}%
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">Ordinance Eligibility Status</span>
                <div
                  className={`text-sm font-bold ${
                    profile.is_eligible ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                  }`}
                >
                  {profile.is_eligible ? 'Eligible for End-Sem Exam' : 'Attendance Shortage (Defaulter)'}
                </div>
              </div>
            </div>

            {/* Subject Breakdown Table */}
            <div className="overflow-x-auto mb-8">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 print:bg-slate-100 text-slate-700 dark:text-slate-300 print:text-slate-700 font-semibold">
                    <th className="py-2.5 px-3">Subject Code</th>
                    <th className="py-2.5 px-3">Subject Name</th>
                    <th className="py-2.5 px-3">Faculty</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3 text-right">Attended</th>
                    <th className="py-2.5 px-3 text-right">Absent</th>
                    <th className="py-2.5 px-3 text-right">Percentage</th>
                    <th className="py-2.5 px-3 text-center">Eligibility</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 print:divide-slate-200">
                  {profile.subjects.map((sub: SubjectAttendanceSummary) => (
                    <tr key={sub.subject_id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 print:hover:bg-transparent">
                      <td className="py-2.5 px-3 font-mono font-medium text-slate-900 dark:text-white print:text-slate-900">{sub.subject_code}</td>
                      <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200 print:text-slate-800 font-medium">{sub.subject_name}</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400 print:text-slate-600">{sub.faculty_name}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200 print:text-slate-800">{sub.total_classes}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400 font-semibold">
                        {sub.attended_classes}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500 dark:text-slate-400">{sub.absent_classes}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900 dark:text-white print:text-slate-900">
                        {sub.attendance_percentage}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`font-semibold ${
                            sub.is_eligible ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
                          }`}
                        >
                          {sub.is_eligible ? 'Eligible' : 'Defaulter'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Master / Defaulter Table if Institute Report */}
        {defaulters && (
          <div className="overflow-x-auto mb-8">
            <div className="mb-4 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 print:text-slate-600">
              <span>Total Defaulter Students Identified: <strong className="text-slate-900 dark:text-white print:text-slate-900">{defaulters.length}</strong></span>
              <span>Regulatory Threshold: <strong>75%</strong></span>
            </div>
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 print:bg-slate-100 text-slate-700 dark:text-slate-300 print:text-slate-700 font-semibold">
                  <th className="py-2.5 px-3">Roll No</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Section</th>
                  <th className="py-2.5 px-3 text-right">Overall %</th>
                  <th className="py-2.5 px-3">Shortage Courses</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 print:divide-slate-200">
                {defaulters.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-400 dark:text-slate-500">
                      No defaulters identified. All students meet the required attendance threshold.
                    </td>
                  </tr>
                ) : (
                  defaulters.map((d: any, idx: number) => (
                    <tr key={d.student?.id || d.id || idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 print:hover:bg-transparent">
                      <td className="py-2.5 px-3 font-mono font-medium text-slate-900 dark:text-white print:text-slate-900">{d.student?.roll_number || d.roll_number}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white print:text-slate-900">{d.student?.name || d.name}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-400">{d.student?.section || d.section}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700 dark:text-rose-400">
                        {d.overall_percentage}%
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                        {d.defaulterSubjects?.map((s: any) => `${s.subject_code} (${s.attendance_percentage}%)`).join(', ') || 'Overall Aggregate'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Academic Verification Signatures */}
        <div className="pt-12 mt-8 border-t border-slate-300 dark:border-slate-700 print:border-slate-300 grid grid-cols-3 gap-6 text-center text-xs text-slate-600 dark:text-slate-400 print:text-slate-600">
          <div>
            <div className="h-10 border-b border-slate-400 dark:border-slate-600 print:border-slate-400 mb-2 w-3/4 mx-auto" />
            <span className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">Faculty In-Charge</span>
            <div className="text-[10px] text-slate-400">Course Coordinator</div>
          </div>
          <div>
            <div className="h-10 border-b border-slate-400 dark:border-slate-600 print:border-slate-400 mb-2 w-3/4 mx-auto" />
            <span className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">Class Mentor</span>
            <div className="text-[10px] text-slate-400">CSE Department</div>
          </div>
          <div>
            <div className="h-10 border-b border-slate-400 dark:border-slate-600 print:border-slate-400 mb-2 w-3/4 mx-auto" />
            <span className="font-semibold text-slate-800 dark:text-slate-200 print:text-slate-800">Head of Department</span>
            <div className="text-[10px] text-slate-400">Dean of Academics</div>
          </div>
        </div>

        {/* Footer timestamp */}
        <div className="mt-8 text-center text-[10px] text-slate-400 dark:text-slate-500 print:text-slate-400">
          Generated automatically by Student Attendance Processing System on {new Date().toLocaleString()} · Institutional Attendance Management Registry
        </div>
      </div>
    </div>
  );
};
