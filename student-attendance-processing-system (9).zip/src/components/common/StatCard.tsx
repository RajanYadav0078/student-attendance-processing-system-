import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  subtext?: string;
  icon?: LucideIcon;
  trend?: {
    value: string;
    isPositive?: boolean;
  };
  highlight?: boolean;
  badge?: {
    text: string;
    variant: 'success' | 'warning' | 'danger' | 'info';
  };
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  icon: Icon,
  trend,
  highlight,
  badge,
}) => {
  return (
    <div
      className={`bg-white dark:bg-slate-900 rounded-lg p-5 border transition-all ${
        highlight
          ? 'border-sky-500 shadow-sm ring-1 ring-sky-500/20'
          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate">{label}</span>
        {Icon && (
          <div className="w-8 h-8 rounded-md bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-750 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white font-mono tabular-nums">
          {value}
        </span>
        {trend && (
          <span
            className={`text-xs font-medium ${
              trend.isPositive ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'
            }`}
          >
            {trend.value}
          </span>
        )}
      </div>

      {(subtext || badge) && (
        <div className="mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          {subtext && <span className="truncate">{subtext}</span>}
          {badge && (
            <span
              className={`font-medium ${
                badge.variant === 'success'
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : badge.variant === 'warning'
                  ? 'text-amber-700 dark:text-amber-400'
                  : badge.variant === 'danger'
                  ? 'text-rose-700 dark:text-rose-400'
                  : 'text-sky-700 dark:text-sky-400'
              }`}
            >
              {badge.text}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
