import React, { useState, useEffect } from 'react';
import { Radio, X, Cpu, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { api } from '../../services/api.ts';
import { AttendanceSession, Student } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';

interface RFIDSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetSessionId?: string;
}

export const RFIDSimulatorModal: React.FC<RFIDSimulatorModalProps> = ({
  isOpen,
  onClose,
  targetSessionId,
}) => {
  const { showToast } = useNotification();
  const [rfidTagInput, setRfidTagInput] = useState<string>('RFID-00123');
  const [selectedSessionId, setSelectedSessionId] = useState<string>(targetSessionId || '');
  const [students, setStudents] = useState<Student[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    student?: Student;
    record?: any;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  const loadData = async () => {
    try {
      const allStudents = await api.getStudents();
      setStudents(allStudents);

      const subjects = await api.getSubjects();
      if (subjects.length > 0 && !selectedSessionId) {
        const defaultSession = await api.createSession({
          subjectId: subjects[0].id,
          section: 'A',
          lectureTopic: 'Smart Card Verification Session',
          durationMinutes: 60,
        });
        setSelectedSessionId(defaultSession.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSimulateTap = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!rfidTagInput.trim() || !selectedSessionId) {
      showToast({
        type: 'warning',
        message: 'Please provide both RFID UID and an active session',
      });
      return;
    }

    setIsProcessing(true);
    setResult(null);

    try {
      const res = await api.tapRfid(rfidTagInput.trim(), selectedSessionId);
      setResult({
        success: true,
        message: res.message,
        student: res.student,
        record: res.record,
      });

      showToast({
        type: 'success',
        title: 'Smart Card Tag Processed',
        message: `Validated student ${res.student.name} (${res.student.roll_number})`,
      });
    } catch (err: any) {
      setResult({
        success: false,
        message: err.message || 'Could not resolve RFID tag',
      });
      showToast({
        type: 'error',
        title: 'Resolution Failure',
        message: err.message || 'Unrecognized RFID Tag',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-sky-400" />
            <div>
              <h2 className="text-sm font-semibold">Contactless RFID / Smart Card Simulation</h2>
              <p className="text-[11px] text-slate-400">
                Hardware Integration Testing Interface
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice */}
        <div className="bg-sky-50 dark:bg-sky-950/40 px-5 py-2.5 border-b border-sky-100 dark:border-sky-900/50 flex items-start gap-2.5 text-xs text-sky-900 dark:text-sky-200">
          <Cpu className="w-4 h-4 text-sky-700 dark:text-sky-400 shrink-0 mt-0.5" />
          <div>
            <strong className="font-semibold">Notice:</strong> This interface simulates contactless card taps by resolving card UIDs against student database records.
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Status Result */}
          {result && (
            <div
              className={`p-3.5 rounded-lg border text-xs flex items-start gap-3 ${
                result.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
              }`}
            >
              {result.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <div className="font-semibold">{result.success ? 'Attendance Recorded' : 'Check-In Error'}</div>
                <div className="mt-0.5 leading-relaxed">{result.message}</div>
                {result.student && (
                  <div className="mt-1 font-mono text-[11px] text-emerald-800 dark:text-emerald-300">
                    Roll: {result.student.roll_number} · Section: {result.student.section}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSimulateTap} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                RFID Tag Identifier / Card Serial Number
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={rfidTagInput}
                  onChange={(e) => setRfidTagInput(e.target.value)}
                  placeholder="e.g. RFID-00123"
                  className="flex-1 px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                />
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>{isProcessing ? 'Reading...' : 'Simulate Tap'}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Sample RFID Tags for Quick Testing */}
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-2">
              Registered Student Cards (Click to Test Tap)
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs max-h-40 overflow-y-auto">
              {students.slice(0, 6).map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setRfidTagInput(st.rfid_id)}
                  className={`p-2 rounded-md border text-left transition-colors flex flex-col ${
                    rfidTagInput === st.rfid_id
                      ? 'border-sky-500 bg-sky-50/50 dark:bg-sky-950/40 text-sky-900 dark:text-sky-200'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="font-semibold truncate">{st.name}</span>
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-1">
                    <span>{st.roll_number}</span>
                    <span className="text-sky-700 dark:text-sky-400 font-semibold">{st.rfid_id}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-md transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
