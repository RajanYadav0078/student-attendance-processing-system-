import React, { useState, useEffect, useRef } from 'react';
import jsQR from 'jsqr';
import {
  Camera,
  X,
  CheckCircle2,
  AlertTriangle,
  Upload,
  KeyRound,
  Sparkles,
  MapPin,
  ShieldCheck,
  ShieldAlert,
  Navigation,
} from 'lucide-react';
import { api } from '../../services/api.ts';
import { GeofenceConfig } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { showToast } = useNotification();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const requestAnimRef = useRef<number | null>(null);

  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [manualToken, setManualToken] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<{
    success: boolean;
    message: string;
    time?: string;
    isDuplicate?: boolean;
    isGeofenceBreach?: boolean;
    distance?: number;
  } | null>(null);
  const [recentToken, setRecentToken] = useState<string | null>(null);

  // GPS & Campus Geofence State
  const [geofenceConfig, setGeofenceConfig] = useState<GeofenceConfig>({
    enabled: true,
    campus_name: 'NIET Greater Noida Campus',
    latitude: 28.4632,
    longitude: 77.4939,
    radius_meters: 500,
  });
  const [gpsMode, setGpsMode] = useState<'campus' | 'device' | 'breach_test'>('campus');
  const [deviceLocation, setDeviceLocation] = useState<{ latitude: number; longitude: number; accuracy?: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState<string>('Campus coordinates loaded');

  useEffect(() => {
    if (isOpen) {
      setScanResult(null);
      fetchLiveSessionToken();
      fetchGeofenceConfig();
      requestDeviceGps();
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const fetchGeofenceConfig = async () => {
    try {
      const cfg = await api.getGeofenceConfig();
      if (cfg) setGeofenceConfig(cfg);
    } catch {
      // Keep defaults
    }
  };

  const requestDeviceGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setDeviceLocation({
            latitude: Number(pos.coords.latitude.toFixed(6)),
            longitude: Number(pos.coords.longitude.toFixed(6)),
            accuracy: Math.round(pos.coords.accuracy),
          });
          setLocationStatus(`Live device GPS acquired (±${Math.round(pos.coords.accuracy)}m)`);
        },
        () => {
          setLocationStatus('Using calibrated campus perimeter coordinates');
        },
        { enableHighAccuracy: true, timeout: 6000 }
      );
    }
  };

  const fetchLiveSessionToken = async () => {
    try {
      const records = await api.getRecords();
      if (records && records.length > 0) {
        // Look up latest session
        const latestSessionId = records[0].session_id;
        if (latestSessionId) {
          const sessDetails = await api.getSessionDetails(latestSessionId);
          if (sessDetails?.session?.qr_token) {
            setRecentToken(sessDetails.session.qr_token);
          }
        }
      }
    } catch {
      //
    }
  };

  const startCamera = async () => {
    try {
      setIsScanning(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.play();
        setHasCameraPermission(true);
        requestAnimRef.current = requestAnimationFrame(scanFrame);
      }
    } catch (err) {
      setHasCameraPermission(false);
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    if (requestAnimRef.current) {
      cancelAnimationFrame(requestAnimRef.current);
      requestAnimRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const scanFrame = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current || document.createElement('canvas');
      canvasRef.current = canvas;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (ctx) {
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handleDetectedCode(code.data);
          return;
        }
      }
    }
    requestAnimRef.current = requestAnimationFrame(scanFrame);
  };

  const handleDetectedCode = async (rawCode: string) => {
    stopCamera();
    try {
      let token = rawCode.trim();
      let sessionId: string | undefined;

      if (rawCode.startsWith('{') && rawCode.endsWith('}')) {
        try {
          const parsed = JSON.parse(rawCode);
          if (parsed.token) token = parsed.token;
          if (parsed.sessionId) sessionId = parsed.sessionId;
        } catch {}
      }

      await submitAttendance(token, sessionId);
    } catch (e: any) {
      setScanResult({
        success: false,
        message: e.message || 'Invalid QR Code scanned',
      });
    }
  };

  const getResolvedLocation = () => {
    if (gpsMode === 'breach_test') {
      // 5.2 km off-campus location in Greater Noida suburbs
      return { latitude: 28.5100, longitude: 77.5400, accuracy: 15 };
    }
    if (gpsMode === 'device' && deviceLocation) {
      return deviceLocation;
    }
    // Default campus coordinates (inside perimeter)
    return {
      latitude: geofenceConfig.latitude || 28.4632,
      longitude: geofenceConfig.longitude || 77.4939,
      accuracy: 5,
    };
  };

  const submitAttendance = async (qrToken?: string, sessionId?: string) => {
    setIsSubmitting(true);
    setScanResult(null);

    const locationToSend = getResolvedLocation();

    try {
      const res = await api.markAttendance({
        qrToken,
        sessionId,
        method: 'qr',
        status: 'present',
        location: locationToSend,
      });

      const successMsg = res.message || 'Attendance verified within campus geofence!';
      setScanResult({
        success: true,
        message: successMsg,
        time: res.record?.time,
      });

      showToast({
        type: 'success',
        title: 'Attendance Confirmed',
        message: successMsg,
      });

      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      const errMsg = err.message || 'Failed to validate QR attendance';
      const isGeofence = err.geofenceBreach || errMsg.toLowerCase().includes('geofence') || errMsg.toLowerCase().includes('gps');
      const isDuplicate = err.duplicate || errMsg.toLowerCase().includes('duplicate') || errMsg.toLowerCase().includes('already');

      setScanResult({
        success: false,
        message: errMsg,
        isGeofenceBreach: isGeofence,
        isDuplicate: isDuplicate,
        distance: err.distance,
      });

      showToast({
        type: 'error',
        title: isDuplicate ? 'Duplicate Check-in Blocked' : isGeofence ? 'Geofence Breach' : 'Verification Failed',
        message: errMsg,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualToken.trim()) return;
    submitAttendance(manualToken.trim());
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, img.width, img.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            handleDetectedCode(code.data);
          } else {
            setScanResult({
              success: false,
              message: 'No recognizable QR code detected in the uploaded image.',
            });
          }
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-sky-700 dark:text-sky-400" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">Scan Attendance QR Code</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 rounded-md"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Geofence & GPS Verification Badge */}
          <div className="p-2.5 rounded-lg border border-sky-100 dark:border-sky-900/60 bg-sky-50/50 dark:bg-sky-950/30 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-semibold text-sky-900 dark:text-sky-200">
                <MapPin className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                <span>Campus Geofence Active</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-sky-100 dark:bg-sky-900 text-sky-800 dark:text-sky-300">
                {geofenceConfig.radius_meters}m Perimeter
              </span>
            </div>

            <div className="text-[11px] text-slate-600 dark:text-slate-400">
              Campus: <span className="font-medium text-slate-800 dark:text-slate-200">{geofenceConfig.campus_name}</span>
            </div>

            {/* GPS Mode Selector for Real Device or Verification Test */}
            <div className="pt-1 border-t border-sky-200/60 dark:border-sky-900/40">
              <label className="block text-[10px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                GPS Location Source:
              </label>
              <select
                value={gpsMode}
                onChange={(e) => setGpsMode(e.target.value as any)}
                className="w-full text-[11px] px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium"
              >
                <option value="campus">📍 Campus Classroom LH-302 (Inside 500m perimeter)</option>
                <option value="device">
                  📱 Live Device GPS {deviceLocation ? `(Lat ${deviceLocation.latitude}, Lon ${deviceLocation.longitude})` : '(Detecting...)'}
                </option>
                <option value="breach_test">⚠️ Off-Campus Test: 5.2 km Away (Geofence Breach Test)</option>
              </select>
            </div>
          </div>

          {/* Result Banner if Scanned */}
          {scanResult && (
            <div
              className={`p-4 rounded-lg border text-xs flex items-start gap-3 ${
                scanResult.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  : scanResult.isDuplicate
                  ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                  : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
              }`}
            >
              {scanResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : scanResult.isDuplicate ? (
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <div className="font-semibold">
                  {scanResult.success
                    ? 'Attendance Verified'
                    : scanResult.isDuplicate
                    ? 'Duplicate Attendance Blocked'
                    : scanResult.isGeofenceBreach
                    ? 'Campus Geofence Breach'
                    : 'Check-In Blocked'}
                </div>
                <div className="mt-0.5 leading-relaxed">{scanResult.message}</div>
                {scanResult.time && (
                  <div className="mt-1 font-mono text-[11px] text-emerald-700 dark:text-emerald-400">
                    Timestamp: {scanResult.time}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Camera Viewport or Fallback */}
          <div className="relative aspect-square max-h-56 mx-auto w-full bg-slate-950 rounded-lg overflow-hidden flex items-center justify-center border border-slate-800">
            {hasCameraPermission === false ? (
              <div className="p-6 text-center text-slate-400 text-xs space-y-2">
                <Camera className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="font-medium text-slate-300">Camera preview unavailable in sandbox</p>
                <p className="text-[11px] text-slate-500">
                  Please use manual token validation, image upload, or one-click verification below.
                </p>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                <div className="absolute inset-6 border-2 border-sky-400/80 rounded-lg pointer-events-none flex flex-col justify-between p-2">
                  <div className="flex justify-between">
                    <span className="w-4 h-4 border-t-2 border-l-2 border-sky-400" />
                    <span className="w-4 h-4 border-t-2 border-r-2 border-sky-400" />
                  </div>
                  <div className="text-center text-[10px] text-sky-200 bg-slate-900/60 py-0.5 px-2 rounded-xs self-center">
                    Align QR inside boundary
                  </div>
                  <div className="flex justify-between">
                    <span className="w-4 h-4 border-b-2 border-l-2 border-sky-400" />
                    <span className="w-4 h-4 border-b-2 border-r-2 border-sky-400" />
                  </div>
                </div>
              </>
            )}
            <canvas ref={canvasRef} className="hidden" />
          </div>

          {/* One-click quick test if a live session exists */}
          {recentToken && (
            <button
              type="button"
              onClick={() => {
                setManualToken(recentToken);
                submitAttendance(recentToken);
              }}
              className="w-full py-2 px-3 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/40 dark:hover:bg-sky-900/50 border border-sky-200 dark:border-sky-800 rounded-md text-xs font-semibold text-sky-800 dark:text-sky-300 flex items-center justify-center gap-1.5 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              <span>One-Click Verify Active Session</span>
            </button>
          )}

          {/* Alternative: QR Image Upload & Manual Token Input */}
          <div className="space-y-3 pt-1 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>Alternative Check-in Methods</span>
              <label className="cursor-pointer text-sky-700 dark:text-sky-400 hover:text-sky-800 font-medium flex items-center gap-1">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload QR Image</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <div className="relative flex-1">
                <KeyRound className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Enter QR Session Token..."
                  value={manualToken}
                  onChange={(e) => setManualToken(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
                />
              </div>
              <button
                type="submit"
                disabled={isSubmitting || !manualToken.trim()}
                className="px-3 py-1.5 bg-slate-900 dark:bg-sky-700 text-white text-xs font-medium rounded-md hover:bg-slate-800 dark:hover:bg-sky-800 disabled:opacity-50 transition-colors whitespace-nowrap"
              >
                {isSubmitting ? 'Verifying...' : 'Validate'}
              </button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>Automatic Session Validation</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
