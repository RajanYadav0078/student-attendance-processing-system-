import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.ts';
import { Subject, AttendanceRecord } from '../../types/index.ts';
import {
  X,
  AlertCircle,
  CheckCircle2,
  Calendar,
  BookOpen,
  FileText,
  Clock,
  Sparkles,
  Send,
  HelpCircle,
} from 'lucide-react';

interface AttendanceDisputeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  initialSubjectId?: string;
  initialDate?: string;
  initialSessionId?: string;
  recentAbsentRecords?: AttendanceRecord[];
}

export const AttendanceDisputeModal: React.FC<AttendanceDisputeModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialSubjectId = '',
  initialDate = '',
  initialSessionId = '',
  recentAbsentRecords = [],
}) => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(initialSubjectId);
  const [sessionId, setSessionId] = useState<string>(initialSessionId);
  const [date, setDate] = useState<string>(initialDate || new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<
    'technical_glitch' | 'marked_absent_by_mistake' | 'medical_leave' | 'college_duty' | 'other'
  >('technical_glitch');
  const [reason, setReason] = useState<string>('');
  const [proofNote, setProofNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadSubjects();
      setErrorMessage(null);
      setSuccessMessage(null);
      if (initialSubjectId) setSelectedSubjectId(initialSubjectId);
      if (initialDate) setDate(initialDate);
      if (initialSessionId) setSessionId(initialSessionId);
    }
  }, [isOpen, initialSubjectId, initialDate, initialSessionId]);

  const loadSubjects = async () => {
    try {
      const data = await api.getSubjects();
      setSubjects(data);
      if (!selectedSubjectId && data.length > 0) {
        setSelectedSubjectId(data[0].id);
      }
    } catch (e) {
      console.error('Failed to load subjects', e);
    }
  };

  const handleSelectRecentAbsent = (rec: AttendanceRecord) => {
    setSelectedSubjectId(rec.subject_id);
    setDate(rec.date);
    setSessionId(rec.session_id);
    setCategory('marked_absent_by_mistake');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubjectId) {
      setErrorMessage('Please select an enrolled subject.');
      return;
    }
    if (!date) {
      setErrorMessage('Please specify the date of the missed lecture.');
      return;
    }
    if (!reason || reason.trim().length < 8) {
      setErrorMessage('Please provide a descriptive reason explaining why your attendance should be corrected.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await api.createAttendanceRequest({
        subject_id: selectedSubjectId,
        session_id: sessionId || undefined,
        date,
        category,
        reason: reason.trim(),
        proof_note: proofNote.trim() || undefined,
      });

      setSuccessMessage(res.message || 'Your attendance request was submitted to faculty.');
      setTimeout(() => {
        if (onSuccess) onSuccess();
        onClose();
      }, 1500);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to submit attendance request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const selectedSubject = subjects.find((s) => s.id === selectedSubjectId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-100 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 flex items-center justify-center border border-sky-200 dark:border-sky-800">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Request Attendance Correction
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Submit an attendance issue or dispute directly to your course faculty
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Quick Select From Recent Absent Record */}
          {recentAbsentRecords && recentAbsentRecords.length > 0 && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg">
              <div className="text-[11px] font-semibold text-amber-900 dark:text-amber-200 mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>Quick-Select an Absent Lecture from Your Records:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentAbsentRecords.slice(0, 3).map((rec) => (
                  <button
                    key={rec.id}
                    type="button"
                    onClick={() => handleSelectRecentAbsent(rec)}
                    className="px-2.5 py-1 text-[11px] bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded text-slate-800 dark:text-slate-200 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-colors flex items-center gap-1"
                  >
                    <span className="font-mono font-semibold">{rec.subject_code}</span>
                    <span className="text-slate-400">·</span>
                    <span>{rec.date}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Subject Selection */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Course / Subject <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <select
                value={selectedSubjectId}
                onChange={(e) => setSelectedSubjectId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                required
              >
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.subject_code} — {sub.subject_name} ({sub.faculty_name || 'Faculty'})
                  </option>
                ))}
              </select>
            </div>
            {selectedSubject && (
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Faculty Instructor: <strong className="text-slate-700 dark:text-slate-300">{selectedSubject.faculty_name || 'ARMIND'}</strong>
              </p>
            )}
          </div>

          {/* Date & Session */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Lecture Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Issue Category <span className="text-rose-500">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
              >
                <option value="technical_glitch">⚡ Technical Glitch (QR/RFID)</option>
                <option value="marked_absent_by_mistake">🙋 Marked Absent by Mistake</option>
                <option value="medical_leave">🏥 Medical Leave / Illness</option>
                <option value="college_duty">🏆 College Duty / On-Duty / Event</option>
                <option value="other">📝 Other Extenuating Reason</option>
              </select>
            </div>
          </div>

          {/* Explanation Textarea */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Detailed Explanation for Faculty <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. My QR scanner gave an expiration timeout while standing in line in room 304, but I was present for the entire lecture on Cache Memory..."
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors font-sans"
              required
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1">
              <span>Be clear and specific so your faculty can verify and approve.</span>
              <span>{reason.length} chars</span>
            </div>
          </div>

          {/* Proof / Verification Reference (Optional) */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Proof / Reference Note <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={proofNote}
              onChange={(e) => setProofNote(e.target.value)}
              placeholder="e.g. Doctor prescription ref #MED-884, OD letter signed by HOD, seated next to Kabir Verma"
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
            />
          </div>

          {/* Notice */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-md border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
            Upon submission, this request is routed to your subject instructor. If approved, your attendance registry record will automatically update to <strong>Present</strong> and your overall percentage will recalculate instantly.
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md font-medium transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-sky-700 hover:bg-sky-800 disabled:opacity-50 text-white rounded-md font-semibold transition-colors flex items-center gap-2 shadow-sm"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Request to Faculty</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
