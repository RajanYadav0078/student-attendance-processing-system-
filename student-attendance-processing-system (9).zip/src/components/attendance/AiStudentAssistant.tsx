import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  X,
  MessageSquare,
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  BookOpen,
  ChevronDown,
  Minimize2,
  Maximize2,
} from 'lucide-react';
import { api } from '../../services/api.ts';

interface AiMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AiStudentAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text: "Hello! I am your AI Attendance Assistant. I have secure real-time access to your verified class attendance data and 75% eligibility calculations. How can I help you today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const quickActions = [
    { label: 'Ask about my attendance', prompt: 'What is my current attendance status?' },
    { label: 'How many classes can I miss?', prompt: 'How many classes can I miss safely before hitting 75%?' },
    { label: 'Attendance improvement plan', prompt: 'Give me an attendance improvement plan to reach my goals.' },
    { label: 'Explain my attendance', prompt: 'Explain my attendance across all enrolled subjects and my lowest course.' },
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const query = (customPrompt || inputQuery).trim();
    if (!query || isLoading) return;

    const userMsg: AiMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const res = await api.askAiAssistant({ prompt: query });
      const aiReply: AiMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: res.reply || 'Attendance analysis complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiReply]);
    } catch (err: any) {
      const errorReply: AiMessage = {
        id: `ai-err-${Date.now()}`,
        sender: 'assistant',
        text: err.message || 'Unable to fetch attendance analysis. Please try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorReply]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 bg-sky-700 hover:bg-sky-800 text-white rounded-full p-3.5 shadow-lg flex items-center gap-2 transition-transform hover:scale-105 border border-sky-500/50"
          aria-label="Open AI Attendance Assistant"
        >
          <Bot className="w-5 h-5" />
          <span className="text-xs font-semibold pr-1 hidden sm:inline">AI Attendance Assistant</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        </button>
      )}

      {/* Floating Panel / Drawer */}
      {isOpen && (
        <div className="fixed bottom-6 right-4 sm:right-6 z-50 w-[92vw] sm:w-[420px] h-[560px] max-h-[85vh] bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-sky-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-sky-700 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-xs font-bold leading-tight">AI Attendance Assistant</h3>
                <span className="text-[10px] text-sky-300 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  Grounded on Your Student Data
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-md transition-colors"
              title="Close panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Action Prompt Chips */}
          <div className="p-2.5 bg-sky-50/70 dark:bg-slate-950/50 border-b border-slate-200 dark:border-slate-800 flex flex-wrap gap-1.5">
            {quickActions.map((qa, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(qa.prompt)}
                disabled={isLoading}
                className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 hover:bg-sky-100 dark:hover:bg-slate-700 text-sky-900 dark:text-sky-200 border border-sky-200 dark:border-slate-700 transition-colors shadow-2xs disabled:opacity-50"
              >
                {qa.label}
              </button>
            ))}
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3 text-xs bg-slate-50/50 dark:bg-slate-900/40">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`p-3 rounded-lg max-w-[88%] leading-relaxed whitespace-pre-wrap ${
                    m.sender === 'user'
                      ? 'bg-sky-700 text-white rounded-br-none'
                      : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 shadow-2xs rounded-bl-none'
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 px-1 font-mono">{m.timestamp}</span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-400 p-2 bg-sky-50 dark:bg-slate-800/60 rounded-md border border-sky-100 dark:border-slate-700">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                <span>Calculating verified attendance metrics...</span>
              </div>
            )}
          </div>

          {/* Query Input Footer */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask attendance question (e.g. Can I miss 2 classes?)..."
              disabled={isLoading}
              className="flex-1 px-3 py-2 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-600 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="px-3 py-2 bg-sky-700 hover:bg-sky-800 disabled:opacity-40 text-white text-xs font-semibold rounded-md transition-colors flex items-center justify-center shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
