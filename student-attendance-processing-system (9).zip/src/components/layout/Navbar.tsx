import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotification } from '../../context/NotificationContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { Bell, LogOut, Cpu, Menu, X, Sun, Moon } from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onToggleSidebar }) => {
  const { user, student, faculty, role, isAuthenticated, logout } = useAuth();
  const { systemNotifications, markAsRead } = useNotification();
  const { isDark, toggleTheme } = useTheme();
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadCount = systemNotifications.filter((n) => !n.is_read).length;

  const handleLogout = async () => {
    await logout();
    onNavigate('login');
  };

  const getDashboardView = () => {
    if (role === 'student') return 'student-dashboard';
    if (role === 'faculty') return 'faculty-dashboard';
    if (role === 'admin') return 'admin-dashboard';
    return 'login';
  };

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-3">
          {isAuthenticated && (
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={() => onNavigate(isAuthenticated ? getDashboardView() : 'landing')}
            className="text-left group flex items-center gap-2.5"
          >
            <div className="w-8 h-8 rounded-lg bg-sky-700 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white group-hover:text-sky-600 transition-colors">
                Student Attendance Processing System
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => onNavigate(isAuthenticated ? getDashboardView() : 'landing')}
            className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
              currentView.includes('dashboard') || currentView === 'landing'
                ? 'text-sky-700 dark:text-sky-400 font-semibold'
                : ''
            }`}
          >
            {isAuthenticated ? 'Dashboard' : 'Home'}
          </button>

          {isAuthenticated && role === 'student' && (
            <>
              <button
                onClick={() => onNavigate('student-attendance')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'student-attendance' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                My Attendance
              </button>
              <button
                onClick={() => onNavigate('student-history')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'student-history' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                History
              </button>
              <button
                onClick={() => onNavigate('student-reports')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'student-reports' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Reports
              </button>
            </>
          )}

          {isAuthenticated && role === 'faculty' && (
            <>
              <button
                onClick={() => onNavigate('faculty-create-session')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'faculty-create-session' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Start QR Session
              </button>
              <button
                onClick={() => onNavigate('faculty-mark')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'faculty-mark' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Mark Attendance
              </button>
              <button
                onClick={() => onNavigate('faculty-reports')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'faculty-reports' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Reports
              </button>
            </>
          )}

          {isAuthenticated && role === 'admin' && (
            <>
              <button
                onClick={() => onNavigate('admin-students')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'admin-students' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Students
              </button>
              <button
                onClick={() => onNavigate('admin-defaulters')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'admin-defaulters' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Defaulters
              </button>
              <button
                onClick={() => onNavigate('admin-records')}
                className={`transition-colors hover:text-slate-900 dark:hover:text-white ${
                  currentView === 'admin-records' ? 'text-sky-700 dark:text-sky-400 font-semibold' : ''
                }`}
              >
                Records
              </button>
            </>
          )}
        </nav>

        {/* Zone 3: Actions + Dark Mode Toggle */}
        <div className="flex items-center gap-2.5">
          {/* Dark Mode Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle color mode"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              {/* Notification Bell */}
              <div className="relative">
                <button
                  onClick={() => setShowNotifMenu(!showNotifMenu)}
                  className="p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg relative transition-colors"
                  aria-label="View notifications"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-sky-600 rounded-full" />
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifMenu && (
                  <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded-lg shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                        System Notifications
                      </span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">{unreadCount} unread</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700">
                      {systemNotifications.length === 0 ? (
                        <div className="p-4 text-center text-xs text-slate-400">No notifications</div>
                      ) : (
                        systemNotifications.map((n) => (
                          <div
                            key={n.id}
                            className={`p-3 text-xs hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors cursor-pointer ${
                              !n.is_read ? 'bg-sky-50/50 dark:bg-sky-950/30' : ''
                            }`}
                            onClick={() => markAsRead(n.id)}
                          >
                            <div className="font-medium text-slate-800 dark:text-slate-200 mb-1 flex items-center justify-between">
                              <span>{n.title}</span>
                              {!n.is_read && (
                                <span className="w-1.5 h-1.5 bg-sky-600 rounded-full shrink-0" />
                              )}
                            </div>
                            <div className="text-slate-600 dark:text-slate-400 leading-normal mb-1">{n.message}</div>
                            <div className="text-[10px] text-slate-400">
                              {new Date(n.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* User Identity / Role Indicator */}
              <div className="hidden sm:flex flex-col text-right">
                <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate max-w-[140px]">
                  {student?.name || faculty?.name || user?.name}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 capitalize">
                  {role} {student ? `· Sec ${student.section}` : faculty ? `· ${faculty.department.split(' ')[0]}` : ''}
                </span>
              </div>

              {/* Logout Button */}
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg border border-slate-200 dark:border-slate-700 transition-colors"
                title="Log out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('login')}
                className="px-4 py-2 text-xs font-medium text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shadow-sm"
              >
                Portal Sign In
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
