import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  LayoutDashboard,
  CalendarCheck,
  History,
  QrCode,
  FileText,
  UserCheck,
  PlusCircle,
  BarChart3,
  Users,
  GraduationCap,
  BookOpen,
  AlertOctagon,
  Settings,
  Radio,
  Cpu,
  X,
  ShieldCheck,
  HelpCircle,
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, isOpen, onClose }) => {
  const { role, user, student, faculty } = useAuth();

  const handleNav = (view: string) => {
    onNavigate(view);
    onClose();
  };

  const studentNavItems = [
    { id: 'student-dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'student-attendance', label: 'My Attendance', icon: CalendarCheck },
    { id: 'student-history', label: 'Attendance History', icon: History },
    { id: 'student-requests', label: 'Attendance Requests', icon: HelpCircle },
    { id: 'student-scanner', label: 'Scan QR Attendance', icon: QrCode },
    { id: 'student-reports', label: 'Download Reports', icon: FileText },
    { id: 'student-profile', label: 'Student Profile', icon: UserCheck },
  ];

  const facultyNavItems = [
    { id: 'faculty-dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'faculty-create-session', label: 'Start QR Session', icon: PlusCircle },
    { id: 'faculty-mark', label: 'Mark Attendance', icon: CalendarCheck },
    { id: 'faculty-requests', label: 'Student Requests', icon: HelpCircle },
    { id: 'faculty-history', label: 'Session History', icon: History },
    { id: 'faculty-analytics', label: 'Subject Analytics', icon: BarChart3 },
    { id: 'faculty-reports', label: 'Faculty Reports', icon: FileText },
    { id: 'rfid-simulator', label: 'RFID Card Simulation', icon: Radio },
  ];

  const adminNavItems = [
    { id: 'admin-dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'admin-students', label: 'Manage Students', icon: GraduationCap },
    { id: 'admin-faculty', label: 'Manage Faculty', icon: Users },
    { id: 'admin-subjects', label: 'Manage Subjects', icon: BookOpen },
    { id: 'admin-records', label: 'Attendance Records', icon: History },
    { id: 'admin-defaulters', label: 'Defaulter List', icon: AlertOctagon },
    { id: 'admin-reports', label: 'Institute Reports', icon: FileText },
    { id: 'admin-management', label: 'Admin Management', icon: ShieldCheck },
    { id: 'admin-settings', label: 'System Settings', icon: Settings },
    { id: 'rfid-simulator', label: 'RFID Card Simulation', icon: Radio },
  ];

  const navItems =
    role === 'student'
      ? studentNavItems
      : role === 'faculty'
      ? facultyNavItems
      : role === 'admin'
      ? adminNavItems
      : [];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* User Card */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sky-400 text-sm">
              {student ? 'ST' : faculty ? 'FC' : 'AD'}
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-semibold text-white truncate">
                {student?.name || faculty?.name || user?.name || 'Authorized User'}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                {student ? `Roll: ${student.roll_number}` : faculty ? faculty.employee_id : 'Administrator'}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden text-slate-400 hover:text-white p-1 rounded-md"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Section */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            {role} Portal
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-sky-700 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>
      </aside>
    </>
  );
};
