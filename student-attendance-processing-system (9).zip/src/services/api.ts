import {
  User,
  Student,
  Faculty,
  Subject,
  ClassSection,
  AttendanceSession,
  AttendanceRecord,
  StudentAttendanceProfile,
  SystemSettings,
  SystemNotification,
  Institution,
  AttendanceCorrectionRequest,
  GeofenceConfig,
} from '../types/index.ts';

const TOKEN_KEY = 'attendance_app_token';
const USER_KEY = 'attendance_app_user';

export const authStorage = {
  getToken: (): string | null => localStorage.getItem(TOKEN_KEY),
  setToken: (token: string) => localStorage.setItem(TOKEN_KEY, token),
  removeToken: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
  getCachedUser: (): User | null => {
    try {
      const u = localStorage.getItem(USER_KEY);
      return u ? JSON.parse(u) : null;
    } catch {
      return null;
    }
  },
  setCachedUser: (user: User) => localStorage.setItem(USER_KEY, JSON.stringify(user)),
};

async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = authStorage.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data?.error || response.statusText || 'Request failed';
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  login: async (credentials: { email: string; password: string }) => {
    const res = await apiFetch<{
      token: string;
      user: User;
      student: Student | null;
      faculty: Faculty | null;
      redirectPath: string;
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    authStorage.setToken(res.token);
    authStorage.setCachedUser(res.user);
    return res;
  },

  logout: async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } finally {
      authStorage.removeToken();
    }
  },

  getCurrentUser: async () => {
    return apiFetch<{
      user: User;
      student: Student | null;
      faculty: Faculty | null;
    }>('/api/auth/me');
  },

  getAdminStatus: async () => {
    return apiFetch<{ hasAdmin: boolean; count: number }>('/api/auth/admin-status');
  },

  getDemoCredentials: async () => {
    return apiFetch<{
      defaultPassword: string;
      supportedDefaultPasswords: string[];
      accounts: {
        role: 'student' | 'faculty' | 'admin';
        label: string;
        name: string;
        email: string;
        identifier: string;
        rollNumber?: string;
        employeeId?: string;
        password: string;
        institution: string;
      }[];
    }>('/api/auth/demo-credentials');
  },

  setupAdmin: async (data: { name: string; email: string; password: string }) => {
    const res = await apiFetch<{
      success: boolean;
      message: string;
      token: string;
      user: User;
      redirectPath: string;
    }>('/api/auth/setup-admin', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    authStorage.setToken(res.token);
    authStorage.setCachedUser(res.user);
    return res;
  },

  getAdmins: async () => {
    return apiFetch<User[]>('/api/auth/admins');
  },

  createAdmin: async (data: { name: string; email: string; password: string }) => {
    return apiFetch<{ success: boolean; message: string; user: User }>('/api/auth/create-admin', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  deleteAdmin: async (id: string) => {
    return apiFetch<{ success: boolean; message: string }>(`/api/auth/admins/${id}`, {
      method: 'DELETE',
    });
  },

  // Students
  getStudents: (params?: { branch?: string; semester?: number; section?: string; search?: string }) => {
    const q = new URLSearchParams();
    if (params?.branch) q.append('branch', params.branch);
    if (params?.semester) q.append('semester', String(params.semester));
    if (params?.section) q.append('section', params.section);
    if (params?.search) q.append('search', params.search);
    return apiFetch<Student[]>(`/api/students?${q.toString()}`);
  },

  getStudentById: (id: string) => {
    return apiFetch<StudentAttendanceProfile & { recent_records: AttendanceRecord[] }>(`/api/students/${id}`);
  },

  addStudent: (data: Partial<Student> & { password?: string }) => {
    return apiFetch<Student>('/api/students', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateStudent: (id: string, data: Partial<Student>) => {
    return apiFetch<Student>(`/api/students/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteStudent: (id: string) => {
    return apiFetch<{ success: boolean }>(`/api/students/${id}`, {
      method: 'DELETE',
    });
  },

  // Faculty
  getFacultyList: () => {
    return apiFetch<Faculty[]>('/api/faculty');
  },

  getFacultyById: (id: string) => {
    return apiFetch<Faculty & { assigned_subjects: Subject[]; today_sessions: AttendanceSession[]; total_sessions_count: number }>(`/api/faculty/${id}`);
  },

  addFaculty: (data: Partial<Faculty> & { password?: string }) => {
    return apiFetch<Faculty>('/api/faculty', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateFaculty: (id: string, data: Partial<Faculty>) => {
    return apiFetch<Faculty>(`/api/faculty/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteFaculty: (id: string) => {
    return apiFetch<{ success: boolean }>(`/api/faculty/${id}`, {
      method: 'DELETE',
    });
  },

  // Subjects & Classes
  getSubjects: () => {
    return apiFetch<Subject[]>('/api/subjects');
  },

  addSubject: (data: Partial<Subject>) => {
    return apiFetch<Subject>('/api/subjects', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateSubject: (id: string, data: Partial<Subject>) => {
    return apiFetch<Subject>(`/api/subjects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteSubject: (id: string) => {
    return apiFetch<{ success: boolean }>(`/api/subjects/${id}`, {
      method: 'DELETE',
    });
  },

  getClasses: () => {
    return apiFetch<ClassSection[]>('/api/subjects/classes/list');
  },

  addClass: (data: Partial<ClassSection>) => {
    return apiFetch<ClassSection>('/api/subjects/classes/list', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Attendance Sessions & Marking
  createSession: (data: {
    subjectId: string;
    facultyId?: string;
    section: string;
    lectureTopic: string;
    durationMinutes?: number;
  }) => {
    return apiFetch<AttendanceSession>('/api/attendance/session', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getSessionDetails: (sessionId: string) => {
    return apiFetch<{
      session: AttendanceSession;
      students: Array<{
        student_id: string;
        roll_number: string;
        name: string;
        email: string;
        rfid_id: string;
        status: 'present' | 'absent';
        time?: string;
        method?: string;
        record_id?: string;
      }>;
      total_students: number;
      present_count: number;
      absent_count: number;
    }>(`/api/attendance/session/${sessionId}`);
  },

  closeSession: (sessionId: string) => {
    return apiFetch<{ success: boolean; session: AttendanceSession }>(`/api/attendance/session/${sessionId}/close`, {
      method: 'POST',
    });
  },

  markAttendance: (data: {
    sessionId?: string;
    qrToken?: string;
    studentId?: string;
    status?: 'present' | 'absent';
    method?: 'qr' | 'manual' | 'rfid';
    remarks?: string;
    location?: {
      latitude: number;
      longitude: number;
      accuracy?: number;
    };
  }) => {
    return apiFetch<{
      success: boolean;
      record?: AttendanceRecord;
      message: string;
      duplicate?: boolean;
      geofenceBreach?: boolean;
      distance?: number;
    }>('/api/attendance/mark', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  saveBulkAttendance: (sessionId: string, records: Array<{ studentId: string; status: 'present' | 'absent'; remarks?: string }>) => {
    return apiFetch<{ success: boolean; message: string; undoStackId: string }>('/api/attendance/bulk', {
      method: 'POST',
      body: JSON.stringify({ sessionId, records }),
    });
  },

  undoLatestAttendance: (sessionId?: string) => {
    return apiFetch<{ success: boolean; message: string }>('/api/attendance/undo', {
      method: 'POST',
      body: JSON.stringify({ sessionId }),
    });
  },

  tapRfid: (rfidId: string, sessionId: string) => {
    return apiFetch<{
      success: boolean;
      message: string;
      student: Student;
      record: AttendanceRecord;
    }>('/api/attendance/rfid-tap', {
      method: 'POST',
      body: JSON.stringify({ rfidId, sessionId }),
    });
  },

  getRecords: (params?: {
    subjectId?: string;
    section?: string;
    studentId?: string;
    date?: string;
    status?: string;
    method?: string;
    search?: string;
  }) => {
    const q = new URLSearchParams();
    if (params?.subjectId) q.append('subjectId', params.subjectId);
    if (params?.section) q.append('section', params.section);
    if (params?.studentId) q.append('studentId', params.studentId);
    if (params?.date) q.append('date', params.date);
    if (params?.status) q.append('status', params.status);
    if (params?.method) q.append('method', params.method);
    if (params?.search) q.append('search', params.search);
    return apiFetch<AttendanceRecord[]>(`/api/attendance/records?${q.toString()}`);
  },

  // Analytics & Dashboards
  getDashboardData: () => {
    return apiFetch<any>('/api/analytics/dashboard');
  },

  getDefaultersReport: (threshold?: number) => {
    const q = threshold ? `?threshold=${threshold}` : '';
    return apiFetch<any[]>(`/api/reports/defaulters${q}`);
  },

  getClassAnalytics: () => {
    return apiFetch<any[]>('/api/reports/classes');
  },

  getSettings: () => {
    return apiFetch<SystemSettings>('/api/settings');
  },

  updateSettings: (settings: Partial<SystemSettings>) => {
    return apiFetch<SystemSettings>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  },

  getNotifications: () => {
    return apiFetch<SystemNotification[]>('/api/notifications');
  },

  markNotificationRead: (id: string) => {
    return apiFetch<{ success: boolean }>(`/api/notifications/${id}/read`, {
      method: 'POST',
    });
  },

  resetDemoData: () => {
    return apiFetch<{ success: boolean; message: string }>('/api/demo/reset', {
      method: 'POST',
    });
  },

  // Institution Multi-Tenancy & Governance
  registerInstitution: async (data: {
    name: string;
    type: 'college' | 'university' | 'institute' | 'school';
    affiliation?: string;
    aishe_code?: string;
    website?: string;
    address: string;
    city: string;
    state: string;
    country: string;
    domain: string;
    admin_name: string;
    admin_designation?: string;
    official_contact?: string;
    official_email: string;
    desired_username?: string;
    password: string;
  }) => {
    const res = await apiFetch<{
      success: boolean;
      message: string;
      institution: Institution;
      adminUser: User;
      token: string;
    }>('/api/institutions/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    if (res.token && res.adminUser) {
      authStorage.setToken(res.token);
      authStorage.setCachedUser(res.adminUser);
    }
    return res;
  },

  getInstitutionsList: () => {
    return apiFetch<Array<{
      id: string;
      name: string;
      type: string;
      domain: string;
      city: string;
      state: string;
      country: string;
      verification_status: string;
    }>>('/api/institutions/list');
  },

  getCurrentInstitution: () => {
    return apiFetch<Institution>('/api/institutions/current');
  },

  verifyDomain: (token: string) => {
    return apiFetch<{ success: boolean; message: string; institution: Institution }>('/api/institutions/verify-domain', {
      method: 'POST',
      body: JSON.stringify({ token }),
    });
  },

  configureEmailProvider: (data: { provider: string; mailboxStatus?: string }) => {
    return apiFetch<{ success: boolean; message: string; institution: Institution }>('/api/institutions/email-config', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateInstitutionProfile: (data: Partial<Institution>) => {
    return apiFetch<{ success: boolean; message: string; institution: Institution }>('/api/institutions/profile', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  getAuditLogs: () => {
    return apiFetch<any[]>('/api/institutions/audit-logs');
  },

  // AI Attendance & Analytics Assistant
  askAiAssistant: (data: { prompt?: string; action?: string }) => {
    return apiFetch<{ reply: string; analyticalData: any }>('/api/ai/chat', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Attendance Disputes & Correction Requests
  getStudentAttendanceRequests: () => {
    return apiFetch<AttendanceCorrectionRequest[]>('/api/attendance/requests/my');
  },

  getFacultyAttendanceRequests: () => {
    return apiFetch<AttendanceCorrectionRequest[]>('/api/attendance/requests/faculty');
  },

  getAllAttendanceRequests: () => {
    return apiFetch<AttendanceCorrectionRequest[]>('/api/attendance/requests');
  },

  createAttendanceRequest: (data: {
    subject_id: string;
    session_id?: string;
    date: string;
    category: string;
    reason: string;
    proof_note?: string;
  }) => {
    return apiFetch<{ success: boolean; message: string; request: AttendanceCorrectionRequest }>(
      '/api/attendance/requests',
      {
        method: 'POST',
        body: JSON.stringify(data),
      }
    );
  },

  actionAttendanceRequest: (id: string, action: 'approve' | 'reject' | 'faculty_verify', remarks?: string) => {
    return apiFetch<{ success: boolean; message: string; request: AttendanceCorrectionRequest }>(
      `/api/attendance/requests/${id}/action`,
      {
        method: 'POST',
        body: JSON.stringify({ action, remarks }),
      }
    );
  },

  facultyVerifyRequest: (id: string, remarks?: string) => {
    return apiFetch<{ success: boolean; message: string; request: AttendanceCorrectionRequest }>(
      `/api/attendance/requests/${id}/faculty-verify`,
      {
        method: 'POST',
        body: JSON.stringify({ remarks }),
      }
    );
  },

  adminApproveRequest: (id: string, remarks?: string) => {
    return apiFetch<{ success: boolean; message: string; request: AttendanceCorrectionRequest }>(
      `/api/attendance/requests/${id}/admin-approve`,
      {
        method: 'POST',
        body: JSON.stringify({ remarks }),
      }
    );
  },

  rejectDisputeRequest: (id: string, remarks?: string) => {
    return apiFetch<{ success: boolean; message: string; request: AttendanceCorrectionRequest }>(
      `/api/attendance/requests/${id}/reject`,
      {
        method: 'POST',
        body: JSON.stringify({ remarks }),
      }
    );
  },

  getGeofenceConfig: () => {
    return apiFetch<GeofenceConfig>('/api/attendance/geofence');
  },

  updateGeofenceConfig: (config: Partial<GeofenceConfig>) => {
    return apiFetch<{ success: boolean; message: string; geofence: GeofenceConfig }>('/api/attendance/geofence', {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  },
};
