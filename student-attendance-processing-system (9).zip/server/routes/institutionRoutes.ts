import { Router, type Request, type Response } from 'express';
import { db } from '../db.ts';
import { authMiddleware, roleMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// Public: Register a new institution
router.post('/register', (req: Request, res: Response) => {
  try {
    const {
      name,
      type,
      affiliation,
      aishe_code,
      website,
      address,
      city,
      state,
      country,
      domain,
      admin_name,
      admin_designation,
      official_contact,
      official_email,
      desired_username,
      password,
    } = req.body;

    if (!name || !address || !city || !state || !country || !domain || !admin_name || !official_email || !password) {
      return res.status(400).json({ error: 'All required institution and administrator fields must be provided.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Administrator password must be at least 6 characters.' });
    }

    const result = db.registerInstitution({
      name,
      type: type || 'college',
      affiliation,
      aishe_code,
      website,
      address,
      city,
      state,
      country,
      domain,
      admin_name,
      admin_designation,
      official_contact,
      official_email,
      desired_username,
      password,
    });

    res.status(201).json({
      success: true,
      message: `Institution "${result.institution.name}" registered successfully.`,
      institution: result.institution,
      adminUser: {
        id: result.adminUser.id,
        name: result.adminUser.name,
        email: result.adminUser.email,
        institutional_email: result.adminUser.institutional_email,
        role: result.adminUser.role,
      },
      token: result.token,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to register institution' });
  }
});

// Public: List institutions (for directory / portal login selector)
router.get('/list', (_req: Request, res: Response) => {
  const list = db.getInstitutions().map((i) => ({
    id: i.id,
    name: i.name,
    type: i.type,
    domain: i.domain,
    city: i.city,
    state: i.state,
    country: i.country,
    verification_status: i.verification_status,
  }));
  res.json(list);
});

// Authenticated: Get current user's institution details
router.get('/current', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'No institution association found in token' });
  }

  const inst = db.getInstitutionById(institutionId);
  if (!inst) {
    return res.status(404).json({ error: 'Institution not found' });
  }

  res.json(inst);
});

// Authenticated (Admin): Verify domain ownership via DNS TXT simulation
router.post('/verify-domain', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const { token } = req.body;

  if (!institutionId) {
    return res.status(400).json({ error: 'Invalid institution session' });
  }

  if (!token) {
    return res.status(400).json({ error: 'DNS TXT verification token is required' });
  }

  try {
    const result = db.verifyDomain(institutionId, token);
    res.json({
      success: true,
      message: `Domain ${result.institution.domain} successfully verified. Institutional credentials activated.`,
      institution: result.institution,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Domain verification failed' });
  }
});

// Authenticated (Admin): Configure institutional email provider
router.post('/email-config', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const { provider, mailboxStatus } = req.body;

  if (!institutionId) {
    return res.status(400).json({ error: 'Invalid institution session' });
  }

  const validProviders = ['none', 'google_workspace', 'microsoft_365', 'custom_mail_server', 'smtp'];
  if (!validProviders.includes(provider)) {
    return res.status(400).json({ error: 'Invalid email provider selection' });
  }

  try {
    const updated = db.updateEmailConfig(institutionId, provider, mailboxStatus || 'active');
    res.json({
      success: true,
      message: `Email provider configured as ${provider}. Mailbox status is now ${updated.mailbox_status}.`,
      institution: updated,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to update email configuration' });
  }
});

// Authenticated (Admin): Update institution profile
router.put('/profile', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Invalid institution session' });
  }

  try {
    const updated = db.updateInstitution(institutionId, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Institution not found' });
    }
    res.json({
      success: true,
      message: 'Institution profile updated successfully.',
      institution: updated,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to update institution profile' });
  }
});

// Authenticated (Admin): Get institution audit logs
router.get('/audit-logs', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Invalid institution session' });
  }

  const logs = db.getAuditLogs(institutionId);
  res.json(logs);
});

export default router;
