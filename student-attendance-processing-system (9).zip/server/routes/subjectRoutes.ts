import { Router, type Response } from 'express';
import { db } from '../db.ts';
import { authMiddleware, roleMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// List all subjects for current institution
router.get('/', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const subjects = db.getSubjects(institutionId);
  res.json(subjects);
});

// Add subject
router.post('/', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.body.institution_id || req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution association required' });
  }

  const { subject_code, subject_name, faculty_id, semester, branch, total_credits } = req.body;

  if (!subject_code || !subject_name || !faculty_id) {
    return res.status(400).json({ error: 'Subject code, name, and assigned faculty are required' });
  }

  const newSubject = db.addSubject({
    institution_id: institutionId,
    subject_code,
    subject_name,
    faculty_id,
    semester: Number(semester) || 1,
    branch: branch || 'Computer Science & Engineering',
    total_credits: Number(total_credits) || 3,
  });

  res.status(201).json(newSubject);
});

// Update subject
router.put('/:id', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const updated = db.updateSubject(req.params.id, req.body, institutionId);
  if (!updated) {
    return res.status(404).json({ error: 'Subject not found in this institution' });
  }
  res.json(updated);
});

// Delete subject
router.delete('/:id', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const deleted = db.deleteSubject(req.params.id, institutionId);
  if (!deleted) {
    return res.status(404).json({ error: 'Subject not found in this institution' });
  }
  res.json({ success: true, message: 'Subject deleted successfully' });
});

// Classes/Sections endpoints
router.get('/classes/list', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const classes = db.getClasses(institutionId);
  res.json(classes);
});

router.post('/classes/list', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.body.institution_id || req.user?.institutionId;
  const { name, branch, semester, section } = req.body;
  if (!name || !section) {
    return res.status(400).json({ error: 'Class name and section are required' });
  }

  const newClass = db.addClass({
    institution_id: institutionId || 'inst-default',
    name,
    branch: branch || 'Computer Science & Engineering',
    semester: Number(semester) || 1,
    section: section.toUpperCase(),
  });

  res.status(201).json(newClass);
});

export default router;
