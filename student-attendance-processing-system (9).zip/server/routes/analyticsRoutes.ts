import { Router, type Response } from 'express';
import { db } from '../db.ts';
import { authMiddleware, roleMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// Role-based dashboard analytics endpoint
router.get('/dashboard', authMiddleware, (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const institutionId = req.user?.institutionId || 'inst-niet';

  if (role === 'student') {
    const student = db.getStudentByUserId(req.user?.userId || '');
    if (!student) {
      return res.status(404).json({ error: 'Student profile not linked' });
    }
    const profile = db.calculateStudentAttendance(student.id, institutionId);
    const recentRecords = db
      .getAttendanceRecords(institutionId)
      .filter((a) => a.student_id === student.id)
      .sort((a, b) => new Date(b.date + 'T' + b.time).getTime() - new Date(a.date + 'T' + a.time).getTime())
      .slice(0, 10);

    return res.json({
      role: 'student',
      profile,
      recentRecords,
      settings: db.getSettings(institutionId),
    });
  }

  if (role === 'faculty') {
    const faculty = db.getFacultyByUserId(req.user?.userId || '');
    const subjects = faculty ? db.getSubjects(institutionId).filter((s) => s.faculty_id === faculty.id) : [];
    const facultySubjectIds = subjects.map((s) => s.id);

    const todayStr = new Date().toISOString().split('T')[0];
    const todaySessions = db
      .getSessions(institutionId)
      .filter((s) => s.faculty_id === faculty?.id && s.date === todayStr);

    const allSessions = db
      .getSessions(institutionId)
      .filter((s) => s.faculty_id === faculty?.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    // Defaulters across faculty's subjects
    const allDefaulters = db.getDefaulters(institutionId);
    const relevantDefaulters = allDefaulters.filter((d) =>
      d.defaulterSubjects.some((ds) => facultySubjectIds.includes(ds.subject_id))
    );

    // Subject statistics
    const subjectStats = subjects.map((subj) => {
      const subjSessions = allSessions.filter((s) => s.subject_id === subj.id);
      const subjRecords = db.getAttendanceRecords(institutionId).filter((r) => r.subject_id === subj.id);
      const presentCount = subjRecords.filter((r) => r.status === 'present').length;
      const totalCount = subjRecords.length;
      const avgPercentage = totalCount > 0 ? Number(((presentCount / totalCount) * 100).toFixed(1)) : 0;

      return {
        ...subj,
        total_sessions: subjSessions.length,
        total_logs: totalCount,
        average_attendance: avgPercentage,
      };
    });

    return res.json({
      role: 'faculty',
      faculty,
      assignedSubjects: subjectStats,
      todaySessions,
      recentSessions: allSessions.slice(0, 5),
      defaulterCount: relevantDefaulters.length,
      defaulters: relevantDefaulters.slice(0, 10),
      settings: db.getSettings(institutionId),
    });
  }

  // Admin Dashboard
  const stats = db.getOverallStatistics(institutionId);
  const defaulters = db.getDefaulters(institutionId);
  const subjects = db.getSubjects(institutionId);
  const classes = db.getClasses(institutionId);
  const recentSessions = db
    .getSessions(institutionId)
    .slice(0, 8);

  const subjectStats = subjects.map((subj) => {
    const subjRecords = db.getAttendanceRecords(institutionId).filter((r) => r.subject_id === subj.id);
    const presentCount = subjRecords.filter((r) => r.status === 'present').length;
    const totalCount = subjRecords.length;
    const avgPercentage = totalCount > 0 ? Number(((presentCount / totalCount) * 100).toFixed(1)) : 0;
    return {
      ...subj,
      average_attendance: avgPercentage,
      total_records: totalCount,
    };
  });

  const inst = db.getInstitutionById(institutionId);

  res.json({
    role: 'admin',
    stats,
    institution: inst,
    defaultersCount: defaulters.length,
    defaulters: defaulters.slice(0, 10),
    subjectStats,
    classes,
    recentSessions,
    settings: db.getSettings(institutionId),
  });
});

// Defaulters report
router.get('/reports/defaulters', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId || 'inst-niet';
  const threshold = req.query.threshold ? Number(req.query.threshold) : undefined;
  const defaulters = db.getDefaulters(institutionId, threshold);
  res.json(defaulters);
});

// Class-wise analytics report
router.get('/reports/classes', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId || 'inst-niet';
  const classes = db.getClasses(institutionId);
  const students = db.getStudents(institutionId);
  const threshold = db.getSettings(institutionId).eligibility_threshold;

  const classReport = classes.map((cls) => {
    const classStudents = students.filter((s) => s.section === cls.section);
    let totalClasses = 0;
    let totalAttended = 0;
    let defaulterCount = 0;

    classStudents.forEach((st) => {
      const p = db.calculateStudentAttendance(st.id, institutionId);
      if (p) {
        totalClasses += p.total_classes;
        totalAttended += p.attended_classes;
        if (p.overall_percentage < threshold) defaulterCount++;
      }
    });

    const averageAttendance = totalClasses > 0 ? Number(((totalAttended / totalClasses) * 100).toFixed(1)) : 0;

    return {
      class: cls,
      student_count: classStudents.length,
      average_attendance: averageAttendance,
      defaulter_count: defaulterCount,
    };
  });

  res.json(classReport);
});

// System Settings
router.get('/settings', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId || 'inst-niet';
  res.json(db.getSettings(institutionId));
});

router.put('/settings', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId || 'inst-niet';
  const updated = db.updateSettings(institutionId, req.body);
  res.json(updated);
});

// Notifications
router.get('/notifications', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const notifs = db.getNotifications(institutionId, req.user?.userId, req.user?.role);
  res.json(notifs);
});

router.post('/notifications/:id/read', authMiddleware, (req: AuthRequest, res: Response) => {
  const ok = db.markNotificationRead(req.params.id);
  res.json({ success: ok });
});

// Reseed demo data
router.post('/demo/reset', authMiddleware, roleMiddleware(['admin']), (_req: AuthRequest, res: Response) => {
  db.resetToDefault();
  res.json({ success: true, message: 'Database reset to initial demo state with fresh records.' });
});

export default router;
