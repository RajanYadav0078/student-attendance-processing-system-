import { Router, type Request, type Response } from 'express';
import { db } from '../db.ts';
import { hashPassword, generateToken, authMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// Universal default passwords for hassle-free and accessible sign-in
const DEFAULT_PASSWORDS = [
  'password123',
  'password',
  'admin123',
  'admin',
  'faculty123',
  'faculty',
  'student123',
  'student',
  '123456',
  '1234',
  '12345',
  '12345678',
  'demo123',
  'demo',
  'pass123',
  'test',
  'user',
  'root',
  'niet123',
  'apex123',
];

router.post('/login', (req: Request, res: Response) => {
  const emailInput = req.body.email !== undefined && req.body.email !== null ? String(req.body.email).trim() : '';
  const passwordInput =
    req.body.password !== undefined && req.body.password !== null && String(req.body.password).trim() !== ''
      ? String(req.body.password).trim()
      : 'password123'; // auto-fallback to default password if empty

  if (!emailInput) {
    return res.status(400).json({
      error: 'Please enter your email, roll number, or keywords "student", "faculty", or "admin".',
    });
  }

  // 1. Look up user by flexible identifier
  let user = db.getUserByEmail(emailInput);

  // 2. If not found directly, do a broader fuzzy search over registered users
  if (!user) {
    const allUsers = db.getUsers();
    const qLower = emailInput.toLowerCase();
    user = allUsers.find(
      (u) =>
        u.email.toLowerCase().includes(qLower) ||
        (u.institutional_email && u.institutional_email.toLowerCase().includes(qLower)) ||
        u.name.toLowerCase().includes(qLower)
    );
  }

  // 3. If still not found, check if keyword maps to role
  if (!user) {
    if (emailInput.toLowerCase().includes('student')) {
      user = db.getUsers().find((u) => u.role === 'student');
    } else if (emailInput.toLowerCase().includes('fac') || emailInput.toLowerCase().includes('teach')) {
      user = db.getUsers().find((u) => u.role === 'faculty');
    } else if (emailInput.toLowerCase().includes('adm')) {
      user = db.getUsers().find((u) => u.role === 'admin');
    }
  }

  if (!user) {
    return res.status(401).json({
      error: `No account found for "${emailInput}". Tip: You can sign in using keywords "student", "faculty", or "admin", or click any 1-Click Quick Sign In button.`,
    });
  }

  const trimmedPassword = passwordInput.trim();
  const inputHash = hashPassword(trimmedPassword);

  // Check if provided password is an approved default or matches user account
  const isApprovedDefault =
    !trimmedPassword ||
    DEFAULT_PASSWORDS.some((dp) => dp.toLowerCase() === trimmedPassword.toLowerCase()) ||
    trimmedPassword.toLowerCase() === user.role.toLowerCase() ||
    (user.institutional_email && trimmedPassword.toLowerCase() === (user.institutional_email.split('@')[0] || '').toLowerCase()) ||
    (user.email && trimmedPassword.toLowerCase() === (user.email.split('@')[0] || '').toLowerCase());

  const isMatch =
    user.password_hash === inputHash ||
    isApprovedDefault ||
    user.password_hash === hashPassword('password123');

  if (!isMatch) {
    return res.status(401).json({
      error: 'Invalid password. (Tip: Use default password "password123" for instant access).',
    });
  }

  const token = generateToken(user);

  let studentProfile = null;
  let facultyProfile = null;

  if (user.role === 'student') {
    studentProfile = db.getStudentByUserId(user.id);
  } else if (user.role === 'faculty') {
    facultyProfile = db.getFacultyByUserId(user.id);
  }

  let redirectPath = '/student/dashboard';
  if (user.role === 'faculty') redirectPath = '/faculty/dashboard';
  if (user.role === 'admin') redirectPath = '/admin/dashboard';

  res.json({
    token,
    user: {
      id: user.id,
      institution_id: user.institution_id,
      name: user.name,
      email: user.email,
      institutional_email: user.institutional_email,
      role: user.role,
    },
    student: studentProfile,
    faculty: facultyProfile,
    redirectPath,
  });
});

// Demo Credentials & Default Password Discovery endpoint (Public)
router.get('/demo-credentials', (_req: Request, res: Response) => {
  const institutions = db.getInstitutions();
  const students = db.getStudents();
  const facultyList = db.getFaculty();
  const admins = db.getAdmins();

  const accounts: Array<{
    role: string;
    label: string;
    name: string;
    email: string;
    identifier: string;
    rollNumber?: string;
    employeeId?: string;
    password: string;
    institution: string;
  }> = [];

  // Students
  students.forEach((s) => {
    accounts.push({
      role: 'student',
      label: `Student: ${s.name}`,
      name: s.name,
      email: s.institutional_email || s.email,
      identifier: s.roll_number,
      rollNumber: s.roll_number,
      password: 'password123',
      institution: institutions.find((i) => i.id === s.institution_id)?.name || institutions[0]?.name || 'Noida Institute of Engineering and Technology',
    });
  });

  // Faculty
  facultyList.forEach((f) => {
    accounts.push({
      role: 'faculty',
      label: `Faculty: ${f.name}`,
      name: f.name,
      email: f.institutional_email || f.email,
      identifier: f.employee_id,
      employeeId: f.employee_id,
      password: 'password123',
      institution: institutions.find((i) => i.id === f.institution_id)?.name || institutions[0]?.name || 'Noida Institute of Engineering and Technology',
    });
  });

  // Admins
  admins.forEach((a) => {
    accounts.push({
      role: 'admin',
      label: `Admin: ${a.name}`,
      name: a.name,
      email: a.institutional_email || a.email,
      identifier: 'admin',
      password: 'password123',
      institution: institutions.find((i) => i.id === a.institution_id)?.name || institutions[0]?.name || 'Noida Institute of Engineering and Technology',
    });
  });

  res.json({
    defaultPassword: 'password123',
    supportedDefaultPasswords: DEFAULT_PASSWORDS,
    accounts,
  });
});

router.post('/logout', (_req: Request, res: Response) => {
  res.json({ success: true, message: 'Logged out successfully' });
});

// Check if any administrator exists (Public endpoint for First Administrator setup)
router.get('/admin-status', (_req: Request, res: Response) => {
  const admins = db.getAdmins();
  res.json({
    hasAdmin: admins.length > 0,
    count: admins.length,
  });
});

// Setup First Administrator (Unauthenticated, ONLY allowed when hasAdmin is false)
router.post('/setup-admin', (req: Request, res: Response) => {
  if (db.getAdmins().length > 0) {
    return res.status(403).json({
      error: 'Administrator account already exists. Please log in as Admin to create/manage additional administrators.',
    });
  }

  const { name, email, password, institution_id } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }

  const existingUser = db.getUserByEmail(email);
  if (existingUser) {
    return res.status(409).json({ error: 'A user with this email address already exists' });
  }

  const instId = institution_id || db.getInstitutions()[0]?.id || 'inst-niet';
  const newAdmin = db.addAdmin({ name, email, password, institution_id: instId });
  const token = generateToken(newAdmin);

  res.status(201).json({
    success: true,
    message: 'Primary Administrator account created successfully.',
    token,
    user: {
      id: newAdmin.id,
      institution_id: newAdmin.institution_id,
      name: newAdmin.name,
      email: newAdmin.email,
      institutional_email: newAdmin.institutional_email,
      role: newAdmin.role,
    },
    redirectPath: '/admin/dashboard',
  });
});

// List Administrators (Admin only)
router.get('/admins', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can view administrator accounts' });
  }
  const admins = db.getAdmins(req.user.institutionId).map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    institutional_email: u.institutional_email,
    role: u.role,
    created_at: u.created_at,
  }));
  res.json(admins);
});

// Create Additional Administrator (Admin only)
router.post('/create-admin', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can create additional administrators' });
  }

  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }

  const institutionId = req.user.institutionId || 'inst-niet';
  const existingUser = db.getUserByEmail(email, institutionId);
  if (existingUser) {
    return res.status(409).json({ error: 'A user with this email already exists' });
  }

  const newAdmin = db.addAdmin({ name, email, password, institution_id: institutionId });
  res.status(201).json({
    success: true,
    message: `Administrator ${newAdmin.name} created successfully.`,
    user: {
      id: newAdmin.id,
      institution_id: newAdmin.institution_id,
      name: newAdmin.name,
      email: newAdmin.email,
      institutional_email: newAdmin.institutional_email,
      role: newAdmin.role,
    },
  });
});

// Delete Administrator (Admin only)
router.delete('/admins/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can delete administrator accounts' });
  }

  if (req.user.userId === req.params.id) {
    return res.status(400).json({ error: 'You cannot delete your own logged-in administrator account' });
  }

  try {
    const institutionId = req.user.institutionId || 'inst-niet';
    const deleted = db.deleteAdmin(req.params.id, institutionId);
    if (!deleted) {
      return res.status(404).json({ error: 'Administrator not found' });
    }
    res.json({ success: true, message: 'Administrator account deleted successfully' });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not delete administrator' });
  }
});

router.get('/me', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const user = db.getUserById(req.user.userId);
  if (!user) {
    return res.status(404).json({ error: 'User profile not found' });
  }

  let studentProfile = null;
  let facultyProfile = null;

  if (user.role === 'student') {
    studentProfile = db.getStudentByUserId(user.id);
  } else if (user.role === 'faculty') {
    facultyProfile = db.getFacultyByUserId(user.id);
  }

  res.json({
    user: {
      id: user.id,
      institution_id: user.institution_id,
      name: user.name,
      email: user.email,
      institutional_email: user.institutional_email,
      role: user.role,
    },
    student: studentProfile,
    faculty: facultyProfile,
  });
});

export default router;
