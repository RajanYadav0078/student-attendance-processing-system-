import { Router, type Response } from 'express';
import QRCode from 'qrcode';
import { db } from '../db.ts';
import { authMiddleware, roleMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// Create attendance session & generate QR Code
router.post('/session', authMiddleware, roleMiddleware(['faculty', 'admin']), async (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    const { subjectId, section, lectureTopic, durationMinutes } = req.body;
    let facultyId = req.body.facultyId;

    if (!facultyId && req.user?.role === 'faculty') {
      const fac = db.getFacultyByUserId(req.user.userId);
      facultyId = fac?.id;
    }

    if (!facultyId && subjectId) {
      const subj = db.getSubjects(institutionId).find((s) => s.id === subjectId);
      if (subj?.faculty_id) {
        facultyId = subj.faculty_id;
      }
    }

    if (!facultyId) {
      const allFaculty = db.getFaculty(institutionId);
      if (allFaculty.length > 0) {
        facultyId = allFaculty[0].id;
      }
    }

    if (!subjectId || !facultyId || !section) {
      return res.status(400).json({ error: 'Subject, Faculty, and Section are required' });
    }

    const session = db.createSession(
      institutionId,
      subjectId,
      facultyId,
      section,
      lectureTopic || 'Class Lecture',
      durationMinutes ? Number(durationMinutes) : 15
    );

    // Payload embedded in QR Code
    const qrPayload = JSON.stringify({
      app: 'Student Attendance Processing System',
      institutionId,
      sessionId: session.id,
      token: session.qr_token,
      subjectCode: session.subject_code,
      section: session.section,
      expiresAt: session.expires_at,
    });

    const qrDataUrl = await QRCode.toDataURL(qrPayload, {
      width: 400,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    });

    session.qr_data_url = qrDataUrl;

    res.status(201).json(session);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create attendance session' });
  }
});

// Get session details and active attendees
router.get('/session/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const session = db.getSessionById(req.params.id, institutionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found in this institution' });
  }

  // Get students in this section belonging to the institution
  const sectionStudents = db.getStudents(institutionId).filter((s) => s.section === session.section);

  // Get attendance records for this session
  const records = db.getAttendanceRecords(institutionId).filter((a) => a.session_id === session.id);

  // Map each student to their attendance status in this session
  const studentStatusList = sectionStudents.map((st) => {
    const rec = records.find((r) => r.student_id === st.id);
    return {
      student_id: st.id,
      roll_number: st.roll_number,
      name: st.name,
      email: st.email,
      rfid_id: st.rfid_id,
      status: rec ? rec.status : 'absent',
      time: rec?.time,
      method: rec?.method,
      record_id: rec?.id,
    };
  });

  const presentCount = studentStatusList.filter((s) => s.status === 'present').length;
  const absentCount = studentStatusList.length - presentCount;

  res.json({
    session,
    students: studentStatusList,
    total_students: studentStatusList.length,
    present_count: presentCount,
    absent_count: absentCount,
  });
});

// Close session
router.post('/session/:id/close', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const closed = db.closeSession(req.params.id, institutionId);
  if (!closed) {
    return res.status(404).json({ error: 'Session not found in this institution' });
  }
  res.json({ success: true, session: closed });
});

// Mark individual attendance (Used by Student QR Scanner or Faculty Toggle)
router.post('/mark', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const { sessionId, qrToken, studentId, status, method, remarks, location } = req.body;

  let targetSessionId = sessionId;
  let targetStudentId = studentId;
  if (qrToken) {
    const session = db.getSessionByQrToken(qrToken);
    if (!session) {
      return res.status(400).json({ error: 'Invalid or non-existent QR token' });
    }
    if (session.institution_id !== institutionId) {
      return res.status(403).json({ error: 'Cross-institution QR attendance rejected' });
    }
    targetSessionId = session.id;
  }

  // If student is scanning, their identity comes from their auth profile
  if (req.user?.role === 'student') {
    const student = db.getStudentByUserId(req.user.userId);
    if (!student) {
      return res.status(404).json({ error: 'Student profile not linked to user account' });
    }
    targetStudentId = student.id;
  } else if (!targetStudentId) {
    // When faculty or administrator tests the scan workflow, assign to the section's enrolled student
    const session = targetSessionId ? db.getSessionById(targetSessionId, institutionId) : null;
    const secStudents = session
      ? db.getStudents(institutionId).filter((s) => s.section === session.section)
      : db.getStudents(institutionId);
    if (secStudents.length > 0) {
      targetStudentId = secStudents[0].id;
    }
  }

  if (!targetStudentId) {
    return res.status(400).json({ error: 'Student ID is required' });
  }

  if (!targetSessionId) {
    return res.status(400).json({ error: 'Session ID or valid QR Token is required' });
  }

  const markedBy = req.user?.userId || 'system';
  const attendanceStatus = status || 'present';
  const attendanceMethod = method || (qrToken ? 'qr' : 'manual');

  const result = db.markAttendance(
    institutionId,
    targetStudentId,
    targetSessionId,
    attendanceStatus,
    markedBy,
    attendanceMethod,
    remarks,
    location
  );

  if (!result.success) {
    const statusCode = result.duplicate ? 409 : (result.geofenceBreach ? 403 : 400);
    return res.status(statusCode).json({
      error: result.message,
      duplicate: result.duplicate,
      geofenceBreach: result.geofenceBreach,
      distance: result.distance,
    });
  }

  res.json(result);
});

// Bulk save attendance sheet (Faculty)
router.post('/bulk', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const { sessionId, records } = req.body;
  if (!sessionId || !Array.isArray(records)) {
    return res.status(400).json({ error: 'Session ID and records array are required' });
  }

  let facultyId = req.user?.userId || 'faculty';
  if (req.user?.role === 'faculty') {
    const fac = db.getFacultyByUserId(req.user.userId);
    if (fac) facultyId = fac.id;
  }

  try {
    const result = db.saveBulkAttendance(institutionId, sessionId, facultyId, records);
    res.json({
      success: true,
      message: `Successfully saved attendance for ${result.count} students. Undo frame pushed to stack.`,
      undoStackId: result.undoStackId,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to save attendance records' });
  }
});

// Undo latest attendance operation
router.post('/undo', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const { sessionId } = req.body;
  let facultyId = req.user?.userId || '';

  if (req.user?.role === 'faculty') {
    const fac = db.getFacultyByUserId(req.user.userId);
    if (fac) facultyId = fac.id;
  }

  const result = db.undoLatestAttendance(institutionId, facultyId, sessionId);
  if (!result.success) {
    return res.status(400).json({ error: result.message });
  }

  res.json(result);
});

// Simulated RFID Hardware Reader Endpoint
router.post('/rfid-tap', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const { rfidId, sessionId } = req.body;
  if (!rfidId || !sessionId) {
    return res.status(400).json({ error: 'RFID Tag UID and Session ID are required' });
  }

  const student = db.getStudents(institutionId).find((s) => s.rfid_id === rfidId);
  if (!student) {
    return res.status(404).json({
      error: `Hardware Bus Exception: Unrecognized RFID tag UID "${rfidId}" in this institution.`,
    });
  }

  const markedBy = req.user?.userId || 'rfid-hardware-bus';
  const result = db.markAttendance(institutionId, student.id, sessionId, 'present', markedBy, 'rfid', 'Logged via RFID Reader Bus');

  if (!result.success) {
    return res.status(result.duplicate ? 409 : 400).json({
      error: result.message,
      duplicate: result.duplicate,
      student,
    });
  }

  res.json({
    success: true,
    message: `RFID Card Tap Recognized! Marked Present for ${student.name} (${student.roll_number}) at ${result.record?.time}`,
    student,
    record: result.record,
  });
});

// Master attendance records query (Admin & Faculty)
router.get('/records', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const { subjectId, section, studentId, date, status, method, search } = req.query;
  let records = db.getAttendanceRecords(institutionId);

  if (subjectId) {
    records = records.filter((r) => r.subject_id === String(subjectId));
  }
  if (studentId) {
    records = records.filter((r) => r.student_id === String(studentId));
  }
  if (date) {
    records = records.filter((r) => r.date === String(date));
  }
  if (status) {
    records = records.filter((r) => r.status === String(status));
  }
  if (method) {
    records = records.filter((r) => r.method === String(method));
  }
  if (search) {
    const q = String(search).toLowerCase();
    records = records.filter(
      (r) =>
        (r.student_name && r.student_name.toLowerCase().includes(q)) ||
        (r.roll_number && r.roll_number.toLowerCase().includes(q)) ||
        (r.subject_code && r.subject_code.toLowerCase().includes(q))
    );
  }

  // Sort descending by date and time
  records.sort((a, b) => new Date(b.date + 'T' + b.time).getTime() - new Date(a.date + 'T' + a.time).getTime());

  res.json(records);
});

// ==========================================
// ATTENDANCE CORRECTION & DISPUTE REQUESTS
// ==========================================

// Get my attendance requests (Student)
router.get('/requests/my', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const student = db.getStudentByUserId(req.user!.userId);
  if (!student) {
    return res.status(404).json({ error: 'Student profile not linked to user account' });
  }

  const requests = db.getAttendanceRequestsByStudent(student.id, institutionId);
  res.json(requests);
});

// Get faculty-assigned requests (Faculty & Admin)
router.get('/requests/faculty', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  if (req.user?.role === 'admin') {
    const allRequests = db.getAttendanceRequests(institutionId);
    return res.json(allRequests);
  }

  const fac = db.getFacultyByUserId(req.user!.userId);
  if (!fac) {
    // If not direct faculty match, check if faculty ID in database or return all institution requests
    const facultyList = db.getFaculty(institutionId);
    if (facultyList.length > 0) {
      return res.json(db.getAttendanceRequestsByFaculty(facultyList[0].id, institutionId));
    }
    return res.json([]);
  }

  const requests = db.getAttendanceRequestsByFaculty(fac.id, institutionId);
  res.json(requests);
});

// Get all requests with contextual role filtering
router.get('/requests', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  if (req.user?.role === 'student') {
    const student = db.getStudentByUserId(req.user.userId);
    if (!student) return res.json([]);
    return res.json(db.getAttendanceRequestsByStudent(student.id, institutionId));
  } else if (req.user?.role === 'faculty') {
    const fac = db.getFacultyByUserId(req.user.userId);
    if (!fac) return res.json(db.getAttendanceRequests(institutionId));
    return res.json(db.getAttendanceRequestsByFaculty(fac.id, institutionId));
  }

  res.json(db.getAttendanceRequests(institutionId));
});

// Submit new attendance correction request (Student)
router.post('/requests', authMiddleware, (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    let targetStudentId = req.body.student_id;
    if (req.user?.role === 'student') {
      const student = db.getStudentByUserId(req.user.userId);
      if (!student) {
        return res.status(404).json({ error: 'Student profile not linked to user account' });
      }
      targetStudentId = student.id;
    }

    if (!targetStudentId) {
      return res.status(400).json({ error: 'Student ID is required' });
    }

    const {
      subject_id,
      session_id,
      date,
      category,
      reason,
      proof_note,
    } = req.body;

    if (!subject_id) {
      return res.status(400).json({ error: 'Subject is required' });
    }
    if (!date) {
      return res.status(400).json({ error: 'Date is required' });
    }
    if (!reason || reason.trim().length < 5) {
      return res.status(400).json({ error: 'Please provide a clear explanation for the attendance request' });
    }

    const validCategories = ['technical_glitch', 'marked_absent_by_mistake', 'medical_leave', 'college_duty', 'other'];
    const resolvedCategory = validCategories.includes(category) ? category : 'other';

    const newRequest = db.createAttendanceRequest({
      institution_id: institutionId,
      student_id: targetStudentId,
      subject_id,
      session_id: session_id || undefined,
      date,
      category: resolvedCategory,
      reason: reason.trim(),
      proof_note: proof_note ? proof_note.trim() : undefined,
    });

    res.status(201).json({
      success: true,
      message: 'Attendance correction request submitted to faculty successfully.',
      request: newRequest,
    });
  } catch (error: any) {
    console.error('Error creating attendance dispute request:', error);
    res.status(500).json({ error: error.message || 'Failed to submit attendance request' });
  }
});

// Multi-Tier Step 1: Faculty Verification (Faculty & Admin)
// Verifies classroom presence/proofs and forwards to Academic Administration
router.post('/requests/:id/faculty-verify', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    const { remarks } = req.body;
    let facultyId = req.user?.userId || 'faculty';
    if (req.user?.role === 'faculty') {
      const fac = db.getFacultyByUserId(req.user.userId);
      if (fac) facultyId = fac.id;
    }

    const result = db.facultyVerifyAttendanceRequest(
      req.params.id,
      remarks || 'Verified physical attendance in classroom.',
      facultyId,
      institutionId
    );

    if (!result.success) {
      return res.status(404).json({ error: result.message });
    }

    res.json(result);
  } catch (error: any) {
    console.error('Error during faculty verification:', error);
    res.status(500).json({ error: error.message || 'Failed to verify attendance request' });
  }
});

// Multi-Tier Step 2: Admin Final Approval (Admin only)
// Authorizes the correction and updates the central attendance registry to Present
router.post('/requests/:id/admin-approve', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    const { remarks } = req.body;
    const adminUserId = req.user?.userId || 'admin';

    const result = db.adminApproveAttendanceRequest(
      req.params.id,
      remarks || 'Final administrative authorization granted.',
      adminUserId,
      institutionId
    );

    if (!result.success) {
      return res.status(404).json({ error: result.message });
    }

    res.json(result);
  } catch (error: any) {
    console.error('Error during admin final approval:', error);
    res.status(500).json({ error: error.message || 'Failed to authorize attendance request' });
  }
});

// Dispute Rejection (Faculty or Admin)
router.post('/requests/:id/reject', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    const { remarks } = req.body;
    const role = req.user?.role || 'faculty';
    let userId = req.user?.userId || 'reviewer';
    if (role === 'faculty') {
      const fac = db.getFacultyByUserId(req.user!.userId);
      if (fac) userId = fac.id;
    }

    const result = db.rejectAttendanceRequest(
      req.params.id,
      remarks || 'Attendance correction declined.',
      userId,
      role,
      institutionId
    );

    if (!result.success) {
      return res.status(404).json({ error: result.message });
    }

    res.json(result);
  } catch (error: any) {
    console.error('Error rejecting attendance dispute:', error);
    res.status(500).json({ error: error.message || 'Failed to decline attendance request' });
  }
});

// Context-aware Action Endpoint (Maintains compatibility)
router.post('/requests/:id/action', authMiddleware, roleMiddleware(['faculty', 'admin']), (req: AuthRequest, res: Response) => {
  try {
    const institutionId = req.user?.institutionId;
    if (!institutionId) {
      return res.status(400).json({ error: 'Institution session required' });
    }

    const { action, remarks } = req.body;
    const userRole = req.user?.role || 'faculty';
    let userId = req.user?.userId || 'reviewer';
    if (userRole === 'faculty') {
      const fac = db.getFacultyByUserId(req.user!.userId);
      if (fac) userId = fac.id;
    }

    if (action === 'reject' || action === 'rejected') {
      const result = db.rejectAttendanceRequest(req.params.id, remarks || 'Declined', userId, userRole, institutionId);
      if (!result.success) return res.status(404).json({ error: result.message });
      return res.json(result);
    }

    if (action === 'faculty_verify' || (action === 'approve' && userRole === 'faculty')) {
      const result = db.facultyVerifyAttendanceRequest(req.params.id, remarks || 'Verified by faculty', userId, institutionId);
      if (!result.success) return res.status(404).json({ error: result.message });
      return res.json(result);
    }

    // Admin direct approval
    const result = db.adminApproveAttendanceRequest(req.params.id, remarks || 'Approved by Admin', userId, institutionId);
    if (!result.success) return res.status(404).json({ error: result.message });
    res.json(result);
  } catch (error: any) {
    console.error('Error actioning attendance dispute:', error);
    res.status(500).json({ error: error.message || 'Failed to process request action' });
  }
});

// ==========================================
// CAMPUS GEOFENCING CONFIGURATION ENDPOINTS
// ==========================================
router.get('/geofence', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const config = db.getGeofenceConfig(institutionId);
  res.json(config);
});

router.put('/geofence', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution session required' });
  }

  const { enabled, campus_name, latitude, longitude, radius_meters } = req.body;
  const updated = db.updateGeofenceConfig(
    institutionId,
    {
      enabled: typeof enabled === 'boolean' ? enabled : undefined,
      campus_name: campus_name ? String(campus_name).trim() : undefined,
      latitude: typeof latitude === 'number' ? latitude : undefined,
      longitude: typeof longitude === 'number' ? longitude : undefined,
      radius_meters: typeof radius_meters === 'number' ? radius_meters : undefined,
    },
    req.user?.userId
  );

  res.json({
    success: true,
    message: `Campus geofence perimeter updated (${updated.radius_meters}m boundary around ${updated.campus_name}).`,
    geofence: updated,
  });
});

export default router;
