import { Router, type Response } from 'express';
import { db } from '../db.ts';
import { authMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// List students with filters (Tenant-isolated)
router.get('/', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const { branch, semester, section, search } = req.query;
  let students = db.getStudents(institutionId);

  if (branch) {
    students = students.filter((s) => s.branch.toLowerCase().includes(String(branch).toLowerCase()));
  }
  if (semester) {
    students = students.filter((s) => s.semester === Number(semester));
  }
  if (section) {
    students = students.filter((s) => s.section.toLowerCase() === String(section).toLowerCase());
  }
  if (search) {
    const q = String(search).toLowerCase();
    students = students.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.roll_number.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        (s.institutional_email && s.institutional_email.toLowerCase().includes(q))
    );
  }

  // Include attendance profile summary for each student
  const studentsWithSummary = students.map((s) => {
    const profile = db.calculateStudentAttendance(s.id, institutionId);
    return {
      ...s,
      overall_percentage: profile?.overall_percentage ?? 100,
      total_classes: profile?.total_classes ?? 0,
      attended_classes: profile?.attended_classes ?? 0,
      is_eligible: profile?.is_eligible ?? true,
    };
  });

  res.json(studentsWithSummary);
});

// Get individual student profile & detailed attendance
router.get('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const studentId = req.params.id;
  const profile = db.calculateStudentAttendance(studentId, institutionId);

  if (!profile) {
    return res.status(404).json({ error: 'Student not found in your institution' });
  }

  // Also include recent attendance records for this student
  const records = db
    .getAttendanceRecords(institutionId)
    .filter((a) => a.student_id === studentId)
    .sort((a, b) => new Date(b.date + 'T' + b.time).getTime() - new Date(a.date + 'T' + a.time).getTime());

  res.json({
    ...profile,
    recent_records: records,
  });
});

// Admin: Add student (Only Institution Admin can add students)
router.post('/', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can add students.' });
  }

  const institutionId = req.body.institution_id || req.user.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution association required to add students.' });
  }

  const { name, roll_number, email, institutional_email, branch, semester, section, rfid_id, password } = req.body;

  if (!name || !roll_number || !email) {
    return res.status(400).json({ error: 'Name, roll number, and student email are required' });
  }

  const existingRoll = db.getStudentByRoll(roll_number, institutionId);
  if (existingRoll) {
    return res.status(409).json({ error: `Student with roll number ${roll_number} already exists in this institution` });
  }

  const existingEmail = db.getUserByEmail(email, institutionId);
  if (existingEmail) {
    return res.status(409).json({ error: `User with email ${email} already exists` });
  }

  const newStudent = db.addStudent({
    institution_id: institutionId,
    name,
    roll_number,
    email,
    institutional_email,
    branch: branch || 'Computer Science & Engineering',
    semester: Number(semester) || 1,
    section: section || 'A',
    rfid_id: rfid_id || `RFID-${Math.floor(10000 + Math.random() * 90000)}`,
    password: password || 'password123',
  });

  res.status(201).json(newStudent);
});

// Admin: Update student
router.put('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can update student records.' });
  }

  const institutionId = req.user.institutionId;
  const updated = db.updateStudent(req.params.id, req.body, institutionId);
  if (!updated) {
    return res.status(404).json({ error: 'Student not found in this institution' });
  }
  res.json(updated);
});

// Admin: Delete student
router.delete('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can delete students.' });
  }

  const institutionId = req.user.institutionId;
  const deleted = db.deleteStudent(req.params.id, institutionId);
  if (!deleted) {
    return res.status(404).json({ error: 'Student not found in this institution' });
  }
  res.json({ success: true, message: 'Student and associated records removed successfully' });
});

export default router;
