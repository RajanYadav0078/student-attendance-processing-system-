import { Router, type Response } from 'express';
import { db } from '../db.ts';
import { authMiddleware, roleMiddleware, type AuthRequest } from '../auth.ts';

const router = Router();

// List all faculty for current institution
router.get('/', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const facultyList = db.getFaculty(institutionId).map((f) => {
    const subjects = db.getSubjects(institutionId).filter((s) => s.faculty_id === f.id);
    return {
      ...f,
      assigned_subjects: subjects,
    };
  });
  res.json(facultyList);
});

// Get faculty details + subjects + today's lectures
router.get('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const faculty = db.getFacultyById(req.params.id, institutionId);
  if (!faculty) {
    return res.status(404).json({ error: 'Faculty member not found in this institution' });
  }

  const subjects = db.getSubjects(institutionId).filter((s) => s.faculty_id === faculty.id);
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySessions = db
    .getSessions(institutionId)
    .filter((s) => s.faculty_id === faculty.id && s.date === todayStr);

  const allFacultySessions = db.getSessions(institutionId).filter((s) => s.faculty_id === faculty.id);

  res.json({
    ...faculty,
    assigned_subjects: subjects,
    today_sessions: todaySessions,
    total_sessions_count: allFacultySessions.length,
  });
});

// Admin: Add faculty (Only Institution Admin can add faculty)
router.post('/', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.body.institution_id || req.user?.institutionId;
  if (!institutionId) {
    return res.status(400).json({ error: 'Institution association required to add faculty' });
  }

  const { name, email, institutional_email, employee_id, department, assigned_subject_ids, password } = req.body;

  if (!name || !email || !employee_id) {
    return res.status(400).json({ error: 'Name, email, and employee ID are required' });
  }

  const existingEmail = db.getUserByEmail(email, institutionId);
  if (existingEmail) {
    return res.status(409).json({ error: `User with email ${email} already exists` });
  }

  const newFaculty = db.addFaculty({
    institution_id: institutionId,
    name,
    email,
    institutional_email,
    employee_id,
    department: department || 'Computer Science & Engineering',
    assigned_subject_ids: assigned_subject_ids || [],
    password: password || 'password123',
  });

  res.status(201).json(newFaculty);
});

// Admin: Update faculty
router.put('/:id', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const updated = db.updateFaculty(req.params.id, req.body, institutionId);
  if (!updated) {
    return res.status(404).json({ error: 'Faculty not found in this institution' });
  }
  res.json(updated);
});

// Admin: Delete faculty
router.delete('/:id', authMiddleware, roleMiddleware(['admin']), (req: AuthRequest, res: Response) => {
  const institutionId = req.user?.institutionId;
  const deleted = db.deleteFaculty(req.params.id, institutionId);
  if (!deleted) {
    return res.status(404).json({ error: 'Faculty not found in this institution' });
  }
  res.json({ success: true, message: 'Faculty removed successfully' });
});

export default router;
