export type UserRole = 'student' | 'faculty' | 'admin';

export type InstitutionType = 'college' | 'university' | 'institute' | 'school';

export interface Institution {
  id: string;
  name: string;
  type: InstitutionType;
  affiliation?: string;
  aishe_code?: string;
  website?: string;
  address: string;
  city: string;
  state: string;
  country: string;
  domain: string; // e.g. "niet.co.in"
  admin_name: string;
  admin_designation?: string;
  official_contact?: string;
  official_email: string;
  institutional_admin_email: string; // e.g. "admin@niet.co.in"
  verification_status: 'pending' | 'verified';
  verification_token: string; // e.g. "attendance-verification=ABC123XYZ"
  verified_at?: string;
  email_service_provider?: 'none' | 'google_workspace' | 'microsoft_365' | 'custom_mail_server' | 'smtp';
  mailbox_status: 'pending' | 'active' | 'not_configured';
  created_at: string;
}

export interface InstitutionDomain {
  id: string;
  institution_id: string;
  domain: string;
  verification_token: string;
  verified_at?: string;
  status: 'pending' | 'verified';
}

export interface User {
  id: string;
  institution_id: string;
  name: string;
  email: string;
  institutional_email?: string;
  password_hash: string;
  role: UserRole;
  status?: 'active' | 'pending' | 'inactive';
  created_at: string;
}

export interface Student {
  id: string;
  institution_id: string;
  user_id: string;
  roll_number: string;
  name: string;
  email: string;
  institutional_email?: string;
  mailbox_status?: 'pending' | 'active' | 'not_configured';
  branch: string;
  semester: number;
  section: string;
  rfid_id: string;
}

export interface Faculty {
  id: string;
  institution_id: string;
  user_id: string;
  employee_id: string;
  name: string;
  email: string;
  institutional_email?: string;
  mailbox_status?: 'pending' | 'active' | 'not_configured';
  department: string;
  assigned_subject_ids: string[];
}

export interface Subject {
  id: string;
  institution_id: string;
  subject_code: string;
  subject_name: string;
  faculty_id: string;
  faculty_name?: string;
  semester: number;
  branch: string;
  total_credits: number;
}

export interface ClassSection {
  id: string;
  institution_id: string;
  name: string; // e.g. "CSE-3A"
  branch: string;
  semester: number;
  section: string;
}

export interface AttendanceSession {
  id: string;
  institution_id: string;
  subject_id: string;
  subject_name?: string;
  subject_code?: string;
  faculty_id: string;
  faculty_name?: string;
  section: string;
  lecture_topic: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  duration_minutes: number;
  qr_token: string;
  qr_data_url?: string;
  created_at: string;
  expires_at: string;
  status: 'active' | 'closed';
}

export interface GeoLocationLog {
  latitude: number;
  longitude: number;
  accuracy?: number;
  distance_meters: number;
  is_within_geofence: boolean;
  verified_at: string;
}

export interface GeofenceConfig {
  enabled: boolean;
  campus_name: string;
  latitude: number;
  longitude: number;
  radius_meters: number;
}

export interface AttendanceRecord {
  id: string;
  institution_id: string;
  student_id: string;
  student_name?: string;
  roll_number?: string;
  subject_id: string;
  subject_code?: string;
  subject_name?: string;
  session_id: string;
  date: string;
  time: string;
  status: 'present' | 'absent';
  marked_by: string; // faculty ID, student ID, or admin
  method: 'qr' | 'manual' | 'rfid';
  remarks?: string;
  location?: GeoLocationLog;
}

export interface UndoStackItem {
  id: string;
  institution_id: string;
  timestamp: string;
  session_id: string;
  faculty_id: string;
  records: AttendanceRecord[];
  description: string;
}

export interface SystemSettings {
  institution_id?: string;
  eligibility_threshold: number; // default 75
  academic_year: string;
  semester_name: string;
  institute_name: string;
  course_code: string;
  course_name: string;
  program: string;
  geofence?: GeofenceConfig;
}

export interface SystemNotification {
  id: string;
  institution_id: string;
  user_id: string;
  role?: UserRole;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'alert' | 'success';
  is_read: boolean;
  created_at: string;
}

export interface AuditLog {
  id: string;
  institution_id: string;
  user_id: string;
  user_name: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface AiChatMessage {
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface SubjectAttendanceSummary {
  subject_id: string;
  subject_code: string;
  subject_name: string;
  faculty_name: string;
  total_classes: number;
  attended_classes: number;
  absent_classes: number;
  attendance_percentage: number;
  is_eligible: boolean;
}

export interface StudentAttendanceProfile {
  student: Student;
  overall_percentage: number;
  total_classes: number;
  attended_classes: number;
  absent_classes: number;
  is_eligible: boolean;
  subjects: SubjectAttendanceSummary[];
}

export type AttendanceDisputeCategory =
  | 'technical_glitch'
  | 'marked_absent_by_mistake'
  | 'medical_leave'
  | 'college_duty'
  | 'other';

export type AttendanceDisputeStatus =
  | 'pending'
  | 'pending_faculty'
  | 'faculty_verified'
  | 'approved'
  | 'rejected';

export interface AttendanceCorrectionRequest {
  id: string;
  institution_id: string;
  student_id: string;
  student_name: string;
  roll_number: string;
  section: string;
  faculty_id: string;
  faculty_name?: string;
  subject_id: string;
  subject_code: string;
  subject_name: string;
  session_id?: string;
  session_topic?: string;
  date: string;
  category: AttendanceDisputeCategory;
  reason: string;
  proof_note?: string;
  status: AttendanceDisputeStatus;
  faculty_remarks?: string;
  faculty_verified_at?: string;
  faculty_verified_by?: string;
  admin_remarks?: string;
  admin_approved_at?: string;
  admin_approved_by?: string;
  created_at: string;
  resolved_at?: string;
}
