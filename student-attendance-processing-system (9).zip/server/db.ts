import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  User,
  Student,
  Faculty,
  Subject,
  ClassSection,
  AttendanceSession,
  AttendanceRecord,
  UndoStackItem,
  SystemSettings,
  SystemNotification,
  SubjectAttendanceSummary,
  StudentAttendanceProfile,
  Institution,
  InstitutionDomain,
  AuditLog,
  AiChatMessage,
  AttendanceCorrectionRequest,
  AttendanceDisputeCategory,
  GeoLocationLog,
  GeofenceConfig,
} from './types.ts';
import { hashPassword, generateToken } from './auth.ts';

// Haversine formula: Computes great-circle distance in meters between two GPS coordinates
export function calculateHaversineDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // Earth radius in metres
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '../database/data.json');

interface DatabaseSchema {
  institutions: Institution[];
  institution_domains: InstitutionDomain[];
  users: User[];
  students: Student[];
  faculty: Faculty[];
  subjects: Subject[];
  classes: ClassSection[];
  sessions: AttendanceSession[];
  attendance: AttendanceRecord[];
  undoStack: UndoStackItem[];
  settings: SystemSettings;
  notifications: SystemNotification[];
  auditLogs: AuditLog[];
  aiConversations: Record<string, AiChatMessage[]>;
  attendance_requests: AttendanceCorrectionRequest[];
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadDatabase();
    if (!this.data || !this.data.institutions || this.data.institutions.length === 0) {
      this.data = this.seedDatabase();
      this.saveDatabase();
    }
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.institutions && parsed.users) {
          // Ensure all arrays exist
          parsed.institution_domains = parsed.institution_domains || [];
          parsed.auditLogs = parsed.auditLogs || [];
          parsed.aiConversations = parsed.aiConversations || {};
          parsed.attendance_requests = parsed.attendance_requests || [];
          if (parsed.settings && !parsed.settings.geofence) {
            parsed.settings.geofence = {
              enabled: true,
              campus_name: 'NIET Greater Noida Campus',
              latitude: 28.4632,
              longitude: 77.4939,
              radius_meters: 500,
            };
          }
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read existing database, initializing fresh seed.', e);
    }
    return this.seedDatabase();
  }

  public saveDatabase() {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write database file', e);
    }
  }

  public resetToDefault() {
    this.data = this.seedDatabase();
    this.saveDatabase();
    return this.data;
  }

  // --- Seed Data Generator ---
  private seedDatabase(): DatabaseSchema {
    const defaultSettings: SystemSettings = {
      institution_id: 'inst-niet',
      eligibility_threshold: 75,
      academic_year: '2026-2027',
      semester_name: 'Semester 3 (Fall)',
      institute_name: 'Noida Institute of Engineering and Technology',
      course_code: 'CCSE0304',
      course_name: 'Computer Architecture & Parallel Processing',
      program: 'B.Tech CSE, Semester 3',
      geofence: {
        enabled: true,
        campus_name: 'NIET Greater Noida Campus',
        latitude: 28.4632,
        longitude: 77.4939,
        radius_meters: 500,
      },
    };

    // Default seed institution for out-of-the-box demo
    const defaultInstitution: Institution = {
      id: 'inst-niet',
      name: 'Noida Institute of Engineering and Technology',
      type: 'institute',
      affiliation: 'Dr. A.P.J. Abdul Kalam Technical University',
      aishe_code: 'C-46141',
      website: 'https://www.niet.co.in',
      address: '19, Knowledge Park-II, Institutional Area',
      city: 'Greater Noida',
      state: 'Uttar Pradesh',
      country: 'India',
      domain: 'niet.co.in',
      admin_name: 'Dr. S. K. Raman',
      admin_designation: 'Principal & Academic Director',
      official_contact: '+91 98765 43210',
      official_email: 'principal@niet.co.in',
      institutional_admin_email: 'admin@niet.co.in',
      verification_status: 'verified',
      verification_token: 'attendance-verification=NIET789XYZ',
      verified_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      email_service_provider: 'google_workspace',
      mailbox_status: 'active',
      created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
    };

    const institutionDomains: InstitutionDomain[] = [
      {
        id: 'dom-1',
        institution_id: 'inst-niet',
        domain: 'niet.co.in',
        verification_token: 'attendance-verification=NIET789XYZ',
        verified_at: new Date('2026-08-01T08:00:00Z').toISOString(),
        status: 'verified',
      },
    ];

    // Administrator, Faculty, and Student users for default institution with default password
    const users: User[] = [
      {
        id: 'usr-admin-1',
        institution_id: 'inst-niet',
        name: 'Dr. S. K. Raman',
        email: 'admin@niet.co.in',
        institutional_email: 'admin@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'admin',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-fac-1',
        institution_id: 'inst-niet',
        name: 'Dr. Priya Sharma',
        email: 'priya@gmail.com',
        institutional_email: 'dr.priya.sharma@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'faculty',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-fac-2',
        institution_id: 'inst-niet',
        name: 'ARMIND',
        email: 'armind@niet.co.in',
        institutional_email: 'armind@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'faculty',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-1',
        institution_id: 'inst-niet',
        name: 'Aarav Sharma',
        email: 'aarav@gmail.com',
        institutional_email: 'aarav.sharma@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-2',
        institution_id: 'inst-niet',
        name: 'Riya Sen',
        email: 'riya.sen@niet.co.in',
        institutional_email: 'riya.sen@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-3',
        institution_id: 'inst-niet',
        name: 'Kabir Verma',
        email: 'kabir.verma@niet.co.in',
        institutional_email: 'kabir.verma@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-4',
        institution_id: 'inst-niet',
        name: 'Ananya Gupta',
        email: 'ananya.gupta@niet.co.in',
        institutional_email: 'ananya.gupta@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-5',
        institution_id: 'inst-niet',
        name: 'Rohan Mehta',
        email: 'rohan.mehta@niet.co.in',
        institutional_email: 'rohan.mehta@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
      {
        id: 'usr-std-6',
        institution_id: 'inst-niet',
        name: 'Devansh Joshi',
        email: 'devansh.joshi@niet.co.in',
        institutional_email: 'devansh.joshi@niet.co.in',
        password_hash: hashPassword('password123'),
        role: 'student',
        status: 'active',
        created_at: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
    ];

    const classes: ClassSection[] = [
      { id: 'cls-1', institution_id: 'inst-niet', name: 'CSE-3A', branch: 'Computer Science & Engineering', semester: 3, section: 'A' },
      { id: 'cls-2', institution_id: 'inst-niet', name: 'CSE-3B', branch: 'Computer Science & Engineering', semester: 3, section: 'B' },
      { id: 'cls-3', institution_id: 'inst-niet', name: 'CSE-3C', branch: 'Computer Science & Engineering', semester: 3, section: 'C' },
    ];

    const students: Student[] = [
      {
        id: 'std-1',
        institution_id: 'inst-niet',
        user_id: 'usr-std-1',
        roll_number: '26CSE042',
        name: 'Aarav Sharma',
        email: 'aarav@gmail.com',
        institutional_email: 'aarav.sharma@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'A',
        rfid_id: 'RFID-90421',
      },
      {
        id: 'std-2',
        institution_id: 'inst-niet',
        user_id: 'usr-std-2',
        roll_number: '26CSE043',
        name: 'Riya Sen',
        email: 'riya.sen@niet.co.in',
        institutional_email: 'riya.sen@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'A',
        rfid_id: 'RFID-90422',
      },
      {
        id: 'std-3',
        institution_id: 'inst-niet',
        user_id: 'usr-std-3',
        roll_number: '26CSE044',
        name: 'Kabir Verma',
        email: 'kabir.verma@niet.co.in',
        institutional_email: 'kabir.verma@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'A',
        rfid_id: 'RFID-90423',
      },
      {
        id: 'std-4',
        institution_id: 'inst-niet',
        user_id: 'usr-std-4',
        roll_number: '26CSE045',
        name: 'Ananya Gupta',
        email: 'ananya.gupta@niet.co.in',
        institutional_email: 'ananya.gupta@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'A',
        rfid_id: 'RFID-90424',
      },
      {
        id: 'std-5',
        institution_id: 'inst-niet',
        user_id: 'usr-std-5',
        roll_number: '26CSE046',
        name: 'Rohan Mehta',
        email: 'rohan.mehta@niet.co.in',
        institutional_email: 'rohan.mehta@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'A',
        rfid_id: 'RFID-90425',
      },
      {
        id: 'std-6',
        institution_id: 'inst-niet',
        user_id: 'usr-std-6',
        roll_number: '26CSE071',
        name: 'Devansh Joshi',
        email: 'devansh.joshi@niet.co.in',
        institutional_email: 'devansh.joshi@niet.co.in',
        mailbox_status: 'active',
        branch: 'Computer Science & Engineering',
        semester: 3,
        section: 'B',
        rfid_id: 'RFID-90426',
      },
    ];

    const faculty: Faculty[] = [
      {
        id: 'fac-1',
        institution_id: 'inst-niet',
        user_id: 'usr-fac-1',
        employee_id: 'FAC-CSE-001',
        name: 'Dr. Priya Sharma',
        email: 'priya@gmail.com',
        institutional_email: 'dr.priya.sharma@niet.co.in',
        department: 'Computer Science & Engineering',
        mailbox_status: 'active',
        assigned_subject_ids: ['sub-1'],
      },
      {
        id: 'fac-2',
        institution_id: 'inst-niet',
        user_id: 'usr-fac-2',
        employee_id: 'CSE-4',
        name: 'ARMIND',
        email: 'armind@niet.co.in',
        institutional_email: 'armind@niet.co.in',
        department: 'Computer Science & Engineering',
        mailbox_status: 'active',
        assigned_subject_ids: ['sub-2'],
      },
    ];

    const subjects: Subject[] = [
      {
        id: 'sub-1',
        institution_id: 'inst-niet',
        subject_code: 'CS-301',
        subject_name: 'Data Structures & Algorithms',
        branch: 'Computer Science & Engineering',
        semester: 3,
        total_credits: 4,
        faculty_id: 'fac-1',
        faculty_name: 'Dr. Priya Sharma',
      },
      {
        id: 'sub-2',
        institution_id: 'inst-niet',
        subject_code: 'CCSE0304',
        subject_name: 'Computer Architecture & Parallel Processing',
        branch: 'Computer Science & Engineering',
        semester: 3,
        total_credits: 4,
        faculty_id: 'fac-2',
        faculty_name: 'ARMIND',
      },
    ];

    const sessions: AttendanceSession[] = [];
    const attendance: AttendanceRecord[] = [];

    const notifications: SystemNotification[] = [
      {
        id: 'notif-1',
        institution_id: 'inst-niet',
        user_id: 'all',
        title: 'Multi-Institution Platform Operational',
        message: 'System active with verified domain niet.co.in. Add faculty and students to begin tracking.',
        type: 'info',
        is_read: false,
        created_at: new Date().toISOString(),
      },
    ];

    const auditLogs: AuditLog[] = [
      {
        id: 'log-1',
        institution_id: 'inst-niet',
        user_id: 'usr-admin-1',
        user_name: 'Dr. S. K. Raman',
        action: 'INSTITUTION_INITIALIZED',
        details: 'Institution Noida Institute of Engineering and Technology (niet.co.in) registered and verified.',
        timestamp: new Date('2026-08-01T08:00:00Z').toISOString(),
      },
    ];

    return {
      institutions: [defaultInstitution],
      institution_domains: institutionDomains,
      users,
      students,
      faculty,
      subjects,
      classes,
      sessions,
      attendance,
      undoStack: [],
      settings: defaultSettings,
      notifications,
      auditLogs,
      aiConversations: {},
      attendance_requests: [],
    };
  }

  // ==========================================
  // INSTITUTIONS & MULTI-TENANCY
  // ==========================================
  public getInstitutions(): Institution[] {
    return this.data.institutions;
  }

  public getInstitutionById(id: string): Institution | undefined {
    return this.data.institutions.find((i) => i.id === id);
  }

  public getInstitutionByDomain(domain: string): Institution | undefined {
    const cleanDomain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    return this.data.institutions.find((i) => i.domain.toLowerCase() === cleanDomain);
  }

  public registerInstitution(data: {
    name: string;
    type: 'college' | 'university' | 'institute' | 'school';
    affiliation?: string;
    aishe_code?: string;
    website?: string;
    address: string;
    city: string;
    state: string;
    country: string;
    domain: string;
    admin_name: string;
    admin_designation?: string;
    official_contact?: string;
    official_email: string;
    desired_username?: string;
    password: string;
  }): { institution: Institution; adminUser: User; token: string } {
    const cleanDomain = data.domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');

    // Check if domain already registered
    const existing = this.data.institutions.find((i) => i.domain.toLowerCase() === cleanDomain);
    if (existing) {
      throw new Error(`An institution with domain "${cleanDomain}" is already registered.`);
    }

    const institutionId = `inst-${Date.now().toString(36)}`;
    const now = new Date().toISOString();

    // Generate unique verification token
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const verificationToken = `attendance-verification=${randomSuffix}${Date.now().toString(36).toUpperCase()}`;

    // Format institutional email: e.g. admin@{domain}
    const adminUserPart = data.desired_username
      ? data.desired_username.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '')
      : 'admin';
    const institutionalAdminEmail = `${adminUserPart}@${cleanDomain}`;

    const newInstitution: Institution = {
      id: institutionId,
      name: data.name.trim(),
      type: data.type || 'college',
      affiliation: data.affiliation?.trim(),
      aishe_code: data.aishe_code?.trim(),
      website: data.website?.trim(),
      address: data.address.trim(),
      city: data.city.trim(),
      state: data.state.trim(),
      country: data.country.trim(),
      domain: cleanDomain,
      admin_name: data.admin_name.trim(),
      admin_designation: data.admin_designation?.trim() || 'Principal / Administrator',
      official_contact: data.official_contact?.trim(),
      official_email: data.official_email.trim().toLowerCase(),
      institutional_admin_email: institutionalAdminEmail,
      verification_status: 'pending',
      verification_token: verificationToken,
      email_service_provider: 'none',
      mailbox_status: 'pending',
      created_at: now,
    };

    this.data.institutions.push(newInstitution);

    // Track domain
    this.data.institution_domains.push({
      id: `dom-${Date.now()}`,
      institution_id: institutionId,
      domain: cleanDomain,
      verification_token: verificationToken,
      status: 'pending',
    });

    // Create primary administrator account
    const adminUserId = `usr-admin-${Date.now()}`;
    const adminUser: User = {
      id: adminUserId,
      institution_id: institutionId,
      name: data.admin_name.trim(),
      email: institutionalAdminEmail,
      institutional_email: institutionalAdminEmail,
      password_hash: hashPassword(data.password),
      role: 'admin',
      status: 'active',
      created_at: now,
    };

    this.data.users.push(adminUser);

    // Create default sections for this new institution
    this.data.classes.push(
      { id: `cls-${Date.now()}-1`, institution_id: institutionId, name: 'Section A', branch: 'Computer Science & Engineering', semester: 1, section: 'A' },
      { id: `cls-${Date.now()}-2`, institution_id: institutionId, name: 'Section B', branch: 'Computer Science & Engineering', semester: 1, section: 'B' }
    );

    // Log audit
    this.addAuditLog(
      institutionId,
      adminUserId,
      data.admin_name,
      'REGISTER_INSTITUTION',
      `Registered ${data.name} with domain ${cleanDomain}. Verification pending.`
    );

    this.saveDatabase();

    const token = generateToken(adminUser);
    return { institution: newInstitution, adminUser, token };
  }

  public verifyDomain(institutionId: string, token: string): { success: boolean; institution: Institution } {
    const inst = this.getInstitutionById(institutionId);
    if (!inst) throw new Error('Institution not found');

    // Verification check: matches token or simulation flag
    const normalizedToken = token.trim();
    if (normalizedToken !== inst.verification_token && !normalizedToken.includes(inst.verification_token.split('=')[1])) {
      throw new Error(`Invalid verification token. Expected TXT record: ${inst.verification_token}`);
    }

    inst.verification_status = 'verified';
    inst.verified_at = new Date().toISOString();

    const dom = this.data.institution_domains.find((d) => d.institution_id === institutionId && d.domain === inst.domain);
    if (dom) {
      dom.status = 'verified';
      dom.verified_at = inst.verified_at;
    }

    this.addAuditLog(
      institutionId,
      'system',
      inst.admin_name,
      'DOMAIN_VERIFIED',
      `Domain ${inst.domain} verified successfully via DNS TXT simulation record.`
    );

    this.saveDatabase();
    return { success: true, institution: inst };
  }

  public updateEmailConfig(
    institutionId: string,
    provider: 'none' | 'google_workspace' | 'microsoft_365' | 'custom_mail_server' | 'smtp',
    mailboxStatus: 'pending' | 'active' | 'not_configured'
  ): Institution {
    const inst = this.getInstitutionById(institutionId);
    if (!inst) throw new Error('Institution not found');

    inst.email_service_provider = provider;
    inst.mailbox_status = mailboxStatus;

    this.addAuditLog(
      institutionId,
      'admin',
      inst.admin_name,
      'EMAIL_CONFIG_UPDATED',
      `Updated email provider to ${provider} with mailbox status ${mailboxStatus}.`
    );

    this.saveDatabase();
    return inst;
  }

  public updateInstitution(institutionId: string, updates: Partial<Institution>): Institution | null {
    const idx = this.data.institutions.findIndex((i) => i.id === institutionId);
    if (idx === -1) return null;

    const oldDomain = this.data.institutions[idx].domain;
    if (updates.domain && updates.domain !== oldDomain) {
      // Re-trigger verification if domain changes
      updates.verification_status = 'pending';
      updates.verified_at = undefined;
      updates.verification_token = `attendance-verification=${Math.random().toString(36).substring(2, 8).toUpperCase()}${Date.now().toString(36).toUpperCase()}`;
    }

    this.data.institutions[idx] = { ...this.data.institutions[idx], ...updates };
    this.saveDatabase();
    return this.data.institutions[idx];
  }

  // ==========================================
  // USERS & AUTH (TENANT ISOLATED)
  // ==========================================
  public getUserByEmail(identifier: string, institutionId?: string): User | undefined {
    if (!identifier) return undefined;
    const raw = String(identifier).trim();
    const q = raw.toLowerCase();
    if (!q) return undefined;

    const matchInst = (u: User) => !institutionId || u.institution_id === institutionId;

    // 1. Direct match on user ID
    const idMatch = this.data.users.find((u) => u.id.toLowerCase() === q && matchInst(u));
    if (idMatch) return idMatch;

    // 2. Direct match on personal email or institutional email
    const directMatch = this.data.users.find((u) => {
      const emailMatches =
        u.email.toLowerCase() === q ||
        (u.institutional_email && u.institutional_email.toLowerCase() === q);
      return emailMatches && matchInst(u);
    });
    if (directMatch) return directMatch;

    // 3. Roll Number match for student accounts
    const student = this.data.students.find(
      (s) => s.roll_number.toLowerCase() === q && (!institutionId || s.institution_id === institutionId)
    );
    if (student) {
      const u = this.data.users.find((user) => user.id === student.user_id && matchInst(user));
      if (u) return u;
    }

    // 4. Employee ID match for faculty accounts
    const faculty = this.data.faculty.find(
      (f) => f.employee_id.toLowerCase() === q && (!institutionId || f.institution_id === institutionId)
    );
    if (faculty) {
      const u = this.data.users.find((user) => user.id === faculty.user_id && matchInst(user));
      if (u) return u;
    }

    // 5. RFID match for student accounts
    const studentRfid = this.data.students.find(
      (s) => s.rfid_id && s.rfid_id.toLowerCase() === q && (!institutionId || s.institution_id === institutionId)
    );
    if (studentRfid) {
      const u = this.data.users.find((user) => user.id === studentRfid.user_id && matchInst(user));
      if (u) return u;
    }

    // 6. Name match (exact, or title-stripped e.g. "Rajan Yadav", "Aarav Sharma", "Dr. Priya Sharma")
    const normalizeName = (str: string) =>
      str
        .toLowerCase()
        .replace(/^(dr|prof|mr|ms|mrs)\.?\s+/i, '')
        .replace(/[^\w\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    const qNorm = normalizeName(q);

    const nameMatch = this.data.users.find((u) => {
      const uNorm = normalizeName(u.name);
      return (u.name.toLowerCase() === q || uNorm === qNorm || uNorm === q) && matchInst(u);
    });
    if (nameMatch) return nameMatch;

    // 7. Username / Email prefix match (e.g. '0251146', 'aarav.sharma', 'rajan.yadav', 'armind', 'rajan')
    const prefixMatch = this.data.users.find((u) => {
      const p1 = (u.email.split('@')[0] || '').toLowerCase();
      const p2 = (u.institutional_email?.split('@')[0] || '').toLowerCase();
      const dotlessP1 = p1.replace(/\./g, ' ');
      const dotlessP2 = p2.replace(/\./g, ' ');
      if (p1 === q || p2 === q || dotlessP1 === q || dotlessP2 === q) {
        return matchInst(u);
      }
      return false;
    });
    if (prefixMatch) return prefixMatch;

    // 8. Partial Name match (e.g. searching "Rajan", "Aarav", "Priya", "Sharma")
    if (qNorm.length >= 3) {
      const partialName = this.data.users.find((u) => {
        const parts = normalizeName(u.name).split(' ');
        return parts.includes(qNorm) && matchInst(u);
      });
      if (partialName) return partialName;
    }

    // 9. Role keywords shortcuts ('admin', 'faculty', 'student', 'administrator', 'teacher')
    if (q === 'admin' || q === 'administrator' || q === 'inst-admin') {
      return this.data.users.find((u) => u.role === 'admin' && matchInst(u));
    }
    if (q === 'faculty' || q === 'teacher' || q === 'prof' || q === 'professor') {
      return this.data.users.find((u) => u.role === 'faculty' && matchInst(u));
    }
    if (q === 'student' || q === 'learner' || q === 'std') {
      return this.data.users.find((u) => u.role === 'student' && matchInst(u));
    }

    return undefined;
  }

  public getUsers(institutionId?: string): User[] {
    if (!institutionId) return this.data.users;
    return this.data.users.filter((u) => u.institution_id === institutionId);
  }

  public getUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public getAdmins(institutionId?: string): User[] {
    return this.data.users.filter((u) => u.role === 'admin' && (!institutionId || u.institution_id === institutionId));
  }

  public addAdmin(data: { name: string; email: string; password: string; institution_id: string }): User {
    const id = `usr-admin-${Date.now()}`;
    const newUser: User = {
      id,
      institution_id: data.institution_id,
      name: data.name,
      email: data.email,
      institutional_email: data.email,
      password_hash: hashPassword(data.password),
      role: 'admin',
      status: 'active',
      created_at: new Date().toISOString(),
    };
    this.data.users.push(newUser);
    this.addAuditLog(data.institution_id, id, data.name, 'CREATE_ADMIN', `Created additional administrator ${data.name} (${data.email}).`);
    this.saveDatabase();
    return newUser;
  }

  public deleteAdmin(id: string, institutionId: string): boolean {
    const adminCount = this.getAdmins(institutionId).length;
    if (adminCount <= 1) {
      throw new Error('Cannot delete the last remaining administrator of this institution.');
    }
    const admin = this.data.users.find((u) => u.id === id && u.role === 'admin' && u.institution_id === institutionId);
    if (!admin) return false;
    this.data.users = this.data.users.filter((u) => u.id !== id);
    this.addAuditLog(institutionId, id, admin.name, 'DELETE_ADMIN', `Deleted administrator account ${admin.name}.`);
    this.saveDatabase();
    return true;
  }

  // ==========================================
  // STUDENTS (TENANT ISOLATED & ADMIN CREATED)
  // ==========================================
  public getStudents(institutionId?: string): Student[] {
    if (!institutionId) return this.data.students;
    return this.data.students.filter((s) => s.institution_id === institutionId);
  }

  public getStudentById(id: string, institutionId?: string): Student | undefined {
    return this.data.students.find((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
  }

  public getStudentByUserId(userId: string): Student | undefined {
    return this.data.students.find((s) => s.user_id === userId);
  }

  public getStudentByRoll(rollNumber: string, institutionId?: string): Student | undefined {
    const r = rollNumber.trim().toLowerCase();
    return this.data.students.find(
      (s) => s.roll_number.toLowerCase() === r && (!institutionId || s.institution_id === institutionId)
    );
  }

  public addStudent(studentData: {
    institution_id: string;
    roll_number: string;
    name: string;
    email: string;
    institutional_email?: string;
    branch?: string;
    semester?: number;
    section?: string;
    rfid_id?: string;
    password?: string;
  }): Student {
    const id = `std-${Date.now()}`;
    const userId = `usr-std-${Date.now()}`;
    const password = studentData.password || 'password123';

    const inst = this.getInstitutionById(studentData.institution_id);
    const domain = inst?.domain || 'college.edu';

    // Auto-generate institutional email if requested or format clean identity
    let instEmail = studentData.institutional_email;
    if (!instEmail || instEmail.trim() === '') {
      const cleanName = studentData.name.trim().toLowerCase().replace(/\s+/g, '.').replace(/[^a-z0-9.]/g, '');
      instEmail = `${cleanName}@${domain}`;
    }

    const newUser: User = {
      id: userId,
      institution_id: studentData.institution_id,
      name: studentData.name,
      email: studentData.email,
      institutional_email: instEmail,
      password_hash: hashPassword(password),
      role: 'student',
      status: 'active',
      created_at: new Date().toISOString(),
    };
    this.data.users.push(newUser);

    const newStudent: Student = {
      id,
      institution_id: studentData.institution_id,
      user_id: userId,
      roll_number: studentData.roll_number,
      name: studentData.name,
      email: studentData.email,
      institutional_email: instEmail,
      mailbox_status: inst?.mailbox_status || 'not_configured',
      branch: studentData.branch || 'Computer Science & Engineering',
      semester: Number(studentData.semester) || 1,
      section: studentData.section || 'A',
      rfid_id: studentData.rfid_id || `RFID-${Math.floor(10000 + Math.random() * 90000)}`,
    };

    this.data.students.push(newStudent);
    this.addAuditLog(
      studentData.institution_id,
      userId,
      studentData.name,
      'CREATE_STUDENT',
      `Admin enrolled student ${studentData.name} (${studentData.roll_number}) in Section ${newStudent.section}.`
    );

    this.saveDatabase();
    return newStudent;
  }

  public updateStudent(id: string, updates: Partial<Student>, institutionId?: string): Student | null {
    const idx = this.data.students.findIndex((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
    if (idx === -1) return null;

    this.data.students[idx] = { ...this.data.students[idx], ...updates };

    const user = this.data.users.find((u) => u.id === this.data.students[idx].user_id);
    if (user) {
      if (updates.name) user.name = updates.name;
      if (updates.email) user.email = updates.email;
      if (updates.institutional_email) user.institutional_email = updates.institutional_email;
    }

    this.saveDatabase();
    return this.data.students[idx];
  }

  public deleteStudent(id: string, institutionId?: string): boolean {
    const student = this.data.students.find((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
    if (!student) return false;

    this.data.students = this.data.students.filter((s) => s.id !== id);
    this.data.users = this.data.users.filter((u) => u.id !== student.user_id);
    this.data.attendance = this.data.attendance.filter((a) => a.student_id !== id);

    this.addAuditLog(
      student.institution_id,
      student.user_id,
      student.name,
      'DELETE_STUDENT',
      `Admin deleted student ${student.name} (${student.roll_number}).`
    );

    this.saveDatabase();
    return true;
  }

  // ==========================================
  // FACULTY (TENANT ISOLATED)
  // ==========================================
  public getFaculty(institutionId?: string): Faculty[] {
    if (!institutionId) return this.data.faculty;
    return this.data.faculty.filter((f) => f.institution_id === institutionId);
  }

  public getFacultyById(id: string, institutionId?: string): Faculty | undefined {
    return this.data.faculty.find((f) => f.id === id && (!institutionId || f.institution_id === institutionId));
  }

  public getFacultyByUserId(userId: string): Faculty | undefined {
    return this.data.faculty.find((f) => f.user_id === userId);
  }

  public addFaculty(data: {
    institution_id: string;
    employee_id: string;
    name: string;
    email: string;
    institutional_email?: string;
    department?: string;
    assigned_subject_ids?: string[];
    password?: string;
  }): Faculty {
    const id = `fac-${Date.now()}`;
    const userId = `usr-fac-${Date.now()}`;
    const password = data.password || 'password123';

    const inst = this.getInstitutionById(data.institution_id);
    const domain = inst?.domain || 'college.edu';

    let instEmail = data.institutional_email;
    if (!instEmail || instEmail.trim() === '') {
      const cleanName = data.name.trim().toLowerCase().replace(/^prof\.\s*|^dr\.\s*/i, '').replace(/\s+/g, '.').replace(/[^a-z0-9.]/g, '');
      instEmail = `${cleanName}@${domain}`;
    }

    const newUser: User = {
      id: userId,
      institution_id: data.institution_id,
      name: data.name,
      email: data.email,
      institutional_email: instEmail,
      password_hash: hashPassword(password),
      role: 'faculty',
      status: 'active',
      created_at: new Date().toISOString(),
    };
    this.data.users.push(newUser);

    const newFaculty: Faculty = {
      id,
      institution_id: data.institution_id,
      user_id: userId,
      employee_id: data.employee_id,
      name: data.name,
      email: data.email,
      institutional_email: instEmail,
      mailbox_status: inst?.mailbox_status || 'not_configured',
      department: data.department || 'Computer Science & Engineering',
      assigned_subject_ids: data.assigned_subject_ids || [],
    };

    this.data.faculty.push(newFaculty);
    this.addAuditLog(data.institution_id, userId, data.name, 'CREATE_FACULTY', `Enrolled faculty ${data.name} (${data.employee_id}).`);

    this.saveDatabase();
    return newFaculty;
  }

  public updateFaculty(id: string, updates: Partial<Faculty>, institutionId?: string): Faculty | null {
    const idx = this.data.faculty.findIndex((f) => f.id === id && (!institutionId || f.institution_id === institutionId));
    if (idx === -1) return null;

    this.data.faculty[idx] = { ...this.data.faculty[idx], ...updates };

    const user = this.data.users.find((u) => u.id === this.data.faculty[idx].user_id);
    if (user) {
      if (updates.name) user.name = updates.name;
      if (updates.email) user.email = updates.email;
      if (updates.institutional_email) user.institutional_email = updates.institutional_email;
    }

    this.saveDatabase();
    return this.data.faculty[idx];
  }

  public deleteFaculty(id: string, institutionId?: string): boolean {
    const fac = this.data.faculty.find((f) => f.id === id && (!institutionId || f.institution_id === institutionId));
    if (!fac) return false;

    this.data.faculty = this.data.faculty.filter((f) => f.id !== id);
    this.data.users = this.data.users.filter((u) => u.id !== fac.user_id);

    this.saveDatabase();
    return true;
  }

  // ==========================================
  // SUBJECTS & SECTIONS (TENANT ISOLATED)
  // ==========================================
  public getSubjects(institutionId?: string): Subject[] {
    if (!institutionId) return this.data.subjects;
    return this.data.subjects.filter((s) => s.institution_id === institutionId);
  }

  public getSubjectById(id: string, institutionId?: string): Subject | undefined {
    return this.data.subjects.find((s) => (s.id === id || s.subject_code === id) && (!institutionId || s.institution_id === institutionId));
  }

  public addSubject(data: Omit<Subject, 'id'>): Subject {
    const id = `sub-${data.subject_code.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now().toString(36)}`;
    const fac = this.data.faculty.find((f) => f.id === data.faculty_id);
    const newSubject: Subject = {
      id,
      ...data,
      faculty_name: fac?.name || 'Unassigned',
    };
    this.data.subjects.push(newSubject);

    if (fac && !fac.assigned_subject_ids.includes(id)) {
      fac.assigned_subject_ids.push(id);
    }

    this.saveDatabase();
    return newSubject;
  }

  public updateSubject(id: string, updates: Partial<Subject>, institutionId?: string): Subject | null {
    const idx = this.data.subjects.findIndex((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
    if (idx === -1) return null;

    if (updates.faculty_id) {
      const fac = this.data.faculty.find((f) => f.id === updates.faculty_id);
      if (fac) updates.faculty_name = fac.name;
    }

    this.data.subjects[idx] = { ...this.data.subjects[idx], ...updates };
    this.saveDatabase();
    return this.data.subjects[idx];
  }

  public deleteSubject(id: string, institutionId?: string): boolean {
    const subj = this.data.subjects.find((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
    if (!subj) return false;

    this.data.subjects = this.data.subjects.filter((s) => s.id !== id);
    this.data.attendance = this.data.attendance.filter((a) => a.subject_id !== id);
    this.data.sessions = this.data.sessions.filter((s) => s.subject_id !== id);

    this.saveDatabase();
    return true;
  }

  public getClasses(institutionId?: string): ClassSection[] {
    if (!institutionId) return this.data.classes;
    return this.data.classes.filter((c) => c.institution_id === institutionId);
  }

  public addClass(data: Omit<ClassSection, 'id'>): ClassSection {
    const id = `cls-${Date.now()}`;
    const newClass = { id, ...data };
    this.data.classes.push(newClass);
    this.saveDatabase();
    return newClass;
  }

  // ==========================================
  // SESSIONS & ATTENDANCE (TENANT ISOLATED)
  // ==========================================
  public getSessions(institutionId?: string): AttendanceSession[] {
    if (!institutionId) return this.data.sessions;
    return this.data.sessions.filter((s) => s.institution_id === institutionId);
  }

  public getSessionById(id: string, institutionId?: string): AttendanceSession | undefined {
    return this.data.sessions.find((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
  }

  public getSessionByQrToken(qrToken: string): AttendanceSession | undefined {
    return this.data.sessions.find((s) => s.qr_token === qrToken.trim());
  }

  public createSession(
    institutionId: string,
    subjectId: string,
    facultyId: string,
    section: string,
    lectureTopic: string,
    durationMinutes: number = 15
  ): AttendanceSession {
    const id = `sess-${Date.now()}`;
    const subject = this.data.subjects.find((s) => s.id === subjectId && s.institution_id === institutionId);
    const faculty = this.data.faculty.find((f) => f.id === facultyId && f.institution_id === institutionId);

    const now = new Date();
    const expiresAt = new Date(now.getTime() + durationMinutes * 60 * 1000);
    const qrToken = `ATT-${id}-${subject?.subject_code || 'SUB'}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

    const newSession: AttendanceSession = {
      id,
      institution_id: institutionId,
      subject_id: subjectId,
      subject_name: subject?.subject_name || 'Class Lecture',
      subject_code: subject?.subject_code || 'SUB001',
      faculty_id: facultyId,
      faculty_name: faculty?.name || 'Faculty Member',
      section,
      lecture_topic: lectureTopic || 'Class Lecture',
      date: now.toISOString().split('T')[0],
      time: now.toTimeString().substring(0, 5),
      duration_minutes: durationMinutes,
      qr_token: qrToken,
      created_at: now.toISOString(),
      expires_at: expiresAt.toISOString(),
      status: 'active',
    };

    this.data.sessions.unshift(newSession);

    this.data.notifications.unshift({
      id: `notif-${Date.now()}`,
      institution_id: institutionId,
      user_id: 'all',
      title: `Live Session: ${subject?.subject_code}`,
      message: `${faculty?.name} opened attendance session for Section ${section}.`,
      type: 'info',
      is_read: false,
      created_at: now.toISOString(),
    });

    this.saveDatabase();
    return newSession;
  }

  public closeSession(id: string, institutionId?: string): AttendanceSession | null {
    const session = this.data.sessions.find((s) => s.id === id && (!institutionId || s.institution_id === institutionId));
    if (!session) return null;
    session.status = 'closed';
    this.saveDatabase();
    return session;
  }

  public getAttendanceRecords(institutionId?: string): AttendanceRecord[] {
    if (!institutionId) return this.data.attendance;
    return this.data.attendance.filter((a) => a.institution_id === institutionId);
  }

  public markAttendance(
    institutionId: string,
    studentId: string,
    sessionId: string,
    status: 'present' | 'absent',
    markedBy: string,
    method: 'qr' | 'manual' | 'rfid' = 'manual',
    remarks?: string,
    location?: { latitude: number; longitude: number; accuracy?: number }
  ): {
    success: boolean;
    record?: AttendanceRecord;
    message: string;
    duplicate?: boolean;
    geofenceBreach?: boolean;
    distance?: number;
  } {
    const session = this.data.sessions.find((s) => s.id === sessionId && s.institution_id === institutionId);
    if (!session) {
      return { success: false, message: 'Invalid or non-existent attendance session for this institution' };
    }

    const student = this.data.students.find((s) => s.id === studentId && s.institution_id === institutionId);
    if (!student) {
      return { success: false, message: 'Student record not found in this institution' };
    }

    // Verify section
    if (student.section !== session.section) {
      return {
        success: false,
        message: `Section Mismatch: Student is enrolled in Section ${student.section}, but this lecture session is strictly for Section ${session.section}.`,
      };
    }

    // Check expiration if QR
    if (method === 'qr') {
      const now = new Date();
      const expires = new Date(session.expires_at);
      if (session.status === 'closed' || now > expires) {
        return { success: false, message: 'Session Expired: Attendance QR code has timed out or session was closed by the instructor.' };
      }
    }

    // ==========================================
    // CAMPUS GEOFENCING & GPS LOCATION VERIFICATION
    // ==========================================
    const geofence = this.data.settings.geofence || {
      enabled: true,
      campus_name: 'NIET Greater Noida Campus',
      latitude: 28.4632,
      longitude: 77.4939,
      radius_meters: 500,
    };

    let geoLog: GeoLocationLog | undefined;

    if (geofence.enabled && (method === 'qr' || location)) {
      if (!location || typeof location.latitude !== 'number' || typeof location.longitude !== 'number') {
        return {
          success: false,
          message: `GPS Verification Required: Physical attendance inside ${geofence.campus_name} is enforced (${geofence.radius_meters}m boundary). Please enable location access or select campus coordinates.`,
        };
      }

      const distance = calculateHaversineDistanceMeters(
        location.latitude,
        location.longitude,
        geofence.latitude,
        geofence.longitude
      );

      const isWithinGeofence = distance <= geofence.radius_meters;

      if (!isWithinGeofence) {
        this.addAuditLog(
          institutionId,
          student.user_id,
          student.name,
          'GEOFENCE_BREACH_REJECTED',
          `Attendance rejected for ${student.name} (${student.roll_number}): Location is ${distance}m away from ${geofence.campus_name} (Allowed radius: ${geofence.radius_meters}m). Coordinates: [${location.latitude}, ${location.longitude}].`
        );

        return {
          success: false,
          geofenceBreach: true,
          distance,
          message: `Campus Geofence Breach: You are ${distance}m away from ${geofence.campus_name} (${geofence.radius_meters}m permitted perimeter). Attendance must be recorded inside university grounds.`,
        };
      }

      geoLog = {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
        distance_meters: distance,
        is_within_geofence: true,
        verified_at: new Date().toISOString(),
      };
    }

    // ==========================================
    // DUPLICATE ATTENDANCE DETECTION
    // ==========================================
    const existing = this.data.attendance.find((a) => a.student_id === studentId && a.session_id === sessionId);
    if (existing) {
      if (existing.status === 'present') {
        this.addAuditLog(
          institutionId,
          student.user_id,
          student.name,
          'DUPLICATE_ATTENDANCE_BLOCKED',
          `Duplicate scan blocked for ${student.name} (${student.roll_number}) in session ${session.subject_code} (Already marked present at ${existing.time} via ${existing.method.toUpperCase()}).`
        );

        return {
          success: false,
          duplicate: true,
          message: `Duplicate Attendance Detected: Student was already verified as Present at ${existing.time} via ${existing.method.toUpperCase()}. Double check-in prohibited.`,
        };
      } else {
        existing.status = status;
        existing.time = new Date().toTimeString().substring(0, 5);
        existing.method = method;
        existing.marked_by = markedBy;
        existing.remarks = remarks;
        if (geoLog) existing.location = geoLog;
        this.saveDatabase();
        return { success: true, record: existing, message: 'Attendance updated successfully' };
      }
    }

    const now = new Date();
    const record: AttendanceRecord = {
      id: `rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      institution_id: institutionId,
      student_id: studentId,
      student_name: student.name,
      roll_number: student.roll_number,
      subject_id: session.subject_id,
      subject_code: session.subject_code,
      subject_name: session.subject_name,
      session_id: sessionId,
      date: session.date,
      time: now.toTimeString().substring(0, 5),
      status,
      marked_by: markedBy,
      method,
      remarks,
      location: geoLog,
    };

    this.data.attendance.push(record);

    this.addAuditLog(
      institutionId,
      student.user_id,
      student.name,
      'ATTENDANCE_RECORDED',
      `Student ${student.name} (${student.roll_number}) marked ${status} in ${session.subject_code} via ${method.toUpperCase()}${geoLog ? ` (GPS Verified: ${geoLog.distance_meters}m from center)` : ''}.`
    );

    this.saveDatabase();
    return {
      success: true,
      record,
      message: `Attendance verified as ${status} at ${record.time}${geoLog ? ` · GPS Geofence: ${geoLog.distance_meters}m` : ''}`,
    };
  }

  public saveBulkAttendance(
    institutionId: string,
    sessionId: string,
    facultyId: string,
    recordsToSave: Array<{ studentId: string; status: 'present' | 'absent'; remarks?: string }>
  ): { count: number; undoStackId: string } {
    const session = this.data.sessions.find((s) => s.id === sessionId && s.institution_id === institutionId);
    if (!session) throw new Error('Session not found in this institution');

    const previousRecords = this.data.attendance.filter((a) => a.session_id === sessionId);
    const stackSnapshot: AttendanceRecord[] = JSON.parse(JSON.stringify(previousRecords));

    this.data.attendance = this.data.attendance.filter((a) => a.session_id !== sessionId);

    const now = new Date();
    const timeStr = now.toTimeString().substring(0, 5);
    const newRecords: AttendanceRecord[] = [];

    recordsToSave.forEach((item) => {
      const student = this.data.students.find((s) => s.id === item.studentId && s.institution_id === institutionId);
      if (student) {
        newRecords.push({
          id: `rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          institution_id: institutionId,
          student_id: student.id,
          student_name: student.name,
          roll_number: student.roll_number,
          subject_id: session.subject_id,
          subject_code: session.subject_code,
          subject_name: session.subject_name,
          session_id: sessionId,
          date: session.date,
          time: timeStr,
          status: item.status,
          marked_by: facultyId,
          method: 'manual',
          remarks: item.remarks,
        });
      }
    });

    this.data.attendance.push(...newRecords);

    const undoId = `stack-${Date.now()}`;
    const stackItem: UndoStackItem = {
      id: undoId,
      institution_id: institutionId,
      timestamp: new Date().toISOString(),
      session_id: sessionId,
      faculty_id: facultyId,
      records: stackSnapshot,
      description: `Saved attendance for ${session.subject_code} (${recordsToSave.length} students)`,
    };
    this.data.undoStack.push(stackItem);

    this.saveDatabase();
    return { count: newRecords.length, undoStackId: undoId };
  }

  public undoLatestAttendance(institutionId: string, facultyId: string, sessionId?: string): { success: boolean; message: string } {
    let targetIdx = -1;
    for (let i = this.data.undoStack.length - 1; i >= 0; i--) {
      const item = this.data.undoStack[i];
      if (item.institution_id === institutionId && item.faculty_id === facultyId) {
        if (!sessionId || item.session_id === sessionId) {
          targetIdx = i;
          break;
        }
      }
    }

    if (targetIdx === -1) {
      return { success: false, message: 'No undo stack frame found to revert.' };
    }

    const [stackItem] = this.data.undoStack.splice(targetIdx, 1);
    this.data.attendance = this.data.attendance.filter((a) => a.session_id !== stackItem.session_id);
    this.data.attendance.push(...stackItem.records);

    this.saveDatabase();
    return {
      success: true,
      message: `Reverted attendance entry from ${new Date(stackItem.timestamp).toLocaleTimeString()}`,
    };
  }

  // ==========================================
  // ATTENDANCE CALCULATION ENGINE
  // ==========================================
  public calculateStudentAttendance(studentId: string, institutionId?: string): StudentAttendanceProfile | null {
    const student = this.data.students.find((s) => s.id === studentId && (!institutionId || s.institution_id === institutionId));
    if (!student) return null;

    const instId = student.institution_id;
    const threshold = this.data.settings.eligibility_threshold;
    const studentRecords = this.data.attendance.filter((a) => a.student_id === studentId && a.institution_id === instId);

    const instSubjects = this.data.subjects.filter((s) => s.institution_id === instId);

    const subjectSummaries: SubjectAttendanceSummary[] = instSubjects.map((subj) => {
      const allSubjectSessions = this.data.sessions.filter(
        (sess) => sess.subject_id === subj.id && sess.section === student.section && sess.institution_id === instId
      );
      const totalClasses = allSubjectSessions.length;
      const recordsForSubj = studentRecords.filter((r) => r.subject_id === subj.id);
      const attendedClasses = recordsForSubj.filter((r) => r.status === 'present').length;
      const absentClasses = totalClasses > attendedClasses ? totalClasses - attendedClasses : 0;
      const percentage = totalClasses > 0 ? Number(((attendedClasses / totalClasses) * 100).toFixed(1)) : 100;
      const isEligible = percentage >= threshold;

      return {
        subject_id: subj.id,
        subject_code: subj.subject_code,
        subject_name: subj.subject_name,
        faculty_name: subj.faculty_name || 'Faculty Member',
        total_classes: totalClasses,
        attended_classes: attendedClasses,
        absent_classes: absentClasses,
        attendance_percentage: percentage,
        is_eligible: isEligible,
      };
    });

    const totalClasses = subjectSummaries.reduce((sum, s) => sum + s.total_classes, 0);
    const attendedClasses = subjectSummaries.reduce((sum, s) => sum + s.attended_classes, 0);
    const absentClasses = totalClasses > attendedClasses ? totalClasses - attendedClasses : 0;
    const overallPercentage = totalClasses > 0 ? Number(((attendedClasses / totalClasses) * 100).toFixed(1)) : 100;
    const isOverallEligible = overallPercentage >= threshold;

    return {
      student,
      overall_percentage: overallPercentage,
      total_classes: totalClasses,
      attended_classes: attendedClasses,
      absent_classes: absentClasses,
      is_eligible: isOverallEligible,
      subjects: subjectSummaries,
    };
  }

  public getDefaulters(institutionId: string, threshold?: number): Array<StudentAttendanceProfile & { defaulterSubjects: SubjectAttendanceSummary[] }> {
    const cutoff = threshold ?? this.data.settings.eligibility_threshold;
    const defaulters: Array<StudentAttendanceProfile & { defaulterSubjects: SubjectAttendanceSummary[] }> = [];

    const instStudents = this.getStudents(institutionId);
    instStudents.forEach((student) => {
      const profile = this.calculateStudentAttendance(student.id, institutionId);
      if (profile && profile.total_classes > 0) {
        const defaulterSubjects = profile.subjects.filter((s) => s.attendance_percentage < cutoff && s.total_classes > 0);
        if (profile.overall_percentage < cutoff || defaulterSubjects.length > 0) {
          defaulters.push({
            ...profile,
            defaulterSubjects,
          });
        }
      }
    });

    return defaulters.sort((a, b) => a.overall_percentage - b.overall_percentage);
  }

  public getOverallStatistics(institutionId: string) {
    const students = this.getStudents(institutionId);
    const faculty = this.getFaculty(institutionId);
    const subjects = this.getSubjects(institutionId);
    const sessions = this.getSessions(institutionId);

    const todayStr = new Date().toISOString().split('T')[0];
    const todaySessions = sessions.filter((s) => s.date === todayStr);
    const todayRecords = this.data.attendance.filter((a) => a.institution_id === institutionId && a.date === todayStr);

    let totalAttendedSum = 0;
    let totalClassesSum = 0;

    const studentProfiles = students
      .map((st) => this.calculateStudentAttendance(st.id, institutionId))
      .filter(Boolean) as StudentAttendanceProfile[];

    studentProfiles.forEach((p) => {
      totalAttendedSum += p.attended_classes;
      totalClassesSum += p.total_classes;
    });

    const averageAttendance = totalClassesSum > 0 ? Number(((totalAttendedSum / totalClassesSum) * 100).toFixed(1)) : 0;
    const defaultersCount = studentProfiles.filter((p) => p.total_classes > 0 && p.overall_percentage < this.data.settings.eligibility_threshold).length;

    return {
      totalStudents: students.length,
      totalFaculty: faculty.length,
      totalSubjects: subjects.length,
      totalSessions: sessions.length,
      todaySessionsCount: todaySessions.length,
      todayAttendanceCount: todayRecords.length,
      averageAttendance,
      defaultersCount,
      eligibilityThreshold: this.data.settings.eligibility_threshold,
    };
  }

  // ==========================================
  // AUDIT LOGS & SETTINGS
  // ==========================================
  public addAuditLog(institutionId: string, userId: string, userName: string, action: string, details: string) {
    const log: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      institution_id: institutionId,
      user_id: userId,
      user_name: userName,
      action,
      details,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
  }

  public getAuditLogs(institutionId: string): AuditLog[] {
    return this.data.auditLogs.filter((l) => l.institution_id === institutionId);
  }

  public getSettings(institutionId?: string): SystemSettings {
    const inst = institutionId ? this.getInstitutionById(institutionId) : undefined;
    return {
      ...this.data.settings,
      institution_id: institutionId,
      institute_name: inst?.name || this.data.settings.institute_name,
    };
  }

  public updateSettings(institutionId: string, updates: Partial<SystemSettings>): SystemSettings {
    this.data.settings = { ...this.data.settings, ...updates, institution_id: institutionId };
    this.saveDatabase();
    return this.data.settings;
  }

  public getNotifications(institutionId?: string, userId?: string, role?: string): SystemNotification[] {
    return this.data.notifications.filter(
      (n) =>
        (!institutionId || n.institution_id === institutionId) &&
        (n.user_id === 'all' || (userId && n.user_id === userId) || (role && n.role === role))
    );
  }

  public markNotificationRead(id: string): boolean {
    const notif = this.data.notifications.find((n) => n.id === id);
    if (!notif) return false;
    notif.is_read = true;
    this.saveDatabase();
    return true;
  }

  // ==========================================
  // ATTENDANCE CORRECTION & DISPUTE REQUESTS
  // ==========================================
  public getAttendanceRequests(institutionId?: string): AttendanceCorrectionRequest[] {
    if (!this.data.attendance_requests) this.data.attendance_requests = [];
    if (!institutionId) return this.data.attendance_requests;
    return this.data.attendance_requests.filter((r) => r.institution_id === institutionId);
  }

  public getAttendanceRequestsByStudent(studentId: string, institutionId?: string): AttendanceCorrectionRequest[] {
    return this.getAttendanceRequests(institutionId).filter((r) => r.student_id === studentId);
  }

  public getAttendanceRequestsByFaculty(facultyId: string, institutionId?: string): AttendanceCorrectionRequest[] {
    const faculty = this.getFacultyById(facultyId, institutionId);
    const assignedSubjIds = faculty ? faculty.assigned_subject_ids || [] : [];
    return this.getAttendanceRequests(institutionId).filter(
      (r) => r.faculty_id === facultyId || assignedSubjIds.includes(r.subject_id)
    );
  }

  public getAttendanceRequestById(id: string, institutionId?: string): AttendanceCorrectionRequest | undefined {
    return this.getAttendanceRequests(institutionId).find((r) => r.id === id);
  }

  public createAttendanceRequest(data: {
    institution_id: string;
    student_id: string;
    subject_id: string;
    session_id?: string;
    date: string;
    category: AttendanceDisputeCategory;
    reason: string;
    proof_note?: string;
  }): AttendanceCorrectionRequest {
    if (!this.data.attendance_requests) this.data.attendance_requests = [];

    const student = this.getStudentById(data.student_id, data.institution_id);
    if (!student) throw new Error('Student profile not found');

    const subject =
      this.getSubjectById(data.subject_id, data.institution_id) ||
      this.getSubjects(data.institution_id).find(
        (s) => s.id === data.subject_id || s.subject_code.toLowerCase() === data.subject_id.toLowerCase()
      );
    if (!subject) throw new Error('Subject not found');

    let facultyId = subject.faculty_id;
    let facultyName = subject.faculty_name;
    let sessionTopic = '';

    if (data.session_id) {
      const session = this.getSessionById(data.session_id, data.institution_id);
      if (session) {
        facultyId = session.faculty_id || facultyId;
        facultyName = session.faculty_name || facultyName;
        sessionTopic = session.lecture_topic;
      }
    }

    if (!facultyName && facultyId) {
      const fac = this.getFacultyById(facultyId, data.institution_id);
      if (fac) facultyName = fac.name;
    }

    const id = `dispute-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newRequest: AttendanceCorrectionRequest = {
      id,
      institution_id: data.institution_id,
      student_id: student.id,
      student_name: student.name,
      roll_number: student.roll_number,
      section: student.section,
      faculty_id: facultyId || '',
      faculty_name: facultyName || 'Course Instructor',
      subject_id: subject.id,
      subject_code: subject.subject_code,
      subject_name: subject.subject_name,
      session_id: data.session_id,
      session_topic: sessionTopic,
      date: data.date,
      category: data.category,
      reason: data.reason,
      proof_note: data.proof_note,
      status: 'pending_faculty',
      created_at: new Date().toISOString(),
    };

    this.data.attendance_requests.unshift(newRequest);

    this.data.notifications.unshift({
      id: `notif-${Date.now()}`,
      institution_id: data.institution_id,
      user_id: facultyId || 'all',
      role: 'faculty',
      title: 'Attendance Correction Submitted',
      message: `${student.name} (${student.roll_number}, Sec ${student.section}) submitted an attendance review request for ${subject.subject_code} on ${data.date}.`,
      type: 'info',
      is_read: false,
      created_at: new Date().toISOString(),
    });

    this.addAuditLog(
      data.institution_id,
      student.user_id,
      student.name,
      'ATTENDANCE_DISPUTE_SUBMITTED',
      `Student ${student.name} submitted correction request for ${subject.subject_code} on ${data.date}: "${data.reason.substring(0, 60)}..."`
    );

    this.saveDatabase();
    return newRequest;
  }

  // ==========================================
  // MULTI-TIER ATTENDANCE CORRECTION WORKFLOW
  // 1. Faculty Verification (signs off without altering records)
  // 2. Admin Final Approval (updates attendance records to Present)
  // ==========================================

  public facultyVerifyAttendanceRequest(
    id: string,
    facultyRemarks: string,
    resolvedByFacultyId: string,
    institutionId?: string
  ): { success: boolean; request?: AttendanceCorrectionRequest; message: string } {
    if (!this.data.attendance_requests) this.data.attendance_requests = [];

    const request = this.data.attendance_requests.find(
      (r) => r.id === id && (!institutionId || r.institution_id === institutionId)
    );
    if (!request) {
      return { success: false, message: 'Attendance dispute request not found' };
    }

    const faculty =
      this.getFacultyById(resolvedByFacultyId, request.institution_id) ||
      this.data.faculty.find((f) => f.user_id === resolvedByFacultyId && (!institutionId || f.institution_id === institutionId)) ||
      this.getFaculty(request.institution_id)[0];
    const facultyDisplayName = faculty ? faculty.name : 'Course Faculty';

    // Tier 1: Faculty Verification (does NOT alter attendance records)
    request.status = 'faculty_verified';
    request.faculty_remarks = facultyRemarks || 'Faculty verified attendance legitimacy.';
    request.faculty_verified_by = facultyDisplayName;
    request.faculty_verified_at = new Date().toISOString();

    // Notify Student
    const student = this.getStudentById(request.student_id, request.institution_id);
    if (student) {
      this.data.notifications.unshift({
        id: `notif-${Date.now()}`,
        institution_id: request.institution_id,
        user_id: student.user_id,
        role: 'student',
        title: 'Correction Verified by Faculty',
        message: `Your attendance request for ${request.subject_code} on ${request.date} was verified by ${facultyDisplayName} and forwarded to Academic Administration for final approval.`,
        type: 'info',
        is_read: false,
        created_at: new Date().toISOString(),
      });
    }

    // Notify Admin Queue
    this.data.notifications.unshift({
      id: `notif-${Date.now()}-admin`,
      institution_id: request.institution_id,
      user_id: 'all',
      role: 'admin',
      title: 'Dispute Awaiting Final Approval',
      message: `Faculty ${facultyDisplayName} verified attendance request for ${request.student_name} (${request.roll_number}, ${request.subject_code}). Awaiting final authorization.`,
      type: 'info',
      is_read: false,
      created_at: new Date().toISOString(),
    });

    this.addAuditLog(
      request.institution_id,
      resolvedByFacultyId,
      facultyDisplayName,
      'ATTENDANCE_DISPUTE_FACULTY_VERIFIED',
      `Faculty ${facultyDisplayName} verified correction for ${request.student_name} (${request.subject_code}, ${request.date}). Remarks: "${facultyRemarks}". Submitted for Admin final approval.`
    );

    this.saveDatabase();
    return {
      success: true,
      request,
      message: 'Request verified by faculty and forwarded to Academic Administration for final approval.',
    };
  }

  public adminApproveAttendanceRequest(
    id: string,
    adminRemarks: string,
    adminUserId: string,
    institutionId?: string
  ): { success: boolean; request?: AttendanceCorrectionRequest; message: string } {
    if (!this.data.attendance_requests) this.data.attendance_requests = [];

    const request = this.data.attendance_requests.find(
      (r) => r.id === id && (!institutionId || r.institution_id === institutionId)
    );
    if (!request) {
      return { success: false, message: 'Attendance dispute request not found' };
    }

    const adminUser = this.getUserById(adminUserId) || this.data.users.find((u) => u.role === 'admin');
    const adminDisplayName = adminUser ? adminUser.name : 'Academic Administrator';

    // Tier 2: Admin Final Approval
    request.status = 'approved';
    request.admin_remarks = adminRemarks || 'Approved by Academic Administration';
    request.admin_approved_by = adminDisplayName;
    request.admin_approved_at = new Date().toISOString();
    request.resolved_at = new Date().toISOString();

    // CRITICAL REQUIREMENT: Update attendance records ONLY after successful admin final approval!
    let matchedRecord = this.data.attendance.find((a) => {
      if (a.institution_id !== request.institution_id || a.student_id !== request.student_id) return false;
      if (request.session_id && a.session_id === request.session_id) return true;
      if (a.subject_id === request.subject_id && a.date === request.date) return true;
      return false;
    });

    if (matchedRecord) {
      matchedRecord.status = 'present';
      matchedRecord.method = 'manual';
      matchedRecord.remarks = adminRemarks
        ? `Authorized by Admin (${adminDisplayName}): ${adminRemarks}`
        : `Authorized by Admin (${adminDisplayName})`;
    } else {
      const now = new Date();
      const newRecord: AttendanceRecord = {
        id: `rec-dispute-${Date.now()}`,
        institution_id: request.institution_id,
        student_id: request.student_id,
        student_name: request.student_name,
        roll_number: request.roll_number,
        subject_id: request.subject_id,
        subject_code: request.subject_code,
        subject_name: request.subject_name,
        session_id: request.session_id || `sess-adhoc-${Date.now()}`,
        date: request.date,
        time: now.toTimeString().substring(0, 5),
        status: 'present',
        marked_by: adminUserId || 'admin',
        method: 'manual',
        remarks: adminRemarks
          ? `Authorized by Admin (${adminDisplayName}): ${adminRemarks}`
          : `Authorized by Admin (${adminDisplayName})`,
      };
      this.data.attendance.push(newRecord);
    }

    // Notify Student
    const student = this.getStudentById(request.student_id, request.institution_id);
    if (student) {
      this.data.notifications.unshift({
        id: `notif-${Date.now()}`,
        institution_id: request.institution_id,
        user_id: student.user_id,
        role: 'student',
        title: 'Attendance Final Approval Granted',
        message: `Academic Administration has granted final approval for ${request.subject_code} on ${request.date}. Official record updated to Present!`,
        type: 'success',
        is_read: false,
        created_at: new Date().toISOString(),
      });
    }

    this.addAuditLog(
      request.institution_id,
      adminUserId,
      adminDisplayName,
      'ATTENDANCE_DISPUTE_ADMIN_APPROVED',
      `Admin ${adminDisplayName} granted final approval for ${request.student_name} (${request.subject_code}, ${request.date}). Central registry updated to Present. Remarks: "${adminRemarks}".`
    );

    this.saveDatabase();
    return {
      success: true,
      request,
      message: 'Dispute approved by Administrator. Central attendance records updated to Present.',
    };
  }

  public rejectAttendanceRequest(
    id: string,
    remarks: string,
    rejectedByUserId: string,
    rejectedByRole: string,
    institutionId?: string
  ): { success: boolean; request?: AttendanceCorrectionRequest; message: string } {
    if (!this.data.attendance_requests) this.data.attendance_requests = [];

    const request = this.data.attendance_requests.find(
      (r) => r.id === id && (!institutionId || r.institution_id === institutionId)
    );
    if (!request) {
      return { success: false, message: 'Attendance dispute request not found' };
    }

    let rejecterName = 'Authorized Reviewer';
    if (rejectedByRole === 'faculty') {
      const fac =
        this.getFacultyById(rejectedByUserId, request.institution_id) ||
        this.data.faculty.find((f) => f.user_id === rejectedByUserId);
      if (fac) rejecterName = fac.name;
      request.faculty_remarks = remarks || 'Declined during faculty verification.';
      request.faculty_verified_by = rejecterName;
    } else {
      const user = this.getUserById(rejectedByUserId);
      if (user) rejecterName = user.name;
      request.admin_remarks = remarks || 'Declined during administrative review.';
      request.admin_approved_by = rejecterName;
    }

    request.status = 'rejected';
    request.resolved_at = new Date().toISOString();

    const student = this.getStudentById(request.student_id, request.institution_id);
    if (student) {
      this.data.notifications.unshift({
        id: `notif-${Date.now()}`,
        institution_id: request.institution_id,
        user_id: student.user_id,
        role: 'student',
        title: 'Attendance Request Declined',
        message: `Your attendance request for ${request.subject_code} on ${request.date} was declined by ${rejecterName}: ${remarks || 'Criteria not met'}.`,
        type: 'warning',
        is_read: false,
        created_at: new Date().toISOString(),
      });
    }

    this.addAuditLog(
      request.institution_id,
      rejectedByUserId,
      rejecterName,
      'ATTENDANCE_DISPUTE_REJECTED',
      `${rejectedByRole.toUpperCase()} (${rejecterName}) declined attendance dispute for ${request.student_name} (${request.subject_code}, ${request.date}). Reason: "${remarks}".`
    );

    this.saveDatabase();
    return {
      success: true,
      request,
      message: 'Attendance dispute request has been rejected.',
    };
  }

  public updateAttendanceRequestStatus(
    id: string,
    status: 'approved' | 'rejected' | 'faculty_verified' | string,
    remarks: string,
    resolvedByUserId: string,
    institutionId?: string,
    userRole: string = 'faculty'
  ): { success: boolean; request?: AttendanceCorrectionRequest; message: string } {
    if (status === 'reject' || status === 'rejected') {
      return this.rejectAttendanceRequest(id, remarks, resolvedByUserId, userRole, institutionId);
    }
    if (status === 'faculty_verified' || userRole === 'faculty') {
      return this.facultyVerifyAttendanceRequest(id, remarks, resolvedByUserId, institutionId);
    }
    return this.adminApproveAttendanceRequest(id, remarks, resolvedByUserId, institutionId);
  }

  // ==========================================
  // CAMPUS GEOFENCING CONFIGURATION
  // ==========================================
  public getGeofenceConfig(institutionId?: string): GeofenceConfig {
    if (!this.data.settings.geofence) {
      this.data.settings.geofence = {
        enabled: true,
        campus_name: 'NIET Greater Noida Campus',
        latitude: 28.4632,
        longitude: 77.4939,
        radius_meters: 500,
      };
      this.saveDatabase();
    }
    return this.data.settings.geofence;
  }

  public updateGeofenceConfig(
    institutionId: string,
    updates: Partial<GeofenceConfig>,
    updatedByUserId: string = 'admin'
  ): GeofenceConfig {
    const current = this.getGeofenceConfig(institutionId);
    const updated: GeofenceConfig = {
      ...current,
      ...updates,
    };
    this.data.settings.geofence = updated;

    const user = this.getUserById(updatedByUserId);
    this.addAuditLog(
      institutionId,
      updatedByUserId,
      user?.name || 'Administrator',
      'GEOFENCE_CONFIG_UPDATED',
      `Updated Campus Geofence for ${updated.campus_name}: Lat ${updated.latitude}, Lon ${updated.longitude}, Radius ${updated.radius_meters}m, Active: ${updated.enabled}`
    );

    this.saveDatabase();
    return updated;
  }
}

export const db = new Database();
