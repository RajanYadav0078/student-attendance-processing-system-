# Student Attendance Processing System
**College PBL Project · Computer Architecture & Parallel Processing (CCSE0304)**  
**Program:** B.Tech Computer Science & Engineering, Semester 3  

---

## 1. Project Overview & Purpose
The **Student Attendance Processing System** is a full-stack digital attendance management and analytics platform engineered for university institutions. It replaces error-prone physical sign-in sheets with:

- **Dynamic QR Code Sessions**: Time-limited cryptographic tokens scanned by students using device cameras.
- **Hardware-Ready RFID Bus**: Contactless card UID resolution (e.g., `RFID-00123`) simulating UART/Serial and Wiegand-26 pulse decoding.
- **Automated ALU Calculation Engine**: Real-time floating-point attendance percentages:
  $$\text{Attendance \%} = \left(\frac{\text{Classes Attended}}{\text{Total Classes}}\right) \times 100$$
- **Regulatory 75% Ordinance Engine**: Automated detection and classification of students into *Eligible* ($\ge 75\%$) or *Attendance Shortage / Defaulter* ($< 75\%$).
- **CPU Stack Undo Frame**: LIFO rollback stack that empowers faculty members to immediately undo accidental or erroneous attendance markings.

---

## 2. Computer Architecture & Hardware Mapping (CCSE0304)

This project models fundamental von Neumann computer architecture components:

| Hardware Subsystem | System Implementation Module | Course Concept (CCSE0304) | Functional Behavior |
| :--- | :--- | :--- | :--- |
| **Input Unit** | Optical QR camera decoder & RFID Bus simulator | I/O Interfacing & Peripheral Bus | Captures raw photon 2D tokens or 125kHz RFID card serial packets. |
| **Memory Unit** | Relational Database Store (`database/data.json`) | Primary Memory & Hierarchy | Stores Student Master Matrices, Session Descriptors, and Attendance Logs. |
| **Arithmetic Logic Unit (ALU)**| Attendance Calculation Engine | ALU Arithmetic & Logic Operations | Computes attendance percentages and executes boolean threshold comparison. |
| **Control Unit** | Sequencer & JWT Validator | Microprogrammed FSM Controller | Enforces session timeouts, checks user roles, and rejects duplicate marks. |
| **Addressing Bus** | Student Roll Number & RFID UID Decoder | Direct & Indexed Addressing | Direct address pointers (e.g., `23BCSE101`) to locate specific memory rows. |
| **Registers** | Active Session & Token Buffers | Temporary Memory Buffers | Holds active clock cycle data while an attendance session is underway. |
| **Stack Pointer / STACK** | LIFO Undo Snapshot Frame | Hardware Stack (SP) | Pushes attendance snapshots prior to writes; faculty POP reverts mutations. |
| **Parallel Processing** | Asynchronous Non-blocking Event Pipeline | SIMD & Multicore Parallelism | Handles concurrent QR check-in requests from multiple students simultaneously. |

---

## 3. Demo Credentials

Quick one-click login buttons are provided on the login portal:

| Role | Email | Password | Associated Profile |
| :--- | :--- | :--- | :--- |
| **Student** | `student@test.com` | `student123` | Rajan Yadav (`23BCSE101`, Sec A, `RFID-00123`) |
| **Faculty** | `faculty@test.com` | `faculty123` | Prof. Arvind Sharma (ID: `EMP-CSE-01`, CCSE0304 Course Lead) |
| **Admin** | `admin@test.com` | `admin123` | Dr. S. K. Raman (Head of Department & Administrator) |

---

## 4. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide Icons
- **Backend**: Node.js, Express, TypeScript (`tsx`)
- **Database**: Relational file-persisted JSON database engine with atomic disk sync, foreign keys, and indexes
- **QR Engine**: `qrcode` (token generation) + `jsqr` (client camera frame optical decoding)
- **Security**: SHA-256 HMAC salted password hashing, Bearer Token authentication, role-based authorization

---

## 5. Local Setup & Execution Instructions

### Prerequisites
- Node.js (v18 or higher)
- npm or bun

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Run Development Full-Stack Server
The development server boots the Express backend on port `3000` with integrated Vite middlewares:
```bash
npm run dev
```
Navigate to `http://localhost:3000` in your web browser.

### Step 3: Production Build
```bash
npm run build
npm start
```

---

## 6. Database Configuration & Maintenance

The relational data store resides in `database/data.json`.
- The database is auto-seeded on first run with 20 realistic students, 3 faculty members, 5 academic subjects, and over 100 historical attendance logs.
- To reset or reseed the database to its pristine state at any time, log in as **Admin** and navigate to **System Settings** -> **Reseed Demo Data**, or send a POST request to `/api/demo/reset`.

---

## 7. REST API Documentation

### Authentication
- `POST /api/auth/login`: Authenticate email & password, returns JWT token and user profile
- `POST /api/auth/logout`: Clears session token
- `GET /api/auth/me`: Retrieves current authenticated user profile

### Students
- `GET /api/students`: List students (supports `?branch`, `?semester`, `?section`, `?search`)
- `GET /api/students/:id`: Detailed attendance profile with subject summaries
- `POST /api/students`: Register new student (Admin)
- `PUT /api/students/:id`: Update student record
- `DELETE /api/students/:id`: Remove student record

### Attendance & Sessions
- `POST /api/attendance/session`: Create live QR session with expiration timer
- `GET /api/attendance/session/:id`: Get session details and real-time attendee list
- `POST /api/attendance/mark`: Mark attendance via QR token, manual toggle, or RFID
- `POST /api/attendance/bulk`: Save full class attendance sheet (creates LIFO stack frame)
- `POST /api/attendance/undo`: Revert latest attendance modification (Stack POP)
- `POST /api/attendance/rfid-tap`: Emulate hardware RFID card scan

### Analytics & Reports
- `GET /api/analytics/dashboard`: Dynamic role-specific metrics & charts
- `GET /api/reports/defaulters`: Returns students under the threshold (supports `?threshold=75`)
- `GET /api/settings`: Returns current university ordinance settings
- `PUT /api/settings`: Update eligibility cutoff threshold percentage
