import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

import authRoutes from './server/routes/authRoutes.ts';
import studentRoutes from './server/routes/studentRoutes.ts';
import facultyRoutes from './server/routes/facultyRoutes.ts';
import subjectRoutes from './server/routes/subjectRoutes.ts';
import attendanceRoutes from './server/routes/attendanceRoutes.ts';
import analyticsRoutes from './server/routes/analyticsRoutes.ts';
import institutionRoutes from './server/routes/institutionRoutes.ts';
import aiRoutes from './server/routes/aiRoutes.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // JSON Body Parser
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // API Request Logger
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      const start = Date.now();
      const identifier = req.body?.email ? ` [user: ${req.body.email}]` : '';
      res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`[API] ${req.method} ${req.path}${identifier} -> ${res.statusCode} (${duration}ms)`);
      });
    }
    next();
  });

  // API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/institutions', institutionRoutes);
  app.use('/api/students', studentRoutes);
  app.use('/api/faculty', facultyRoutes);
  app.use('/api/subjects', subjectRoutes);
  app.use('/api/attendance', attendanceRoutes);
  app.use('/api/analytics', analyticsRoutes);
  app.use('/api/ai', aiRoutes);
  app.use('/api', analyticsRoutes); // for /api/reports, /api/settings, etc.

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'online',
      system: 'Student Attendance Processing System',
      course: 'CCSE0304 - Computer Architecture & Parallel Processing',
      timestamp: new Date().toISOString(),
    });
  });

  // API 404 handler to prevent API requests from returning SPA index.html
  app.all('/api/*', (req, res) => {
    console.warn(`[API 404] Unhandled route: ${req.method} ${req.path}`);
    res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
  });

  // Development vs Production
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  // Global Error Handler returning JSON
  app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error(`[SERVER ERROR] Uncaught exception on ${req.method} ${req.path}:`, err);
    if (res.headersSent) return;
    res.status(err.status || err.statusCode || 500).json({
      error: err.message || 'Internal Server Error',
    });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Attendance System Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal Server Error:', err);
  process.exit(1);
});
